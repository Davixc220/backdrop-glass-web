# Contributing

* Build: `node tools/build.mjs && node tools/build-demo.mjs`. Smoke test: `node tests/smoke.mjs`.
* Run `node tools/audit.mjs` before every commit/PR - it blocks fonts, third-party images and Apple asset names.
* Do not add assets you do not own or that are not under a licence allowing redistribution (see `LEGAL.md`).
* By contributing you agree your work is licensed under the Apache License 2.0 (section 5 of the licence).
* Files ported from Kyant0/AndroidLiquidGlass keep their attribution header; mark your own modifications.
