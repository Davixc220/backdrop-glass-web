// Headless smoke test: opens every page of the demo, fails on console errors / page errors and saves screenshots.
//   npm i -D puppeteer && node tests/smoke.mjs
// Using your own Chrome:   CHROME_PATH=/usr/bin/chromium npm i -D puppeteer-core && node tests/smoke.mjs
import fs from 'node:fs';

const pageUrl = process.env.DEMO_URL || new URL('../docs/index.html', import.meta.url).href;
const outDir = new URL('./out/', import.meta.url);
const puppeteer = (await import(process.env.CHROME_PATH ? 'puppeteer-core' : 'puppeteer')).default;
const launch = {
  headless: 'shell',
  args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--allow-file-access-from-files', '--no-sandbox'],
  defaultViewport: { width: 430, height: 932 },
};
if (process.env.CHROME_PATH) launch.executablePath = process.env.CHROME_PATH;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pages = ['buttons', 'toggle', 'slider', 'tabs', 'play', 'dialog', 'lock', 'cc', 'mag', 'adl', 'pb', 'sc', 'lz'];
const errors = [];
fs.mkdirSync(outDir, { recursive: true });
const browser = await puppeteer.launch(launch);
const page = await browser.newPage();
page.on('console', (m) => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
await page.goto(pageUrl);
await sleep(1200);
if (!(await page.evaluate(() => BackdropGlass.supported()))) { console.error('WebGL2 is not available in this browser'); process.exit(2); }
await page.screenshot({ path: new URL('home.png', outDir).pathname });
for (const id of pages) {
  await page.evaluate((i) => push(i), id);
  await sleep(id === 'lock' ? 2500 : 1600);
  await page.screenshot({ path: new URL(id + '.png', outDir).pathname });
  await page.evaluate(() => pop());
  await sleep(600);
}
await browser.close();
if (errors.length) { console.error(errors.join('\n')); process.exit(1); }
console.log('smoke ok: ' + pages.length + ' pages rendered without console errors (screenshots in tests/out/)');
