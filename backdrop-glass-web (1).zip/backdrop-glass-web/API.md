# API

Everything lives on the global `BackdropGlass` (or the default export of `dist/backdrop-glass.esm.js`).

```
BackdropGlass.Stage          the main class
BackdropGlass.supported()    true if WebGL2 is available
BackdropGlass.backgrounds.aurora   built-in procedural background (a draw function)
BackdropGlass.sdf.fromText(text, opts)  SDF texture generator for the "sdf" effect
BackdropGlass.util / .advanced          helpers (springs, colours, backdrop builders) - see the end
```

## `new BackdropGlass.Stage(root, options)`

`root` is the container element (it becomes `position:relative` if static and creates its own stacking context).
Everything glass must be a descendant of `root`.

| option | type | default | meaning |
|---|---|---|---|
| `background` | URL \| `HTMLImageElement` \| `HTMLCanvasElement` \| `ImageBitmap` \| `(ctx, w, h, dpr) => void` | `aurora` | what the glass refracts. Images are drawn *cover*. Functions get the 2D context and the size in device pixels. |
| `blur` | `number \| () => number` | 0 | pre-blur of the background in css px |
| `dim` | `[r,g,b,a] \| () => [r,g,b,a]` (0..1) | - | overlay painted over the background (it becomes part of what glass sees) |
| `extra` | `(ctx, w, h, dpr) => void` | - | draw anything else into the backdrop (text, shapes). Call `stage.redraw()` when it changes |
| `dark` | `boolean \| () => boolean` | `prefers-color-scheme` | theme used by sliders/tabs |
| `accent` | CSS colour | `#0088ff` / `#0091ff` | accent of sliders and tabs |
| `font` | CSS font-family | system stack | font used inside tabs |

Methods: `setBackground(src)`, `redraw()`, `wake(ms)` (ask for animation frames, e.g. after you scroll or move glass
elements yourself), `destroy()`.

The stage observes `root` with a `ResizeObserver` and repaints on resize. When nothing animates, no frames are drawn.

## `stage.glass(element, options)` - any element as glass

Returns a handle with `destroy()`.

| option | meaning |
|---|---|
| `shape` | `'capsule'` (default), `'rect'`, a radius in css px, or `{ radius }`. Corners are G2 (curvature-continuous) like the original |
| `vibrancy` | `true` = saturation x1.5 before blurring |
| `colorControls` | `{ saturation, contrast, brightness }` (1, 1, 0 are neutral); replaces `vibrancy` |
| `blur` | blur radius in css px |
| `lens` | `{ height, amount, depth, chromatic }` - refraction band height and strength (css px); `depth` adds the centre-bulge term; `chromatic` enables dispersion |
| `surface` | colour painted over the glass, e.g. `'rgba(255,255,255,.3)'` |
| `tint` | hue-blend tint like LiquidButton's (`'#0088ff'`); can be combined with `surface` |
| `highlight` | `'default'` (directional rim light, default), `'plain'`, `'ambient'` or `false`; `highlightAngle` (deg), `highlightFalloff` |
| `shadow` | `true` (default) \| `false` \| `{ radius, offset: [x, y], alpha }` |
| `innerShadow` | `false` \| `{ radius, offset: [x, y], alpha }` |
| `interactive` | press feedback like LiquidButton (scale + light); children of the element move with it; use `onClick` |
| `backdrop` | what the glass refracts: `'scene'` (default), a CSS colour, a draw function `(ctx, c) => void`, or another glass handle created with `exportBackdrop: true` |
| `exportBackdrop` | lets other elements use this one as their `backdrop` (e.g. sliders inside a glass sheet) |

Children (text, icons) of the element are normal DOM and appear above the glass.

## Components

All return a DOM element you place yourself (`root.append(el)`), sized/positioned with CSS.

* **`stage.button(content, { tint, surface, color, onClick, style, backdrop })`** - `content` is text or a Node.
  Default size `48px` high, auto width; override with `style`. `tint` is any CSS colour; `surface: true` adds the
  translucent white of the catalog's "surface" button.
* **`stage.toggle({ checked, onChange, backdrop })`** - 64x28. `el.checked`, `el.setChecked(bool)`.
* **`stage.slider({ value, min, max, onChange, backdrop })`** - fills the width of its parent, 24px high.
  `el.value`, `el.setValue(n)`.
* **`stage.tabs({ items, selected, onChange, style })`** - `items: [{ label, icon: { path, w, h } }]` where `path` is
  SVG path data (y down) and `w`,`h` its viewBox size; `el.select(i)`. 64px high, fills its width; add margins with `style`.

`backdrop` for toggles/sliders matters when they sit on a solid card instead of the stage background, e.g.
`backdrop: '#fff'`.

## `stage.setSdfTexture(texture)` and `BackdropGlass.sdf.fromText(text, options)`

`fromText('12:45', { font, width, height, maxDistance, dy })` renders text and returns
`{ width, height, data }` (RGBA: signed distance, normal, coverage) for the "sdf" effect - glass digits with a
bevel. Upload it with `stage.setSdfTexture(tex)` and use the advanced `mode: 3` effect (see the *Lock screen* page
of `demo/catalog.js`).

## Advanced: `stage.gl(host, options)`

`glass()` is a declarative layer over this. `options`:

| key | meaning |
|---|---|
| `bg(ctx, c)` | draws the backdrop into a 2D context in the element's local pixels (`c = { q, bw, bh, X, pr, Ch, pad }`). Build it with `BackdropGlass.advanced.BD` (`scene`, `solid`, `layer`, `el`, `combine`, `wrap`) |
| `fx(g, W, H, q)` | returns the effect description for this frame (`W`,`H` css size, `q` = device pixels per css px): `rad`, `cf:[sat,contrast,brightness]`, `blur`, `lens:[height,amount,chromatic,depth]`, `mode` (0 plain, 1 lens, 2 lens+dispersion, 3 sdf, 4 alpha mask), `sdf`, `am`, `t1`/`t2` (RGBA 0..1), `hue`, `hi`, `sh`, `is` - all lengths in device pixels |
| `xf(g, W, H)` | layer transform `{ sx, sy, tx, ty, rot }` (css px / radians), like Compose's `graphicsLayer` - the backdrop is compensated so glass never magnifies what is behind it |
| `ov`, `post`, `after` | overlay drawn inside the clip, drawing on top of the result, hook after the backdrop is drawn |
| `smax`, `dom`, `exp`, `skip` | max raster scale, move children with the layer, export as backdrop, skip drawing |

`stage.step(f)` registers an animation stepper `f(dtSeconds) => keepRunning`, `stage.timer(fn, ms)` an interval that is
cleared by `destroy()`. `BackdropGlass.util` has `Sp` (spring), `DDA` (DampedDragAnimation), `lerpOklab`, `toRGBA`,
`easeIn/easeOut`, `wake`; `BackdropGlass.advanced.gestures` has pan/zoom/rotate helpers (see the playground page).
The demo (`demo/catalog.js`) is the reference for every advanced feature.

## Notes and limits

* Glass refracts the stage background, not live DOM behind it. Draw dynamic content into the backdrop with `extra`.
* Cost grows with the number and size of glass elements that animate at once; elements outside the viewport are skipped.
* WebGL context loss is not handled yet; reload the page.
* Pixel-exact equality with Android is not guaranteed (different rasteriser, fonts, density).
