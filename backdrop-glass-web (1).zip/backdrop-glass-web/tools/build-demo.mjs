// Copies the demo + the built library into docs/ (GitHub Pages: Settings -> Pages -> "Deploy from a branch" -> /docs)
import fs from 'node:fs';
fs.mkdirSync('docs', { recursive: true });
for (const f of ['style.css', 'catalog.js']) fs.copyFileSync(`demo/${f}`, `docs/${f}`);
fs.copyFileSync('dist/backdrop-glass.js', 'docs/backdrop-glass.js');
fs.writeFileSync('docs/index.html', fs.readFileSync('demo/index.html', 'utf8').replace('../dist/backdrop-glass.js', 'backdrop-glass.js'));
fs.writeFileSync('docs/.nojekyll', '');
console.log('docs/ ready');
