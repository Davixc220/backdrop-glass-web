// Concatenates src/*.js into dist/backdrop-glass.js (UMD, global `BackdropGlass`) and dist/backdrop-glass.esm.js
import fs from 'node:fs';
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const order = ['shaders', 'util', 'g2', 'engine', 'core', 'gestures', 'components', 'backgrounds', 'sdf', 'stage', 'index'];
const body = order.map((n) => fs.readFileSync(`src/${n}.js`, 'utf8')).join('\n');
const banner = `/*! Backdrop Glass Web v${pkg.version} | Apache-2.0 | WebGL2 port of Kyant0/AndroidLiquidGlass (Apache-2.0, Copyright 2025 Kyant) - see NOTICE */\n`;
const umd = `${banner}(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BackdropGlass = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';
${body}
return api;
});
`;
const esm = `${banner}const BackdropGlass = (function () {
'use strict';
${body}
return api;
})();
export default BackdropGlass;
export const { Stage, supported, backgrounds, sdf, util, advanced, version } = BackdropGlass;
`;
fs.mkdirSync('dist', { recursive: true });
fs.writeFileSync('dist/backdrop-glass.js', umd);
fs.writeFileSync('dist/backdrop-glass.esm.js', esm);
console.log('dist/backdrop-glass.js', (umd.length / 1024).toFixed(1) + ' KB');
