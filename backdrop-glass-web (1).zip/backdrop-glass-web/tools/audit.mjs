// Fails if the repository contains assets that must not be published (see LEGAL.md).
import fs from 'node:fs';
import path from 'node:path';
const banned = [/\.(ttf|otf|woff2?|eot)$/i, /\.(webp|jpe?g|gif|bmp|tiff?|heic|avif)$/i];
const allowedPng = new Set(['docs/preview.png']);
const forbiddenText = [/SF[- ]?Pro/i, /SFSymbol/i, /sfsymbols/i, /wallpaper_light/i, /clock_sdf/i, /San-Francisco/i];
const skipDirs = new Set(['.git', 'node_modules']);
const allowTextIn = new Set(['LEGAL.md', 'README.md', 'README.pt-BR.md', 'tools/audit.mjs', 'CONTRIBUTING.md', 'NOTICE', 'THIRD_PARTY_NOTICES.md']);
let problems = 0;
const walk = (dir) => {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (!skipDirs.has(e.name)) walk(p); continue; }
    const rel = p.split(path.sep).join('/');
    if (/\.png$/i.test(rel) && !allowedPng.has(rel)) { console.error('unexpected image:', rel); problems++; }
    if (banned.some((r) => r.test(rel))) { console.error('banned asset type:', rel); problems++; }
    if (/\.(js|mjs|html|css|md|json|py|yml|svg)$/i.test(rel) || !path.extname(rel)) {
      const t = fs.readFileSync(p, 'utf8');
      if (!allowTextIn.has(rel)) for (const r of forbiddenText) if (r.test(t)) { console.error('forbidden reference', r, 'in', rel); problems++; }
      const m = t.match(/data:[a-z]+\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]{2000,}/i);
      if (m) { console.error('large embedded binary in', rel); problems++; }
    }
  }
};
walk('.');
if (problems) { console.error(problems + ' problem(s)'); process.exit(1); }
console.log('audit ok: no fonts, third-party images, proprietary asset names or embedded binaries');
