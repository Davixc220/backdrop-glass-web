#!/usr/bin/env python3
"""Regenerates src/shaders.js from the upstream Kotlin sources.

Usage:  python3 tools/extract_shaders.py /path/to/AndroidLiquidGlass

The upstream project (https://github.com/Kyant0/AndroidLiquidGlass, Apache-2.0,
Copyright 2025 Kyant) keeps its shaders as AGSL strings inside Kotlin files.
This script reads those strings and translates them to GLSL ES 3.00 (the dialect
WebGL2 understands):  half4/float2/... -> vec4/vec2/..., `content.eval(p)` ->
`cEval(p)`, `main` -> a named function, uniform declarations hoisted/deduplicated.
"""
import re, sys, glob, json, os

root = sys.argv[1] if len(sys.argv) > 1 else '.'
def find(pattern):
    hits = glob.glob(os.path.join(root, '**', pattern), recursive=True)
    if not hits: sys.exit('not found: ' + pattern)
    return open(hits[0], encoding='utf8').read()

shaders = {m.group(1): m.group(2) for m in re.finditer(r'val (\w+) = """(.*?)"""', find('Shaders.kt'), re.S)}
sdf = re.search(r'SdfShaderString\s*=\s*"""(.*?)"""', find('SdfShader.kt'), re.S)
shaders['SdfShaderString'] = sdf.group(1)

def conv(s):
    s = s.replace('half4', 'vec4').replace('half3', 'vec3').replace('half2', 'vec2').replace('half ', 'float ')
    for n in '234': s = s.replace('float%s' % n, 'vec%s' % n)
    s = re.sub(r'layout\(color\)\s*', '', s).replace('content.eval(', 'cEval(').replace('sdfTex.eval(', 'sdfEval(')
    # smoothstep with edge0 > edge1 is undefined in GLSL: rewrite the one place that uses it
    return s.replace('smoothstep(1.0, 0.0, abs(intensity - 0.25) * 6.0)',
                     '(1.0 - smoothstep(0.0, 1.0, abs(intensity - 0.25) * 6.0))')

uniforms = {}
def body(key, name, drop_circle=False):
    s = conv(shaders[key].replace('$RoundedRectSDF', ''))
    for m in re.finditer(r'^uniform (\w+) (\w+);', s, re.M):
        if m.group(1) != 'shader': uniforms[m.group(2)] = m.group(1)
    s = re.sub(r'^uniform [^\n]*\n', '', s, flags=re.M)
    if drop_circle: s = re.sub(r'float circleMap\(float x\) \{.*?\n\}\n', '', s, flags=re.S)
    return re.sub(r'\n\s*\n\s*\n', '\n', s.replace('vec4 main(vec2 coord)', 'vec4 %s(vec2 coord)' % name))

lens = body('RoundedRectRefractionShaderString', 'lensMain')
circle = re.search(r'float circleMap\(float x\) \{.*?\n\}\n', lens, re.S).group(0)
KT = {
  'sdf': conv(shaders['RoundedRectSDF']) + '\n', 'circle': circle, 'lens': lens.replace(circle, ''),
  'lensD': body('RoundedRectRefractionWithDispersionShaderString', 'lensDMain', True),
  'hiD': body('DefaultHighlightShaderString', 'hiDMain'), 'hiA': body('AmbientHighlightShaderString', 'hiAMain'),
  'sdfs': body('SdfShaderString', 'sdfMain', True),
}
KT['uni'] = ''.join('uniform %s %s;\n' % (t, n) for n, t in uniforms.items())

header = '''/*
 * GENERATED FILE - do not edit by hand.  Regenerate with:
 *     python3 tools/extract_shaders.py /path/to/AndroidLiquidGlass
 *
 * GLSL ES 3.00 translation of the AGSL shaders of Kyant0/AndroidLiquidGlass
 *   (backdrop/.../internal/Shaders.kt and app/.../catalog/utils/SdfShader.kt)
 *   https://github.com/Kyant0/AndroidLiquidGlass
 * Original work: Copyright 2025 Kyant - Licensed under the Apache License, Version 2.0.
 * Modifications: translated from AGSL to GLSL ES 3.00 (type names, `content.eval()` replaced by a
 * texture lookup, entry points renamed, uniforms hoisted). See NOTICE and tools/extract_shaders.py.
 */
'''
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'shaders.js'), 'w', encoding='utf8').write(
    header + 'const KT = ' + json.dumps(KT, indent=2) + ';\n')
print('src/shaders.js written:', list(KT))
