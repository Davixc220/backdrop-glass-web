/*
 * Backdrop Glass Web - catalog demo
 * Copyright 2026 Backdrop Glass Web contributors - Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * A browser port of the screens of the "catalog" app of Kyant0/AndroidLiquidGlass
 * (https://github.com/Kyant0/AndroidLiquidGlass, Apache-2.0, Copyright 2025 Kyant).
 * Layout, parameters and behaviour follow that app; this file was rewritten from Kotlin/Compose to JavaScript.
 * Only system fonts, original icons and a procedural background are used - nothing from third parties is bundled.
 */
const BG = BackdropGlass, { Stage } = BG;
const { Sp, DDA, cl, lerp, easeIn, easeOut, wake } = BG.util;
const { BD, hiD, hiP, shD, VIB, g2clip, gestures } = BG.advanced;
const { xform, mkT, stepT, xfT, smaxT, hitSync } = gestures;

const dk = () => matchMedia('(prefers-color-scheme: dark)').matches;
const h = (t, c, s, ...k) => {
  const e = document.createElement(t);
  if (c) e.className = c;
  if (s) e.style.cssText = s;
  e.append(...k);
  return e;
};
const BLUE = [0, 136 / 255, 1], ORANGE = [1, 141 / 255, 40 / 255];
const ACC = () => (dk() ? '#0091ff' : '#0088ff');
const CONT = (a) => (dk() ? [18 / 255, 18 / 255, 18 / 255, a] : [250 / 255, 250 / 255, 250 / 255, a]);
const FG = () => (dk() ? '#fff' : '#000');
const LOREM = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';

/* ---- original icon set (24x24; `d` = stroked path, `f` = filled path, `fill` = d is filled) ---- */
const ICONS = {
  plane: { fill: 1, d: 'M12 2c.9 0 1.6.8 1.6 1.8V9l7.4 4.4v2L13.6 13v4.2l2.2 1.6V21L12 19.8 8.2 21v-2.2l2.2-1.6V13L3 15.4v-2L10.4 9V3.8C10.4 2.8 11.1 2 12 2z' },
  back: { d: 'M15 5l-7 7 7 7' },
  forward: { d: 'M9 5l7 7-7 7' },
  signal: { fill: 1, d: 'M3 17h3v4H3zM8 13h3v8H8zM13 9h3v12h-3zM18 5h3v16h-3z' },
  wifi: { d: 'M2.5 9a14 14 0 0 1 19 0M6 12.8a9 9 0 0 1 12 0M9.4 16.4a4 4 0 0 1 5.2 0M12 20h.01', w: 2.4 },
  buttons: { d: 'M8 7h8a5 5 0 0 1 0 10H8A5 5 0 0 1 8 7z' },
  toggle: { d: 'M8 7h8a5 5 0 0 1 0 10H8A5 5 0 0 1 8 7z', f: 'M16 9.2a2.8 2.8 0 1 1 0 5.6 2.8 2.8 0 0 1 0-5.6z' },
  sliders: { d: 'M4 12h16', f: 'M14 8.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7z' },
  tabs: { d: 'M5 15h14a2.5 2.5 0 0 1 0 5H5a2.5 2.5 0 0 1 0-5z', f: 'M7 6h2v2H7zM11 6h2v2h-2zM15 6h2v2h-2z' },
  bubble: { d: 'M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-7l-4 3v-3H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z' },
  lock: { d: 'M7 11h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM8 11V8a4 4 0 0 1 8 0v3' },
  panels: { d: 'M5 4h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM14 4h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM5 13h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1zM14 13h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1z' },
  search: { d: 'M11 5a6 6 0 1 1 0 12 6 6 0 0 1 0-12zM16 16l4 4' },
  sparkles: { d: 'M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3' },
  contrast: { d: 'M12 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16z', f: 'M12 4a8 8 0 0 1 0 16z' },
  drop: { d: 'M12 3c3 4 6 7 6 10.5a6 6 0 0 1-12 0C6 10 9 7 12 3z' },
  scroll: { d: 'M8 3h8a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3zM9 8h6M9 12h6M9 16h4' },
  list: { d: 'M9 6h11M9 12h11M9 18h11', f: 'M4 5h2v2H4zM4 11h2v2H4zM4 17h2v2H4z' },
};
const NS = 'http://www.w3.org/2000/svg';
const sf = (name, px, col) => {
  const ic = ICONS[name], v = document.createElementNS(NS, 'svg');
  v.setAttribute('viewBox', '0 0 24 24');
  const add = (d, filled) => {
    const p = document.createElementNS(NS, 'path');
    p.setAttribute('d', d);
    if (filled) p.setAttribute('fill', 'currentColor');
    else { p.setAttribute('fill', 'none'); p.setAttribute('stroke', 'currentColor'); p.setAttribute('stroke-width', ic.w || 2); p.setAttribute('stroke-linecap', 'round'); p.setAttribute('stroke-linejoin', 'round'); }
    v.append(p);
  };
  if (ic.d) add(ic.d, ic.fill);
  if (ic.f) add(ic.f, true);
  v.style.cssText = 'height:' + px + 'px;width:' + px + 'px;color:' + (col || 'currentColor') + ';flex:none;display:block';
  return v;
};
const AIRPLANE = { path: ICONS.plane.d, w: 24, h: 24 };

/* ---- app shell (iOS-style list + glass back button) ---- */
const stack = [], S = {}, scr = document.getElementById('scr'), dev = document.getElementById('dev');
let pickedBg = window.BACKDROP_DEMO_BG; // undefined -> built-in procedural background
const LB = (stage, label, o = {}) => stage.button(label, { ...o, style: o.css, onClick: o.click });

function nav(pg, stage, title, dark) {
  const back = stage.button(sf('back', 20, dark ? '#fff' : '#000'), { surface: true, onClick: pop, style: 'position:absolute;left:16px;top:58px;width:44px;height:44px;padding:0;z-index:5' });
  pg.el.append(h('div', 'nt', dark ? 'color:#fff' : '', title), back);
}
/* BackdropDemoScaffold of the Android catalog: background + "Pick an image" button */
function scaffold(pg, title, o = {}) {
  const so = { ...o }, dark = so.dark;
  delete so.dark; // `dark` here only means "light text over a dark page", not the colour theme
  const stage = new Stage(pg.el, { ...so, background: pickedBg });
  pg.stage = stage;
  pg.dark = dark;
  nav(pg, stage, title, dark);
  const inp = h('input');
  inp.type = 'file';
  inp.accept = 'image/*';
  inp.style.display = 'none';
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    try {
      const b = await createImageBitmap(f);
      pickedBg = b;
      stack.forEach((p) => p.stage && p.stage.setBackground(b));
    } catch (e) { /* not an image */ }
    inp.value = '';
  };
  pg.el.append(inp, h('div', '', 'position:absolute;left:0;right:0;bottom:50px;display:flex;justify-content:center;z-index:6;pointer-events:none',
    stage.button('Pick an image', { tint: BLUE, color: '#fff', style: 'height:56px;padding:0 24px;font-size:16px;pointer-events:auto', onClick: () => inp.click() })));
  return stage;
}
const ctr = (...k) => h('div', 'col', 'align-items:center', ...k);

/* ---- Buttons / Toggle / Slider / Bottom tabs: the public API of the library ---- */
S.buttons = (pg) => {
  const stage = scaffold(pg, 'Buttons');
  pg.el.append(ctr(
    stage.button('Transparent Liquid Button'),
    stage.button('Surface Liquid Button', { surface: true }),
    stage.button('Tinted Liquid Button', { tint: BLUE, color: '#fff' }),
    stage.button('Tinted Liquid Button', { tint: ORANGE, color: '#fff' })));
};
S.toggle = (pg) => {
  const stage = scaffold(pg, 'Toggle');
  let on = false;
  const t1 = stage.toggle({ checked: on, onChange: (v) => { on = v; t2.setChecked(v); } });
  const t2 = stage.toggle({ checked: on, backdrop: dk() ? '#121212' : '#fff', onChange: (v) => { on = v; t1.setChecked(v); } });
  const bx = h('div', 'box', '', h('div', '', 'padding:0 32px', t2));
  pg.el.append(ctr(h('div', '', 'padding:0 32px', t1), bx));
  g2clip(bx, 32);
};
S.slider = (pg) => {
  const stage = scaffold(pg, 'Slider');
  let v = 50;
  const a = stage.slider({ value: v, min: 0, max: 100, onChange: (x) => { v = x; b.setValue(x); } });
  const b = stage.slider({ value: v, min: 0, max: 100, backdrop: dk() ? '#121212' : '#fff', onChange: (x) => { v = x; a.setValue(x); } });
  const bx = h('div', 'box', '', h('div', '', 'padding:0 32px', b));
  pg.el.append(h('div', 'col', '', h('div', '', 'padding:0 32px', a), bx));
  g2clip(bx, 32);
};
S.tabs = (pg) => {
  const stage = scaffold(pg, 'Bottom tabs');
  const mk = (n) => stage.tabs({ items: Array.from({ length: n }, (_, i) => ({ label: 'Tab ' + (i + 1), icon: AIRPLANE })), style: 'margin:0 36px' });
  pg.el.append(h('div', 'col', 'gap:32px', mk(3), mk(4)));
};

/* ---- Glass playground ---- */
S.play=pg=>{const stage=scaffold(pg,'Glass playground'),st={cr:.5,blur:0,rh:.2,ra:.2,ca:0},T=mkT(),bd=stage.bdScene();
const box=h('div','','position:absolute;left:50%;top:102px;width:256px;height:256px;margin-left:-128px'),hit=h('div','','position:absolute;inset:0;touch-action:none;cursor:grab;z-index:2');box.append(hit);
stage.gl(box,{bg:bd,smax:smaxT(T),fx:(g,W,H,q)=>{const m=Math.min(W,H)*q;return{rad:128*st.cr*q,cf:VIB,blur:st.blur*q,lens:[st.rh*m*.5,st.ra*m,st.ca>0,1],hi:hiP(q),sh:shD(q)}},xf:xfT(T)});xform(hit,T);
const f=dt=>{const b=stepT(T,dt);hitSync(hit,T);return b};stage.step(f);
const sheet=h('div','','position:absolute;left:16px;right:16px;bottom:110px;padding:24px;display:flex;flex-direction:column;gap:16px'),gs=stage.gl(sheet,{bg:bd,exp:1,fx:(g,W,H,q)=>({rad:32*q,cf:VIB,blur:4*q,lens:[16*q,32*q,0,0],t1:[1,1,1,.5],hi:hiP(q),sh:shD(q)})}),sb=BD.layer(gs),sl=[];
[['Corner radius','cr',0,1,.001],['Blur radius','blur',0,32,.01],['Refraction height','rh',0,1,.001],['Refraction amount','ra',0,1,.001],['Chromatic aberration','ca',0,1,.001]].forEach(([l,k,a,b,t])=>{const s=stage.slider({backdrop:sb,value:st[k],min:a,max:b,onChange:v=>{st[k]=v;wake()}});sl.push([s,k]);sheet.append(h('div','','display:flex;flex-direction:column;gap:8px;font:400 14px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#000;position:relative',l,s))});
let open=true;const bt=LB(stage,'🔽',{tint:ORANGE,color:'#fff',css:'position:absolute;left:20px;bottom:44px;padding:0 16px;min-width:50px;z-index:6;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif',click:()=>{open=!open;sheet.style.display=open?'flex':'none';bt.querySelector('span').textContent=open?'🔽':'🔼';wake(80)}}),
rs=LB(stage,'Reset',{tint:ORANGE,color:'#fff',css:'position:absolute;right:20px;bottom:44px;z-index:6',click:()=>{T.x.t=0;T.y.t=0;T.z.t=1;T.r.t=0;Object.assign(st,{cr:.5,blur:0,rh:.2,ra:.2,ca:0});sl.forEach(([s,k])=>s.setValue(st[k]));wake()}});pg.el.append(box,sheet,bt,rs)};
/* ---- Dialog ---- */
S.dialog=pg=>{const stage=scaffold(pg,'Dialog',{dark:1,dim:()=>dk()?[18/255,18/255,18/255,.56]:[41/255,41/255,58/255,.23]}),fg=FG();
const cancel=h('div','dbtn',`background:rgba(${dk()?'18,18,18':'250,250,250'},.2);color:${fg}`,'Cancel'),ok=h('div','dbtn','background:'+ACC()+';color:#fff','Okay'),
dlg=h('div','','margin:0 40px;border-radius:48px;position:relative;width:calc(100% - 80px)',h('div','','font:500 24px/32px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding:24px 28px 12px;color:'+fg,'Dialog Title'),h('div','','font:400 15px/22px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding:12px 24px;display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical;overflow:hidden;color:'+(dk()?'rgba(255,255,255,.68)':'rgba(0,0,0,.68)'),LOREM),h('div','','display:flex;gap:16px;padding:12px 24px 24px',cancel,ok));
stage.gl(dlg,{bg:stage.bdScene(),fx:(g,W,H,q)=>({rad:48*q,cf:[1.5,1,dk()?0:.2],blur:(dk()?8:16)*q,lens:[24*q,48*q,0,1],t1:CONT(dk()?.4:.6),hi:hiP(q),sh:shD(q)})});pg.el.append(h('div','col','align-items:center;justify-content:center',dlg))};
/* ---- Lock screen (SDF) ---- */
S.lock=pg=>{const stage=scaffold(pg,'Lock screen',{dark:1}),T={x:new Sp(0,1,1500,.5),y:new Sp(0,1,1500,.5)};let sd=null;
const shade=h('div','','position:absolute;inset:0;background:rgba(0,0,0,.3);z-index:1;pointer-events:none'),clock=h('div','','position:relative;width:min(400px,calc(100% - 96px));aspect-ratio:2/1'),hit=h('div','','position:absolute;inset:0;touch-action:none;cursor:grab;z-index:2'),wrap=h('div','','position:absolute;left:0;right:0;top:0;height:50%;display:flex;align-items:center;justify-content:center;z-index:2;pointer-events:none');clock.append(hit);hit.style.pointerEvents='auto';wrap.append(clock);
setTimeout(()=>{const tex=BG.sdf.fromText('12:45',{width:900,height:340});stage.setSdfTexture(tex);sd=[tex.width,tex.height];clock.style.aspectRatio=sd[0]+'/'+sd[1];wake(200)},40);
stage.gl(clock,{skip:()=>!sd,bg:BD.combine(stage.bdScene(),(x,c)=>{x.fillStyle='rgba(255,255,255,.25)';x.fillRect(0,0,c.bw,c.bh)}),fx:(g,W,H,q)=>sd?{rad:0,cf:[1.5,.75,-.1],blur:2*q,mode:3,sdf:{h:48*q,a:45,w:sd[0],h2:sd[1]}}:{rad:0,mode:0},xf:()=>({tx:T.x.x,ty:T.y.x,sx:1,sy:1,rot:0})});
let dn=0,lx=0,ly=0;hit.addEventListener('pointerdown',e=>{hit.setPointerCapture(e.pointerId);dn=1;lx=e.clientX;ly=e.clientY});hit.addEventListener('pointermove',e=>{if(!dn)return;T.x.snap(T.x.x+e.clientX-lx);T.y.snap(T.y.x+e.clientY-ly);lx=e.clientX;ly=e.clientY;hit.style.transform='translate('+T.x.x+'px,'+T.y.x+'px)';wake()});hit.addEventListener('pointerup',()=>dn=0);
pg.el.append(shade,wrap)};
/* ---- Control center ---- */
S.cc=pg=>{const enter=new Sp(1,1,300,.01),safe=new Sp(1,1,300,.01),conv=x=>(1-Math.exp(-Math.abs(x)))*Math.sign(x),prog=()=>{const p=enter.x;return p<0?conv(p):p<=1?p:1+conv(p-1)},stage=scaffold(pg,'Control center',{dark:1,blur:()=>4*safe.x,dim:()=>[0,0,0,.4*safe.x]}),bd=stage.bdScene(),tiles=[],sp1=h('div'),sp2=h('div'),sm1=h('div'),sm2=h('div');
const tile=(w,hh,o={})=>{const e=h('div','',`position:relative;width:${w}px;height:${hh}px;flex:none`);if(o.inner)e.append(...o.inner);if(o.icon)e.append(h('div','','position:absolute;inset:0;display:grid;place-items:center;color:#fff;pointer-events:none',sf('plane',34,'#fff')));
stage.gl(e,{bg:bd,dom:1,fx:(g,W,H,q)=>{const p=safe.x;return{rad:Math.min(34,W/2,H/2)*q,cf:VIB,lens:[24*q*p,48*q*p,0,1],t1:o.surf===false?null:[0,0,0,.05],hi:{m:1,w:.73*q,b:.25*q,a:1,angle:45,falloff:2}}},
xf:()=>{const pr=prog(),k=1+.1*Math.max(pr-1,0);return{tx:0,ty:-48*(1-pr),sx:1/k,sy:k,rot:0}}});tiles.push(e);return e};
const circ=(pos,col)=>h('div','',`position:absolute;${pos};width:56px;height:56px;border-radius:50%;background:${col};display:grid;place-items:center;pointer-events:none`,sf('plane',27,'#fff')),
big=tile(152,152,{inner:[circ('left:16px;top:16px','rgba(255,255,255,.2)'),circ('right:16px;top:16px',ACC()),circ('left:16px;bottom:16px',ACC())]}),
row=(...k)=>h('div','','display:flex;gap:16px;align-items:center',...k),colm=(...k)=>h('div','','display:flex;flex-direction:column',...k);
const root=h('div','','position:absolute;left:0;right:0;top:134px;display:flex;flex-direction:column;align-items:center;z-index:2;pointer-events:none');
root.append(row(big,tile(152,152)),sp1,h('div','','display:flex;gap:16px;align-items:center;justify-content:center',colm(row(tile(68,68,{icon:1}),tile(68,68,{icon:1})),sm1,tile(152,68,{surf:false})),row(tile(68,152),tile(68,152))),sp2,row(tile(152,152),colm(row(tile(68,68,{icon:1}),tile(68,68,{icon:1})),sm2,row(tile(68,68,{icon:1})))));
let last=-1,dn=0,ly=0,lt=0,vy=0;const f=dt=>{enter.step(dt);safe.step(dt);const p=prog(),ex=Math.max(p-1,0);sp1.style.height=sp2.style.height=16+32*ex+'px';sm1.style.height=sm2.style.height=16+16*ex+'px';tiles.forEach(t=>t.style.opacity=easeIn(cl(safe.x,0,1)));
if(Math.abs(safe.x-last)>.003){last=safe.x;stage.redraw()}return dn||!(enter.rest&&safe.rest)};stage.step(f);
pg.el.addEventListener('pointerdown',e=>{if(e.target.closest('.back,.lb'))return;pg.el.setPointerCapture(e.pointerId);dn=1;ly=e.clientY;lt=performance.now();vy=0});
pg.el.addEventListener('pointermove',e=>{if(!dn)return;const d=e.clientY-ly,n=performance.now();vy=d/Math.max(1,n-lt)*1000;ly=e.clientY;lt=n;const t=enter.x+d/1000;enter.snap(t);safe.snap(cl(t,0,1));wake()});
const up=()=>{if(!dn)return;dn=0;const t=vy<0?0:vy>0?1:(enter.x<.5?0:1);if(t>.5){enter.z=.5;enter.k=300;enter.th=.0005}else{enter.z=1;enter.k=300;enter.th=.01}enter.t=t;enter.v=vy/1000;safe.t=t;wake()};pg.el.addEventListener('pointerup',up);pg.el.addEventListener('pointercancel',up);pg.el.append(root)};
/* ---- Magnifier ---- */
S.mag=pg=>{const off={x:0,y:0};let ln=[];const lh=19.5,stage=scaffold(pg,'Magnifier',{extra:(x,w,hh,dp)=>{const W=w/dp,H=hh/dp,cw=W-48;x.save();x.scale(dp,dp);x.font='400 16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif';const mw=cw-48;ln=[];let l='';for(const t of LOREM.split(/\s+/)){const c=l?l+' '+t:t;if(x.measureText(c).width>mw&&l){ln.push(l);l=t}else l=c}if(l)ln.push(l);
const ch=ln.length*lh+48,cx=24,cy=(H-ch)/2;x.fillStyle=dk()?'rgba(18,18,18,.9)':'rgba(255,255,255,.9)';x.beginPath();x.roundRect(cx,cy,cw,ch,32);x.fill();x.fillStyle=FG();x.textBaseline='top';ln.forEach((s,i)=>x.fillText(s,cx+24,cy+24+i*lh+(lh-16)/2-1));
x.fillStyle=ACC();x.beginPath();x.roundRect(W/2-2+off.x,H/2-12+off.y,4,24,2);x.fill();x.restore()}});
const hit=h('div','','position:absolute;left:50%;top:50%;width:36px;height:48px;margin:-24px 0 0 -18px;touch-action:none;cursor:grab;z-index:3'),glass=h('div','','position:absolute;left:50%;top:50%;width:128px;height:96px;margin:-48px 0 0 -64px;z-index:2');
stage.gl(glass,{bg:BD.wrap(stage.bdScene(),(x,c)=>{x.translate(c.bw/2,c.bh/2);x.scale(1.5,1.5);x.translate(-c.bw/2,-c.bh/2);x.translate(0,-80*c.q)}),fx:(g,W,H,q)=>({rad:Math.min(W,H)/2*q,lens:[8*q,24*q,1,1],hi:hiD(q),sh:shD(q),is:{r:16*q,ox:0,oy:16*q,a:.15}}),xf:()=>({tx:off.x,ty:off.y-80,sx:1,sy:1,rot:0})});
let dn=0,lx=0,ly=0;hit.addEventListener('pointerdown',e=>{hit.setPointerCapture(e.pointerId);dn=1;lx=e.clientX;ly=e.clientY});hit.addEventListener('pointermove',e=>{if(!dn)return;off.x+=e.clientX-lx;off.y+=e.clientY-ly;lx=e.clientX;ly=e.clientY;hit.style.transform='translate('+off.x+'px,'+off.y+'px)';stage.redraw();wake()});hit.addEventListener('pointerup',()=>dn=0);pg.el.append(glass,hit)};
/* ---- Adaptive luminance glass ---- */
S.adl=pg=>{const stage=scaffold(pg,'Adaptive luminance'),T=mkT(),hit=h('div','','position:absolute;inset:0;touch-action:none;cursor:grab;z-index:2'),lab=h('div','','position:absolute;inset:0;display:grid;place-items:center;text-align:center;font:400 16px/22px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;white-space:pre;pointer-events:none'),box=h('div','','position:absolute;left:50%;top:50%;width:160px;height:160px;margin:-80px 0 0 -80px',lab);box.append(hit);
let lum=dk()?0:1,tl=lum,cc=dk()?1:0,tc=cc,tm=0;const lc=document.createElement('canvas');lc.width=lc.height=5;
stage.gl(box,{bg:stage.bdScene(),smax:smaxT(T),dom:0,fx:(g,W,H,q)=>{const l0=lum*2-1,l=Math.sign(l0)*l0*l0;return{rad:24*q,cf:[1.5,l>0?lerp(1,0,l):1,l>0?lerp(.1,.5,l):lerp(.1,-.2,-l)],blur:(l>0?lerp(8,16,l):lerp(8,2,-l))*q,lens:[24*q,Math.min(W,H)*q/2,0,1],hi:hiP(q),sh:shD(q)}},xf:xfT(T),
after:(g,bk)=>{const n=performance.now();if(n-tm<120||!lc)return;tm=n;try{const x=lc.getContext('2d');x.drawImage(bk,0,0,5,5);const d=x.getImageData(0,0,5,5).data;let s=0;for(let i=0;i<100;i+=4)s+=.2126*d[i]/255+.7152*d[i+1]/255+.0722*d[i+2]/255;tl=s/25;tc=tl>.5?0:1}catch(e){}}});xform(hit,T);
const f=dt=>{const k=1-Math.exp(-dt/.35);lum+=(tl-lum)*k;cc+=(tc-cc)*k;const v=Math.round(cc*255);lab.style.color='rgb('+v+','+v+','+v+')';lab.textContent='luminance:\n'+(Math.round(lum*100)/100);hitSync(hit,T);return stepT(T,dt)||Math.abs(tl-lum)>.003||Math.abs(tc-cc)>.003};stage.step(f);
stage.timer(()=>wake(1200),150);pg.el.append(box)};
/* ---- Progressive blur ---- */
S.pb=pg=>{const stage=scaffold(pg,'Progressive blur'),b=h('div','','position:absolute;left:0;right:0;top:50%;height:128px;margin-top:-64px;display:grid;place-items:center;font:400 16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:'+FG(),'alpha-masked progressive blur');
stage.gl(b,{bg:stage.bdScene(),fx:(g,W,H,q)=>({rad:0,blur:4*q,mode:4,am:dk()?[128/255,128/255,128/255,.8]:[1,1,1,.8]})});pg.el.append(b)};
/* ---- Scroll containers ---- */
const scrollPage=(pg,n,title)=>{const stage=scaffold(pg,title),bd=stage.bdScene(),box=h('div','sbox','');for(let i=0;i<n;i++){const t=h('div','','height:160px;flex:none;border-radius:32px;position:relative');stage.gl(t,{bg:bd,fx:(g,W,H,q)=>({rad:32*q,cf:VIB,lens:[16*q,32*q,0,0],hi:hiD(q),sh:shD(q)})});box.append(t)}box.addEventListener('scroll',()=>wake(120));pg.el.append(box)};
S.sc=pg=>scrollPage(pg,20,'Scroll container');S.lz=pg=>scrollPage(pg,100,'Lazy scroll container');

/* ---- Home ---- */
const HOME = [
  ['Liquid glass components', [['Buttons', 'buttons', 'buttons', '#0a84ff'], ['Toggle', 'toggle', 'toggle', '#30d158'], ['Slider', 'slider', 'sliders', '#ff9f0a'], ['Bottom tabs', 'tabs', 'tabs', '#bf5af2'], ['Dialog', 'dialog', 'bubble', '#ff453a']]],
  ['System UIs', [['Lock screen (SDF texture)', 'lock', 'lock', '#636366'], ['Control center', 'cc', 'panels', '#8e8e93'], ['Magnifier', 'mag', 'search', '#32ade6']]],
  ['Experiments', [['Glass playground', 'play', 'sparkles', '#5e5ce6'], ['Adaptive luminance glass', 'adl', 'contrast', '#ac8e68'], ['Progressive blur', 'pb', 'drop', '#64d2ff'], ['Scroll container', 'sc', 'scroll', '#ff375f'], ['Lazy scroll container', 'lz', 'list', '#30b0c7']]],
];
S.home = (pg) => {
  const sc = h('div', 'scroll'), t = h('div', 'ttl', '', 'Backdrop Glass Catalog');
  sc.append(t);
  HOME.forEach(([name, rows]) => {
    const g = h('div', 'grp');
    rows.forEach(([l, id, ic, col]) => {
      const r = h('div', 'row', '', h('span', 'ic', 'background:' + col, sf(ic, 17, '#fff')), h('span', '', '', l), h('span', 'ch', '', sf('forward', 13)));
      r.onclick = () => push(id);
      g.append(r);
    });
    sc.append(h('div', 'sec', '', name), g);
  });
  pg.el.append(sc);
};
const EASE = 'cubic-bezier(.32,.72,0,1)';
function push(id) {
  const prev = stack[stack.length - 1], pg = { el: h('div', 'pg') };
  scr.append(pg.el);
  S[id](pg);
  stack.push(pg);
  dev.dataset.sc = pg.stage ? (pg.dark ? 2 : 1) : 0;
  if (prev) {
    pg.el.animate([{ transform: 'translateX(100%)' }, { transform: 'none' }], { duration: 450, easing: EASE });
    prev.el.animate([{ transform: 'none', filter: 'none' }, { transform: 'translateX(-28%)', filter: 'brightness(.8)' }], { duration: 450, easing: EASE, fill: 'forwards' });
  }
  wake(700);
}
function pop() {
  if (stack.length < 2) return;
  const pg = stack.pop(), prev = stack[stack.length - 1];
  prev.el.getAnimations().forEach((a) => a.cancel());
  dev.dataset.sc = prev.stage ? (prev.dark ? 2 : 1) : 0;
  const a = pg.el.animate([{ transform: 'none' }, { transform: 'translateX(100%)' }], { duration: 380, easing: EASE, fill: 'forwards' });
  prev.el.animate([{ transform: 'translateX(-28%)', filter: 'brightness(.8)' }, { transform: 'none', filter: 'none' }], { duration: 380, easing: EASE });
  wake(430);
  a.onfinish = () => { if (pg.stage) pg.stage.destroy(); pg.el.remove(); };
}
document.getElementById('stat').append(h('span', '', '', '9:41'), h('span', '', 'display:flex;gap:6px;align-items:center', sf('signal', 12), sf('wifi', 12), h('span', 'bat', '', h('i'))));
if (BG.supported()) push('home');
else scr.append(h('div', '', 'padding:80px 24px;font:17px system-ui;color:var(--fg)', 'This demo needs a browser with WebGL2.'));
