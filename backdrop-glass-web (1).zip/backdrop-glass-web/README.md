# Backdrop Glass Web

**Glass buttons, toggles, sliders, tabs and panels with real refraction, for any website.**
A WebGL2 port of the effects of [Kyant0/AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass) (Apache-2.0).

![preview](docs/preview.png)

* Real lens refraction, blur, vibrancy, chromatic aberration, rim highlight, drop shadow and inner shadow - the same
  shaders and parameters as the Android library (translated from AGSL to GLSL).
* Ready-made components with the original spring physics: **button**, **toggle**, **slider**, **bottom tabs**.
* A generic `stage.glass(element, options)` to turn *any* element into glass.
* Curvature-continuous ("G2") capsules and rounded rectangles, like the original.
* One file, no dependencies, no build step needed to use it. Idle pages cost nothing (no frames when nothing moves).
* A complete **catalog demo** (14 screens: buttons, toggle, slider, tabs, dialog, lock screen with an SDF text shape,
  control center, magnifier, playground, adaptive luminance, progressive blur, scroll containers).

**Live demo:** enable GitHub Pages for this repository (Settings -> Pages -> Source: *GitHub Actions*) and open
`https://<your-user>.github.io/<repo>/`. Or run it locally: `npx serve .` and open `/docs/` (or `/demo/`).

## Quick start

```html
<div id="stage" style="position:relative;width:420px;height:640px"></div>
<script src="dist/backdrop-glass.js"></script>
<script>
  const root = document.getElementById('stage');
  const stage = new BackdropGlass.Stage(root, { background: 'my-photo.jpg' }); // omit for the built-in background

  root.append(stage.button('Continue', { tint: '#0088ff', color: '#fff', onClick: () => alert('hi') }));
  root.append(stage.toggle({ checked: true, onChange: (on) => console.log(on) }));
  root.append(stage.slider({ value: 40, min: 0, max: 100, onChange: (v) => console.log(v) }));

  // any element can be glass
  const card = document.createElement('div');
  card.style.cssText = 'position:absolute;left:24px;right:24px;top:120px;height:150px';
  root.append(card);
  stage.glass(card, { shape: 32, vibrancy: true, blur: 6, lens: { height: 24, amount: 34, depth: true },
                      surface: 'rgba(255,255,255,.18)', highlight: 'plain' });
</script>
```

Position the elements with normal CSS (`position:absolute`, flex, grid...). See [`examples/basic.html`](examples/basic.html)
for a full page and [`API.md`](API.md) for every option. ES module: `import BackdropGlass from './dist/backdrop-glass.esm.js'`.

### The one thing to understand: the Stage

Glass in the browser cannot read the pixels "behind" arbitrary DOM, so a **Stage** paints its own background on a
canvas and every glass element refracts *that*. Put a photo, a canvas or a draw function in `background`; draw extra
shapes/text into the backdrop with the `extra` option. Elements outside the stage's `root` are not affected.
Images must be same-origin or served with CORS headers (WebGL cannot read tainted canvases).

## Browser support

Needs WebGL2 and canvas `roundRect` (Chrome/Edge 99+, Firefox 112+, Safari 16.4+). Check `BackdropGlass.supported()` and
provide a plain fallback. Tested here in headless Chromium with a software WebGL renderer; not yet tested on Safari,
Firefox or mobile GPUs - reports welcome.

## How it works

For each glass element the library (1) crops the stage background under it - compensating the element's own
scale/rotation exactly like Compose's `LayerBackdrop` - (2) runs `colorFilter -> blur -> lens | SDF | alpha mask`,
(3) adds the surface tint, rim highlight and inner shadow, (4) draws the outer shadow, (5) clips with the exact
G2 outline evaluated in the shader. Springs follow `spring(dampingRatio, stiffness)` and the catalog's
`DampedDragAnimation`. Details of the port are in the source headers and [`NOTICE`](NOTICE).

## Repository layout

```
src/        library sources (shaders.js is generated from the upstream Kotlin by tools/extract_shaders.py)
dist/       built bundles (backdrop-glass.js, .min.js, .esm.js)
demo/       the catalog demo        docs/   the same demo, ready for GitHub Pages
examples/   minimal examples        tools/  build, shader extraction, asset audit      tests/  smoke test
```

Build: `node tools/build.mjs && node tools/build-demo.mjs` (`npm run build` also minifies with esbuild).
Regenerate the shaders from upstream: clone AndroidLiquidGlass and run `python3 tools/extract_shaders.py path/to/it`.
Asset audit (run before publishing): `node tools/audit.mjs`. Smoke test: `npm i -D puppeteer && node tests/smoke.mjs`.

## Credits

* **[Kyant](https://github.com/Kyant0)** created [AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass)
  and [Shapes](https://github.com/Kyant0/Shapes). The shaders, the effect pipeline, the component behaviour and the
  catalog screens in this project are a port of their work. **If you build Android apps, use the original.**
* Oklab colour space - Bjorn Ottosson. Distance transform adapted from Mapbox TinySDF.
  Full notices in [`NOTICE`](NOTICE) and [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).

## Legal

Licensed under the [Apache License 2.0](LICENSE). This repository intentionally contains **no Apple fonts or icons**
(SF Pro / SF Symbols), no third-party images and no pre-baked assets from the upstream app - see
[`LEGAL.md`](LEGAL.md). Not affiliated with or endorsed by Apple, Google or Kyant; "Apple", "iOS", "SF Symbols",
"Liquid Glass" and "Android" belong to their owners and are only used descriptively.

Documentação em português: [`README.pt-BR.md`](README.pt-BR.md).
