# Backdrop Glass Web (português)

**Botões, interruptores, sliders, abas e painéis de vidro com refração real, para qualquer site.**
Um port em WebGL2 dos efeitos do [Kyant0/AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass) (Apache-2.0).

## Uso rápido

```html
<div id="stage" style="position:relative;width:420px;height:640px"></div>
<script src="dist/backdrop-glass.js"></script>
<script>
  const root = document.getElementById('stage');
  const stage = new BackdropGlass.Stage(root, { background: 'minha-foto.jpg' }); // sem `background` usa o fundo embutido
  root.append(stage.button('Continuar', { tint: '#0088ff', color: '#fff', onClick: () => alert('oi') }));
  root.append(stage.toggle({ checked: true, onChange: (v) => console.log(v) }));
  root.append(stage.slider({ value: 40, min: 0, max: 100, onChange: (v) => console.log(v) }));
</script>
```

Qualquer elemento vira vidro com `stage.glass(elemento, opções)`. Opções completas em [`API.md`](API.md) (inglês) e um
exemplo completo em [`examples/basic.html`](examples/basic.html).

**Ponto importante:** o navegador não consegue "ler" o que está atrás de elementos HTML quaisquer. Por isso o *Stage*
pinta o próprio fundo num canvas, e todo vidro refrata esse fundo. Imagens precisam ser do mesmo domínio ou ter CORS.

## Demo
Ative o GitHub Pages (Settings -> Pages -> Source: *GitHub Actions*) e abra `https://<seu-usuario>.github.io/<repo>/`.
Localmente: `npx serve .` e abra `/docs/`.

## Créditos
O **[Kyant](https://github.com/Kyant0)** criou o [AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass) e o
[Shapes](https://github.com/Kyant0/Shapes). Os shaders, o pipeline de efeitos, o comportamento dos componentes e as telas do
catálogo deste projeto são um port do trabalho dele. Quem desenvolve para Android deve usar o original.

## Legal
Licença [Apache 2.0](LICENSE). Este repositório **não contém fontes nem ícones da Apple** (SF Pro / SF Symbols), nem
imagens de terceiros, nem os arquivos prontos do app original - veja [`LEGAL.md`](LEGAL.md). Projeto independente, sem
vínculo com Apple, Google ou Kyant. Mantenha `LICENSE`, `NOTICE` e `THIRD_PARTY_NOTICES.md` em forks e marque os arquivos
que você alterar (exigência da Apache-2.0).
