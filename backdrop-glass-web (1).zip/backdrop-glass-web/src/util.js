/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Springs (spring(dampingRatio, stiffness)) and DampedDragAnimation follow the catalog of Kyant0/AndroidLiquidGlass.
 * Colour lerp uses the Oklab colour space (Bjorn Ottosson, MIT - see THIRD_PARTY_NOTICES.md), like Compose.
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
const NS='http://www.w3.org/2000/svg',PD=32,I0={sx:1,sy:1,tx:0,ty:0,rot:0};
const cl=(x,a,b)=>Math.min(b,Math.max(a,x)),lerp=(a,b,t)=>a+(b-a)*t,DPR=()=>Math.min(2,devicePixelRatio||1);
const h=(t,c,s,...k)=>{const e=document.createElement(t);if(c)e.className=c;if(s)e.style.cssText=s;e.append(...k);return e};
/* lerp de cor em Oklab, igual ao androidx.compose.ui.graphics.lerp */
const s2l=c=>c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4),l2s=c=>c<=.0031308?c*12.92:1.055*Math.pow(c,1/2.4)-.055;
const toLab=([r,g,b])=>{r=s2l(r);g=s2l(g);b=s2l(b);const l=Math.cbrt(.4122214708*r+.5363325363*g+.0514459929*b),m=Math.cbrt(.2119034982*r+.6806995451*g+.1073969566*b),s=Math.cbrt(.0883024619*r+.2817188376*g+.6299787005*b);return[.2104542553*l+.793617785*m-.0040720468*s,1.9779984951*l-2.428592205*m+.4505937099*s,.0259040371*l+.7827717662*m-.808675766*s]};
const fromLab=([L,a,b])=>{const l=Math.pow(L+.3963377774*a+.2158037573*b,3),m=Math.pow(L-.1055613458*a-.0638541728*b,3),s=Math.pow(L-.0894841775*a-1.291485548*b,3);return[l2s(4.0767416621*l-3.3077115913*m+.2309699292*s),l2s(-1.2684380046*l+2.6097574011*m-.3413193965*s),l2s(-.0041960863*l-.7034186147*m+1.707614701*s)]};
const lerpC=(A,B,t)=>{const a=toLab(A),b=toLab(B),c=fromLab(a.map((v,i)=>lerp(v,b[i],t)));return'rgba('+c.map(v=>Math.round(cl(v,0,1)*255)).join(',')+','+lerp(A[3],B[3],t)+')'};
/* ---- molas (spring(dampingRatio, stiffness, threshold) do Compose) e DampedDragAnimation ---- */
class Sp{constructor(x,z,k,th){this.x=x;this.v=0;this.t=x;this.z=z;this.k=k;this.th=th}
step(dt){const c=2*this.z*Math.sqrt(this.k);let n=Math.max(1,Math.ceil(dt/.004));const q=dt/n;while(n--){this.v+=(this.k*(this.t-this.x)-c*this.v)*q;this.x+=this.v*q}}
snap(v){this.x=this.t=v;this.v=0}get rest(){return Math.abs(this.x-this.t)<this.th&&Math.abs(this.v)<this.th*10}}
class DDA{constructor(v0,min,max,th,ps){this.min=min;this.max=max;this.ps=ps||1.5;this.val=new Sp(v0,1,1000,th);this.vel=new Sp(0,.5,300,th*10);this.pr=new Sp(0,1,1000,.001);this.sx=new Sp(1,.6,250,.001);this.sy=new Sp(1,.7,250,.001);this.last=v0;this.rel=false}
get progress(){return(this.val.x-this.min)/(this.max-this.min)}get target(){return this.val.t}
press(){this.rel=false;this.pr.t=1;this.sx.t=this.sy.t=this.ps}release(){this.rel=true}
update(v){this.val.t=cl(v,this.min,this.max)}animateTo(v){this.press();this.update(v);this.rel=true}
step(dt){this.val.step(dt);const iv=(this.val.x-this.last)/Math.max(dt,1e-3)/(this.max-this.min);this.last=this.val.x;this.vel.t=Math.abs(iv)<1e-3?0:iv;this.vel.step(dt);this.pr.step(dt);this.sx.step(dt);this.sy.step(dt);
if(this.rel&&Math.abs(this.val.x-this.val.t)<(this.max-this.min)*.025){this.rel=false;this.pr.t=0;this.sx.t=this.sy.t=1}}
get rest(){return[this.val,this.vel,this.pr,this.sx,this.sy].every(s=>s.rest)}}

/* easing: CubicBezierEasing(x1, y1, x2, y2) do Compose (EaseIn = .42,0,1,1 / EaseOut = 0,0,.58,1) */
const bez=(x1,y1,x2,y2)=>x=>{let lo=0,hi=1,t=x;for(let i=0;i<24;i++){const b=3*(1-t)*(1-t)*t*x1+3*(1-t)*t*t*x2+t*t*t;if(b<x)lo=t;else hi=t;t=(lo+hi)/2}return 3*(1-t)*(1-t)*t*y1+3*(1-t)*t*t*y2+t*t*t},easeOut=bez(0,0,.58,1),easeIn=bez(.42,0,1,1);
