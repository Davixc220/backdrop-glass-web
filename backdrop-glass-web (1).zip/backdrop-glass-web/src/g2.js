/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * G2 (curvature-continuous) rounded rectangles and capsules: port of ContinuousCurvatureRoundedRectangleCornerBuilder
 * Original work: Kyant0/Shapes (https://github.com/Kyant0/Shapes), author Kyant0, Apache License 2.0.
 * This file was MODIFIED from the original: ported from Kotlin to JavaScript.
 */
/* Capsule()/RoundedRectangle() of Kyant0/Shapes (Apache-2.0) are G2 shapes; the corner Bezier construction is ported 1:1. */
/* ===== Shapes do Kyant0: Capsule()/RoundedRectangle() com cantos G2 (curvatura contínua), porte de ContinuousCurvatureRoundedRectangleCornerBuilder ===== */
const G2K=(()=>{const R2=Math.SQRT2,R2i=Math.SQRT1_2,th=(1-.5)*Math.PI/4,cs=Math.cos(th),sn=Math.sin(th),ct=1/Math.tan(th),cs2=cs*cs,sn2=sn*sn,cs3=cs2*cs,sn3=sn2*sn,E=2/3;
const k0=27*(R2-6*cs+6*R2*cs2-4*cs3)*ct+2*sn*(-9+2*(R2-2*sn)*sn3+2*R2*cs*(9+sn2)-2*cs2*(9+2*sn2)),k1=-81*(-2+R2+4*(-1+R2)*cs+2*(-2+R2)*cs2)*ct-4*sn*(-9+9*R2+R2*sn3+(-2+R2)*cs*(9+sn2)),k2=9*(9*(-4+3*R2+(-6+4*R2)*cs)*ct+(-6+4*R2)*sn),k3=27*(10-7*R2)*ct;
const cubic=(a,b,c,d)=>{const f=((3*c/a)-(b*b)/(a*a))/3,g=((2*b*b*b)/(a*a*a)-(9*b*c)/(a*a)+(27*d)/a)/27,s=Math.sqrt(g*g/4+f*f*f/27);return Math.cbrt(-g/2+s)+Math.cbrt(-g/2-s)-b/(3*a)};
const quartic=(p,q,r)=>{const b=-p/2,c=-r,d=r*p/2-q*q/8,f=((3*c)-(b*b))/3,g=((2*b*b*b)-(9*b*c)+(27*d))/27,rr=Math.sqrt(-f*f*f/27),phi=Math.acos(-g/(2*rr)),y=2*Math.sqrt(-f/3)*Math.cos(phi/3),z=y-b/3,u=Math.sqrt(2*z-p);return(u-Math.sqrt(u*u-4*(z+q/(2*u))))/2};
const even=t=>{const k=E*t,ka=cubic(k3,k2,k1+8*(-k)*sn3*sn,k0),x3=R2i+(-R2i+sn)/ka,y3=1-R2i+(R2i-cs)/ka,x2=x3-y3*ct,x1=x2-1.5*ka*y3*y3/sn3,x0=-k,x6=1-y3,y6=1-x3,y7=1-x2,y8=1-x1,y9=1-x0,a=1.5*ka,g=cs2-sn2,x36=x6-x3,y36=y6-y3,c=-(cs*y36-sn*x36),la=(-g+Math.sqrt(g*g-4*a*c))/(2*a),x4=x3+la*cs,y4=y3+la*sn,x5=x6-la*sn,y5=y6-la*cs;return[x0,0,x1,0,x2,0,x3,y3,x4,y4,x5,y5,x6,y6,1,y7,1,y8,1,y9]};
const uneven=(tH,tV)=>{const kH=E*tH,kV=E*tV,ka3=cubic(k3,k2,k1+8*(-kH)*sn3*sn,k0),ka6=cubic(k3,k2,k1+8*(-kV)*sn3*sn,k0),x3=R2i+(-R2i+sn)/ka3,y3=1-R2i+(R2i-cs)/ka3,x2=x3-y3*ct,x1=x2-1.5*ka3*y3*y3/sn3,x0=-kH,x3p=R2i+(-R2i+sn)/ka6,y3p=1-R2i+(R2i-cs)/ka6,x2p=x3p-y3p*ct,x1p=x2p-1.5*ka6*y3p*y3p/sn3,x0p=-kV,
x6=1-y3p,y6=1-x3p,y7=1-x2p,y8=1-x1p,y9=1-x0p,a=1.5*ka3,b=1.5*ka6,g=cs2-sn2,x36=x6-x3,y36=y6-y3,c=-(cs*y36-sn*x36),d=sn*y36-cs*x36,pp=2*(d/b),qq=g*g*g/(a*b*b),rr=(a*d*d+c*g*g)/(a*b*b),l6=quartic(pp,qq,rr),l3=(-d-b*l6*l6)/g,x4=x3+l3*cs,y4=y3+l3*sn,x5=x6-l6*sn,y5=y6-l6*cs;return[x0,0,x1,0,x2,0,x3,y3,x4,y4,x5,y5,x6,y6,1,y7,1,y8,1,y9]};
const pts=(a,b)=>a===b?even(a):uneven(a,b);
function path(w,h,r,p=new Path2D()){const tW=Math.min(1,Math.max(0,(w*.5-r)/r)),tH=Math.min(1,Math.max(0,(h*.5-r)/r)),P=pts(tW,tH);if(P.length<20||P.some(v=>!isFinite(v))){p.roundRect(0,0,w,h,r);return p}
let x=w-r,y=0;p.moveTo(x+P[0]*r,y+P[1]*r);p.bezierCurveTo(x+P[2]*r,y+P[3]*r,x+P[4]*r,y+P[5]*r,x+P[6]*r,y+P[7]*r);p.bezierCurveTo(x+P[8]*r,y+P[9]*r,x+P[10]*r,y+P[11]*r,x+P[12]*r,y+P[13]*r);p.bezierCurveTo(x+P[14]*r,y+P[15]*r,x+P[16]*r,y+P[17]*r,x+P[18]*r,y+P[19]*r);
x=w-r;y=h;p.lineTo(x+P[18]*r,y-P[19]*r);p.bezierCurveTo(x+P[16]*r,y-P[17]*r,x+P[14]*r,y-P[15]*r,x+P[12]*r,y-P[13]*r);p.bezierCurveTo(x+P[10]*r,y-P[11]*r,x+P[8]*r,y-P[9]*r,x+P[6]*r,y-P[7]*r);p.bezierCurveTo(x+P[4]*r,y-P[5]*r,x+P[2]*r,y-P[3]*r,x+P[0]*r,y-P[1]*r);
x=r;y=h;p.lineTo(x-P[0]*r,y-P[1]*r);p.bezierCurveTo(x-P[2]*r,y-P[3]*r,x-P[4]*r,y-P[5]*r,x-P[6]*r,y-P[7]*r);p.bezierCurveTo(x-P[8]*r,y-P[9]*r,x-P[10]*r,y-P[11]*r,x-P[12]*r,y-P[13]*r);p.bezierCurveTo(x-P[14]*r,y-P[15]*r,x-P[16]*r,y-P[17]*r,x-P[18]*r,y-P[19]*r);
x=r;y=0;p.lineTo(x-P[18]*r,y+P[19]*r);p.bezierCurveTo(x-P[16]*r,y+P[17]*r,x-P[14]*r,y+P[15]*r,x-P[12]*r,y+P[13]*r);p.bezierCurveTo(x-P[10]*r,y+P[11]*r,x-P[8]*r,y+P[9]*r,x-P[6]*r,y+P[7]*r);p.bezierCurveTo(x-P[4]*r,y+P[5]*r,x-P[2]*r,y+P[3]*r,x-P[0]*r,y+P[1]*r);p.closePath();return p}
function quad(w,h,r){const cl01=v=>Math.min(1,Math.max(0,v)),P=pts(cl01((w*.5-r)/r),cl01((h*.5-r)/r));if(P.length<20||P.some(v=>!isFinite(v)))return null;const hw=w/2,hh=h/2,ax=hw-r,pt=i=>[ax+P[i]*r,hh-P[i+1]*r],o=[[0,hh],pt(0)];
for(let c=0;c<3;c++){const b0=pt(c*6),b1=pt(c*6+2),b2=pt(c*6+4),b3=pt(c*6+6);for(let s=1;s<=8;s++){const t=s/8,u=1-t;o.push([u*u*u*b0[0]+3*u*u*t*b1[0]+3*u*t*t*b2[0]+t*t*t*b3[0],u*u*u*b0[1]+3*u*u*t*b1[1]+3*u*t*t*b2[1]+t*t*t*b3[1]])}}o.push([hw,0]);return Float32Array.from(o.flat())}
const svg=(w,h,r)=>{const s={d:'',moveTo(x,y){this.d+='M'+x.toFixed(2)+' '+y.toFixed(2)},lineTo(x,y){this.d+='L'+x.toFixed(2)+' '+y.toFixed(2)},bezierCurveTo(...v){this.d+='C'+v.map(n=>n.toFixed(2)).join(' ')},closePath(){this.d+='Z'},roundRect(){}};path(w,h,r,s);return s.d};
return{path,quad,svg}})();
function g2clip(el,r){const f=()=>{const w=el.offsetWidth,hh=el.offsetHeight;if(w>1&&hh>1)el.style.clipPath='path("'+G2K.svg(w,hh,Math.min(r,w/2,hh/2))+'")'};new ResizeObserver(f).observe(el);f()}
const G2C=new Map();function g2shape(W,H,r,q){const k=W.toFixed(2)+'x'+H.toFixed(2)+'r'+r.toFixed(2);let p=G2C.get(k);if(p===undefined){if(G2C.size>300)G2C.clear();p=G2K.quad(W,H,r);G2C.set(k,p)}return p?{q,pts:p}:null}
