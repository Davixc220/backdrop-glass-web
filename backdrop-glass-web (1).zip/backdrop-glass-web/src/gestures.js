/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Pan / pinch-zoom / rotate helpers (detectTransformGestures behaviour used by the catalog playground)
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- gestos de transformação (detectTransformGestures) ---- */
function xform(el,T){const P=new Map(),c=p=>p.length?[p.reduce((a,b)=>a+b[0],0)/p.length,p.reduce((a,b)=>a+b[1],0)/p.length]:[0,0],ds=p=>p.length>1?Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]):1,an=p=>p.length>1?Math.atan2(p[1][1]-p[0][1],p[1][0]-p[0][0]):0;
el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);P.set(e.pointerId,[e.clientX,e.clientY]);wake()});
el.addEventListener('pointermove',e=>{if(!P.has(e.pointerId))return;const b=[...P.values()],cb=c(b),db=ds(b),ab=an(b);P.set(e.pointerId,[e.clientX,e.clientY]);const a=[...P.values()],ca=c(a);
if(a.length>1){T.z.snap(cl(T.z.x*ds(a)/(db||1),.2,6));T.r.snap(T.r.x+(an(a)-ab)*180/Math.PI)}T.x.snap(T.x.x+ca[0]-cb[0]);T.y.snap(T.y.x+ca[1]-cb[1]);wake()});
const up=e=>P.delete(e.pointerId);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
el.addEventListener('wheel',e=>{e.preventDefault();if(e.shiftKey)T.r.snap(T.r.x+e.deltaY*.2);else T.z.snap(cl(T.z.x*Math.exp(-e.deltaY*.0015),.2,6));wake()},{passive:false})}
const mkT=()=>({x:new Sp(0,1,1500,.5),y:new Sp(0,1,1500,.5),z:new Sp(1,1,1500,.001),r:new Sp(0,1,1500,.1)}),stepT=(T,dt)=>{for(const k in T)T[k].step(dt);return!Object.values(T).every(s=>s.rest)},xfT=T=>()=>({tx:T.x.x,ty:T.y.x,sx:T.z.x,sy:T.z.x,rot:T.r.x*Math.PI/180}),smaxT=T=>()=>Math.min(2.5,Math.max(1,Math.ceil(T.z.x*2)/2));
const hitSync=(hit,T)=>{hit.style.transform='translate('+T.x.x+'px,'+T.y.x+'px) rotate('+T.r.x+'deg) scale('+T.z.x+')'};
