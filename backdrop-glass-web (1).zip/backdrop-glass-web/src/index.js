/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 */
const api = {
  version: '1.0.0',
  Stage,
  supported,
  backgrounds: { aurora },
  sdf: { fromText: sdfFromText },
  util: { Sp, DDA, cl, lerp, DPR, easeIn, easeOut, lerpOklab: lerpC, toRGBA, wake },
  /** building blocks used by the demo catalog; less stable than the API above */
  advanced: {
    BD: { solid: BDsolid, scene: BDscene, layer: BDlayer, el: BDel, combine: BDcomb, wrap: BDwrap },
    bxf, pov, hiD, hiP, shD, VIB, G2K, g2clip, layerDraw, PD,
    gestures: { xform, mkT, stepT, xfT, smaxT, hitSync },
  },
};
