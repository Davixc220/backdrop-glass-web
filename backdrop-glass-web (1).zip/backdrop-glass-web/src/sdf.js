/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Runtime signed-distance-field texture generator for the "sdf" glass effect (the Lock screen clock of the
 * upstream catalog). The upstream catalog ships a pre-baked texture whose provenance is not documented, so
 * this project generates its own from any text/font instead.
 *
 * The euclidean distance transform follows Felzenszwalb & Huttenlocher (2012); the routine structure is adapted
 * from Mapbox TinySDF (ISC License, Copyright (c) 2016, Mapbox) - see THIRD_PARTY_NOTICES.md.
 */
const INF = 1e20;

function edt1d(grid, offset, stride, length, f, v, z) {
  v[0] = 0;
  z[0] = -INF;
  z[1] = INF;
  f[0] = grid[offset];
  for (let q = 1, k = 0, s = 0; q < length; q++) {
    f[q] = grid[offset + q * stride];
    const q2 = q * q;
    do {
      const r = v[k];
      s = (f[q] - f[r] + q2 - r * r) / (q - r) / 2;
    } while (s <= z[k] && --k > -1);
    k++;
    v[k] = q;
    z[k] = s;
    z[k + 1] = INF;
  }
  for (let q = 0, k = 0; q < length; q++) {
    while (z[k + 1] < q) k++;
    const r = v[k];
    const qr = q - r;
    grid[offset + q * stride] = f[r] + qr * qr;
  }
}

function edt(data, w, h) {
  const m = Math.max(w, h);
  const f = new Float64Array(m), v = new Uint16Array(m), z = new Float64Array(m + 1);
  for (let x = 0; x < w; x++) edt1d(data, x, w, h, f, v, z);
  for (let y = 0; y < h; y++) edt1d(data, y * w, 1, w, f, v, z);
}

/**
 * Builds the RGBA texture expected by the SDF shader of the upstream catalog:
 *   R = signed distance (negative inside) / maxDistance, remapped to 0..1
 *   G,B = outward normal (x,y) remapped to 0..1,   A = coverage.
 * @param {string} text
 * @param {{font?:string,width?:number,height?:number,maxDistance?:number}} [o]
 * @returns {{width:number,height:number,data:Uint8Array}}  pass to stage.setSdfTexture()
 */
function sdfFromText(text, o = {}) {
  const W = o.width || 900, H = o.height || 340, D = o.maxDistance || 16;
  const font = o.font || '700 210px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const x = cv.getContext('2d', { willReadFrequently: true });
  x.font = font;
  x.textAlign = 'center';
  x.textBaseline = 'middle';
  x.fillStyle = '#fff';
  x.fillText(text, W / 2, H / 2 + (o.dy || 0));
  const px = x.getImageData(0, 0, W, H).data, n = W * H;
  const outer = new Float64Array(n), inner = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const a = px[i * 4 + 3] / 255;
    if (a === 1) { outer[i] = 0; inner[i] = INF; }
    else if (a === 0) { outer[i] = INF; inner[i] = 0; }
    else { const d = 0.5 - a; outer[i] = d > 0 ? d * d : 0; inner[i] = d < 0 ? d * d : 0; }
  }
  edt(outer, W, H);
  edt(inner, W, H);
  const d = new Float32Array(n);
  for (let i = 0; i < n; i++) d[i] = Math.sqrt(outer[i]) - Math.sqrt(inner[i]);
  // 3x3 box smoothing before taking the gradient (removes stair-steps in the normals)
  const sm = new Float32Array(n);
  for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) {
    let s = 0, c = 0;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
      const X = xx + i, Y = y + j;
      if (X >= 0 && X < W && Y >= 0 && Y < H) { s += d[Y * W + X]; c++; }
    }
    sm[y * W + xx] = s / c;
  }
  const out = new Uint8Array(n * 4);
  for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) {
    const i = y * W + xx;
    const gx = (sm[y * W + Math.min(W - 1, xx + 1)] - sm[y * W + Math.max(0, xx - 1)]) / 2;
    const gy = (sm[Math.min(H - 1, y + 1) * W + xx] - sm[Math.max(0, y - 1) * W + xx]) / 2;
    const len = Math.hypot(gx, gy), nx = len > 1e-4 ? gx / len : 0, ny = len > 1e-4 ? gy / len : 0;
    out[i * 4] = Math.round((Math.min(1, Math.max(-1, d[i] / D)) * 0.5 + 0.5) * 255);
    out[i * 4 + 1] = Math.round((nx * 0.5 + 0.5) * 255);
    out[i * 4 + 2] = Math.round((ny * 0.5 + 0.5) * 255);
    out[i * 4 + 3] = px[i * 4 + 3];
  }
  return { width: W, height: H, data: out };
}
