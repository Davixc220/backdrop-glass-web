/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * WebGL2 version of the backdrop effect pipeline of Kyant0/AndroidLiquidGlass:
 * colorFilter -> blur -> lens | sdf | alpha mask -> surface -> highlight -> inner shadow, plus the outer shadow.
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- shaders ---- */
const HD='#version 300 es\nprecision highp float;\n',VS='#version 300 es\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0,1);}';
/* colorFilter (vibrancy/colorControls) + blur gaussiano separável; textura de capacidade fixa, clamp no tamanho lógico (TileMode.Clamp) */
const FS_B=HD+`uniform sampler2D t;uniform vec2 dir,uBS,uTS;uniform float sig,uCF;uniform mat3 uM;uniform vec3 uK;out vec4 o;
vec3 S(vec2 p){vec3 c=texture(t,clamp(p,vec2(.5),uBS-.5)/uTS).rgb;return uCF>.5?clamp(uM*c+uK,0.,1.):c;}
void main(){vec2 p=gl_FragCoord.xy;if(sig<.05){o=vec4(S(p),1);return;}
float R=ceil(sig*3.),st=max(1.,R/12.),ws=0.;vec3 a=vec3(0);
for(float x=-R;x<=R;x+=st){float w=exp(-.5*x*x/(sig*sig));a+=S(p+dir*x)*w;ws+=w;}o=vec4(a/ws,1);}`;
/* elemento: efeito (lens/dispersão/sdf/máscara alfa) -> surface -> highlight -> inner shadow, e shadow por fora (ordem do DrawBackdropModifier) */
const FS_E=HD+`uniform sampler2D uBack,uSdf;uniform vec4 uShp;uniform vec2 uQ[27];uniform vec2 uBS,uTS,uCS,uPos;uniform float uBO,uMode,uHue;uniform vec4 uT1,uT2,uHi,uSh,uIs,uAM;
${KT.uni}
vec4 cEval(vec2 p){return texture(uBack,clamp(p,vec2(.5),uBS-.5)/uTS);}
vec4 sdfEval(vec2 p){return texture(uSdf,p/sdfTexSize);}
${KT.sdf}${KT.circle}${KT.lens}${KT.lensD}${KT.hiD}${KT.hiA}${KT.sdfs}
vec4 amMain(vec2 coord){float a=1.-smoothstep(size.y*.5,size.y,coord.y);return mix(cEval(coord)*a,vec4(uAM.rgb,1.)*a,uAM.w);}
float lum(vec3 c){return dot(c,vec3(.3,.59,.11));}
vec3 clipC(vec3 c){float l=lum(c),n=min(c.r,min(c.g,c.b)),x=max(c.r,max(c.g,c.b));if(n<0.)c=l+(c-l)*l/(l-n);if(x>1.)c=l+(c-l)*(1.-l)/(x-l);return c;}
vec3 setLum(vec3 c,float l){return clipC(c+(l-lum(c)));}
float satOf(vec3 c){return max(c.r,max(c.g,c.b))-min(c.r,min(c.g,c.b));}
vec3 setSat(vec3 c,float s){float mn=min(c.r,min(c.g,c.b)),mx=max(c.r,max(c.g,c.b));return mx>mn?(c-mn)*s/(mx-mn):vec3(0);}
out vec4 o;float ph(float x){return .5+.5*tanh(clamp(.85*x,-12.,12.));}
float sdG(vec2 pc){vec2 p=abs(pc);float mx=-1e9,dm=1e9;for(int i=0;i<26;i++){vec2 A=uQ[i],d=uQ[i+1]-A,ap=p-A;float l2=dot(d,d);if(l2<1e-8)continue;mx=max(mx,dot(ap,vec2(-d.y,d.x))/sqrt(l2));dm=min(dm,length(ap-d*clamp(dot(ap,d)/l2,0.,1.)));}return mx>0.?dm:mx;}
float sdAt(vec2 p,vec2 hs,float rd){return uShp.x>.5?sdG((p-uPos-hs)/uShp.y)*uShp.y:sdRoundedRect(p-uPos-hs,hs,rd);}
float rA(vec2 q,vec4 r){return q.x>=0.?(q.y<=0.?r.y:r.z):(q.y<=0.?r.x:r.w);}
void main(){vec2 px=vec2(gl_FragCoord.x,uCS.y-gl_FragCoord.y),c=px-uPos,hs=size*.5,cc=c-hs,bo=vec2(uBO);
float rd=rA(cc,cornerRadii),sd=sdAt(px,hs,rd),a0=1.-smoothstep(-.5,.5,sd);vec4 res=vec4(0);
if(a0>0.){vec4 b;
if(uMode<.5)b=vec4(cEval(c+bo).rgb,1.);else if(uMode<1.5)b=lensMain(c+bo);else if(uMode<2.5)b=lensDMain(c+bo);else if(uMode<3.5)b=sdfMain(c+bo);else b=amMain(c+bo);
if(uMode<2.5){vec3 col=b.rgb;if(uHue>.5)col=setLum(setSat(uT1.rgb,satOf(col)),lum(col));col=mix(col,uT1.rgb,uT1.a);col=mix(col,uT2.rgb,uT2.a);
if(uHi.x>.5){float d=max(-sd,0.),w=uHi.y,s=max(uHi.z,.001),k=(ph((d+w)/s)-ph((d-w)/s))*uHi.w;
if(uHi.x>2.5)col=min(col+vec3(.38*k),1.);else if(uHi.x<1.5)col=min(col+hiDMain(c).rgb*.5*k,1.);else{vec4 hh=hiAMain(c)*.38*k;col=hh.rgb+col*(1.-hh.a);}}
if(uIs.w>0.){float s=max(uIs.x,.001);col*=1.-uIs.w*ph(-sd/s)*(1.-ph(-sdAt(px-uIs.yz,hs,rd)/s));}
res=vec4(col,1.);}else res=b;}
float sA=0.;if(uSh.w>0.&&a0<1.)sA=uSh.w*ph(-sdAt(px-uSh.yz,hs,rd)/max(uSh.x,.001));
float ra=res.a*a0;o=vec4(res.rgb*a0,ra+sA*(1.-ra));}`;
const sgm=r=>r>0?.57735*r+.5:0;                       /* BlurMaskFilter(radius) do Android: sigma = 0.57735*r + 0.5 */
class Eng{
constructor(){const cv=document.createElement('canvas');cv.width=cv.height=8;const g=this.g=cv.getContext('webgl2',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true,depth:false,stencil:false});this.cv=cv;this.cap=[0,0];this.ul=new Map();
this.pB=this.prog(FS_B);this.pE=this.prog(FS_E);this.t0=this.tex();this.tA=this.tex();this.tB=this.tex();this.ts=this.tex();g.texImage2D(g.TEXTURE_2D,0,g.RGBA,1,1,0,g.RGBA,g.UNSIGNED_BYTE,new Uint8Array(4));this.fb=g.createFramebuffer();this.hasSdf=0;}
prog(fs){const g=this.g,p=g.createProgram();for(const[t,s]of[[g.VERTEX_SHADER,VS],[g.FRAGMENT_SHADER,fs]]){const x=g.createShader(t);g.shaderSource(x,s);g.compileShader(x);if(!g.getShaderParameter(x,g.COMPILE_STATUS))console.error(g.getShaderInfoLog(x));g.attachShader(p,x)}g.linkProgram(p);return p}
tex(){const g=this.g,t=g.createTexture();g.bindTexture(g.TEXTURE_2D,t);[[g.TEXTURE_MIN_FILTER,g.LINEAR],[g.TEXTURE_MAG_FILTER,g.LINEAR],[g.TEXTURE_WRAP_S,g.CLAMP_TO_EDGE],[g.TEXTURE_WRAP_T,g.CLAMP_TO_EDGE]].forEach(([a,b])=>g.texParameteri(g.TEXTURE_2D,a,b));return t}
setSdf(bmp){const g=this.g;if(bmp&&bmp.data){g.bindTexture(g.TEXTURE_2D,this.ts);g.pixelStorei(g.UNPACK_ALIGNMENT,1);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,bmp.width,bmp.height,0,g.RGBA,g.UNSIGNED_BYTE,bmp.data);g.pixelStorei(g.UNPACK_ALIGNMENT,4);this.hasSdf=1;return}g.bindTexture(g.TEXTURE_2D,this.ts);g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL,false);g.pixelStorei(g.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);g.pixelStorei(g.UNPACK_COLORSPACE_CONVERSION_WEBGL,g.NONE);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,g.RGBA,g.UNSIGNED_BYTE,bmp);g.pixelStorei(g.UNPACK_COLORSPACE_CONVERSION_WEBGL,g.BROWSER_DEFAULT_WEBGL);this.hasSdf=1}
ensure(w,hh){if(w<=this.cap[0]&&hh<=this.cap[1])return;const g=this.g,W=Math.max(this.cap[0],Math.ceil(w/128)*128),H=Math.max(this.cap[1],Math.ceil(hh/128)*128);this.cap=[W,H];this.cv.width=W;this.cv.height=H;[this.t0,this.tA,this.tB].forEach(t=>{g.bindTexture(g.TEXTURE_2D,t);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,W,H,0,g.RGBA,g.UNSIGNED_BYTE,null)})}
use(p){this.g.useProgram(p);this.cur=p}
L(n){let m=this.ul.get(this.cur);if(!m)this.ul.set(this.cur,m={});return n in m?m[n]:(m[n]=this.g.getUniformLocation(this.cur,n))}
u(n,...v){const l=this.L(n);if(l===null)return;const g=this.g;if(n=='t'||n=='uBack'||n=='uSdf')g.uniform1i(l,v[0]);else g['uniform'+v.length+'f'](l,...v)}
pass(src,dst,W,H){const g=this.g;g.bindFramebuffer(g.FRAMEBUFFER,this.fb);g.framebufferTexture2D(g.FRAMEBUFFER,g.COLOR_ATTACHMENT0,g.TEXTURE_2D,dst,0);g.viewport(0,0,W,H);g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,src);g.drawArrays(g.TRIANGLES,0,3)}
/* o: {bk,cw,ch,ex,ey,w,h,bo,rad,cf:[sat,con,bri],blur,mode,lens,t1,t2,hue,hi,sh,is,am,sdf} — tudo em px de dispositivo/raster */
draw(o){const g=this.g,BW=o.bk.width,BH=o.bk.height,CW=o.cw,CH=o.ch;this.ensure(Math.max(CW,BW),Math.max(CH,BH));const TS=this.cap;
g.disable(g.BLEND);g.disable(g.SCISSOR_TEST);g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL,false);g.pixelStorei(g.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,this.t0);g.texSubImage2D(g.TEXTURE_2D,0,0,0,g.RGBA,g.UNSIGNED_BYTE,o.bk);
let T=this.t0;const cf=o.cf,sg=o.blur||0;
if(cf||sg>=.05){this.use(this.pB);this.u('uBS',BW,BH);this.u('uTS',TS[0],TS[1]);this.u('t',0);
if(cf){const[s,c,b]=cf,iv=1-s,r=.213*iv,gg=.715*iv,bb=.072*iv,k=.5-c*.5+b,M=[c*r+c*s,c*r,c*r,c*gg,c*gg+c*s,c*gg,c*bb,c*bb,c*bb+c*s];g.uniformMatrix3fv(this.L('uM'),false,M);this.u('uK',k,k,k);this.u('uCF',1)}else this.u('uCF',0);
this.u('dir',1,0);this.u('sig',sg);this.pass(this.t0,this.tA,BW,BH);T=this.tA;
if(sg>=.05){this.u('uCF',0);this.u('dir',0,1);this.pass(this.tA,this.tB,BW,BH);T=this.tB}}
g.bindFramebuffer(g.FRAMEBUFFER,null);g.viewport(0,0,CW,CH);g.enable(g.SCISSOR_TEST);g.scissor(0,0,CW,CH);g.clearColor(0,0,0,0);g.clear(g.COLOR_BUFFER_BIT);g.disable(g.SCISSOR_TEST);
this.use(this.pE);g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,T);g.activeTexture(g.TEXTURE1);g.bindTexture(g.TEXTURE_2D,this.ts);g.activeTexture(g.TEXTURE0);
this.u('uBack',0);this.u('uSdf',1);const sp=o.shp;if(sp){this.u('uShp',1,sp.q,0,0);g.uniform2fv(this.L('uQ'),sp.pts)}else this.u('uShp',0,1,0,0);this.u('uBS',BW,BH);this.u('uTS',TS[0],TS[1]);this.u('uCS',CW,CH);this.u('uPos',o.ex,o.ey);this.u('uBO',o.bo||0);
this.u('size',o.w,o.h);this.u('offset',-(o.bo||0),-(o.bo||0));this.u('cornerRadii',o.rad,o.rad,o.rad,o.rad);
const mode=o.mode||0,L=o.lens;this.u('uMode',mode);
if(mode==1||mode==2){this.u('refractionHeight',L[0]);this.u('refractionAmount',-L[1]);this.u('depthEffect',L[3]?1:0);this.u('chromaticAberration',1)}
if(mode==3){this.u('refractionHeight',o.sdf.h);this.u('lightAngle',o.sdf.a);this.u('sdfTexSize',o.sdf.w,o.sdf.h2)}
const t1=o.t1||[0,0,0,0],t2=o.t2||[0,0,0,0],hi=o.hi,sh=o.sh,is=o.is,am=o.am||[0,0,0,0];
this.u('uT1',...t1);this.u('uT2',...t2);this.u('uHue',o.hue?1:0);this.u('uAM',...am);
this.u('uHi',hi?hi.m:0,hi?hi.w:0,hi?sgm(hi.b):0,hi?hi.a:0);this.u('color',1,1,1,1);this.u('angle',((hi&&hi.angle)??45)*Math.PI/180);this.u('falloff',(hi&&hi.falloff)||1);
this.u('uSh',sh?sgm(sh.r):0,sh?sh.ox:0,sh?sh.oy:0,sh?sh.a:0);this.u('uIs',is?is.r:0,is?is.ox:0,is?is.oy:0,is?is.a:0);
g.drawArrays(g.TRIANGLES,0,3)}}
