/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Port of the catalog components LiquidButton, LiquidToggle, LiquidSlider and LiquidBottomTabs
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* LiquidButton (catalog/components/LiquidButton.kt): vibrancy + blur(2dp) + lens(12dp, 24dp), default highlight/shadow, press scale + interactive highlight */
const BTN_STYLE='position:relative;display:flex;align-items:center;justify-content:center;gap:8px;box-sizing:border-box;height:48px;padding:0 16px;font:400 15px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:none;width:max-content;';
function makeButton(st,content,o={}){const host=h('div','',BTN_STYLE+(o.style||''));
if(content instanceof Node)host.append(content);else if(content!==undefined&&content!==null&&content!=='')host.append(h('span','','pointer-events:none;color:'+(o.color||'#000'),String(content)));
const ih=IH(st,host,o.onClick);
gl(st,host,{bg:o.backdrop||BDscene(st),dom:1,smax:1.12,fx:(g,W,H,q)=>({rad:Math.min(W,H)/2*q,cf:VIB,blur:2*q,lens:[12*q,24*q,0,0],t1:o.tint?[...o.tint,.75]:o.surface?[1,1,1,.3]:null,hue:!!o.tint,hi:hiD(q),sh:shD(q)}),xf:bxf(ih),ov:pov(ih.pp,()=>[ih.px.x,ih.py.x])});return host}
/* icon spec: {path:'SVG path data (y down)', w, h} -> inline <svg> */
function iconSvg(ic,px){const v=document.createElementNS(NS,'svg'),p=document.createElementNS(NS,'path');v.setAttribute('viewBox','0 0 '+ic.w+' '+ic.h);p.setAttribute('d',ic.path);v.append(p);v.style.cssText='height:'+px+'px;width:auto;fill:currentColor;flex:none;display:block';return v}
/* ---- LiquidToggle ---- */
function makeToggle(st,bd,get,set){const w=h('div','','position:relative;width:64px;height:28px;flex:none;cursor:pointer;touch-action:none'),trk=h('canvas','','position:absolute;left:0;top:0;width:64px;height:28px'),th=h('div','','position:absolute;left:0;top:2px;width:40px;height:24px');w.append(trk,th);
let fr=get()?1:0,drag=0,down=0,lx=0;const d=new DDA(fr,0,1,.001),acc=st.dark()?[48/255,209/255,88/255,1]:[52/255,199/255,89/255,1],trc=st.dark()?[120/255,120/255,128/255,.36]:[120/255,120/255,120/255,.2];
const lay=()=>{th.style.left=lerp(2,22,d.val.x)+'px';const dp=DPR();if(trk.width!=64*dp){trk.width=64*dp;trk.height=28*dp}const x=trk.getContext('2d');x.setTransform(dp,0,0,dp,0,0);x.clearRect(0,0,64,28);x.fillStyle=lerpC(trc,acc,d.val.x);x.beginPath();x.roundRect(0,0,64,28,14);x.fill()};
gl(st,th,{bg:BDcomb(bd,BDwrap(BDel(trk),(x,c)=>{const p=d.pr.x;x.translate(c.bw/2,c.bh/2);x.scale(lerp(2/3,.75,p),lerp(0,.75,p));x.translate(-c.bw/2,-c.bh/2)})),smax:1.5,
fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,blur:8*q*(1-p),lens:[5*q*p,10*q*p,1,0],t1:[1,1,1,1-p],hi:{m:2,w:.36*q,b:.25/1.5*q,a:p},sh:{r:4*q,ox:0,oy:4/6*q,a:.05},is:{r:4*q*p,ox:0,oy:4*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/50;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
w.addEventListener('pointerdown',e=>{w.setPointerCapture(e.pointerId);down=1;drag=0;lx=e.clientX;d.press();wake()});
w.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-lx;lx=e.clientX;if(dx)drag=1;fr=cl(fr+dx/20,0,1);d.update(fr);wake()});
const up=()=>{if(!down)return;down=0;if(drag){fr=d.target>=.5?1:0;drag=0}else fr=get()?0:1;set(fr==1);d.update(fr);d.release();wake()};w.addEventListener('pointerup',up);w.addEventListener('pointercancel',up);
w.sync=()=>{const t=get()?1:0;if(t!=fr){fr=t;d.animateTo(t)}wake()};const f=dt=>{d.step(dt);lay();return down||!d.rest};st._step(f);lay();return w}
/* ---- LiquidSlider ---- */
function makeSlider(st,bd,get,set,min,max,vt){const w=h('div','','position:relative;width:100%;height:24px;cursor:pointer;touch-action:none'),trk=h('canvas','','position:absolute;left:0;top:9px;width:100%;height:6px'),th=h('div','','position:absolute;left:0;top:0;width:40px;height:24px');w.append(trk,th);
const d=new DDA(get(),min,max,vt),acc=st.accent(),trc=st.dark()?'rgba(120,120,128,.36)':'rgba(120,120,120,.2)',TW=()=>w.clientWidth||300;let down=0,drag=0,lx=0,tap=0;
const lay=()=>{const dp=DPR(),W=TW();th.style.left=cl(-20+W*d.progress,-10,W-30)+'px';if(trk.width!=Math.round(W*dp)){trk.width=Math.round(W*dp);trk.height=6*dp}const x=trk.getContext('2d');x.setTransform(dp,0,0,dp,0,0);x.clearRect(0,0,W,6);x.fillStyle=trc;x.beginPath();x.roundRect(0,0,W,6,3);x.fill();const aw=Math.round(W*d.progress);if(aw>0){x.fillStyle=acc;x.beginPath();x.roundRect(0,0,aw,6,Math.min(aw,6)/2);x.fill()}};
gl(st,th,{bg:BDcomb(bd,BDwrap(BDel(trk),(x,c)=>{const p=d.pr.x;x.translate(c.bw/2,c.bh/2);x.scale(lerp(2/3,1,p),lerp(0,1,p));x.translate(-c.bw/2,-c.bh/2)})),smax:1.5,
fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,blur:8*q*(1-p),lens:[10*q*p,14*q*p,1,0],t1:[1,1,1,1-p],hi:{m:2,w:.36*q,b:.25/1.5*q,a:p},sh:{r:4*q,ox:0,oy:4/6*q,a:.05},is:{r:4*q*p,ox:0,oy:4*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/10;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
w.addEventListener('pointerdown',e=>{w.setPointerCapture(e.pointerId);const r=w.getBoundingClientRect(),px=e.clientX-r.left,t=parseFloat(th.style.left)||0;tap=px<t||px>t+40;down=1;drag=0;lx=e.clientX;if(!tap)d.press();wake()});
w.addEventListener('pointermove',e=>{if(!down||tap)return;const dx=e.clientX-lx;lx=e.clientX;if(dx)drag=1;const v=cl(d.target+(max-min)*dx/TW(),min,max);d.update(v);set(v);wake()});
const up=e=>{if(!down)return;down=0;if(tap){const r=w.getBoundingClientRect(),v=cl(min+(max-min)*(e.clientX-r.left)/TW(),min,max);d.animateTo(v);set(v)}else d.release();wake()};w.addEventListener('pointerup',up);w.addEventListener('pointercancel',()=>{down=0;d.release()});
w.sync=()=>{const v=cl(get(),min,max);if(d.target!=v)d.update(v);wake()};const f=dt=>{d.step(dt);lay();return down||!d.rest};st._step(f);lay();return w}
/* ---- LiquidBottomTabs ---- */
function makeTabs(st,o){const items=o.items,n=items.length,font=st.font,bd=BDscene(st),host=h('div','','position:relative;height:64px;touch-action:none;user-select:none;-webkit-user-select:none;'+(o.style||'')),row=h('div','','position:absolute;inset:0;display:flex;padding:4px;pointer-events:none');
items.forEach(it=>row.append(h('div','','flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font:400 12px/14px '+font+';color:'+st.fg(),it.icon?iconSvg(it.icon,26):'',it.label||'')));
const bar=h('div','','position:absolute;inset:0',row),hid=h('div','','position:absolute;left:0;right:0;top:4px;height:56px;opacity:0;pointer-events:none'),pill=h('div','','position:absolute;top:4px;height:56px'),d=new DDA(o.selected||0,0,n-1,.001,78/56),off=new Sp(0,1,300,.5);host.append(bar,hid,pill);
const tw=()=>(host.clientWidth-8)/n,po=()=>{const f=cl(off.x/(host.clientWidth||1),-1,1);return 4*Math.sign(f)*easeOut(Math.abs(f))},lay=()=>{pill.style.width=tw()+'px';pill.style.left=4+d.val.x*tw()+po()+'px'},ih=IH(st,pill),pos=(W,H)=>[(d.val.x+.5)*tw()+po(),H/2];
gl(st,bar,{bg:bd,dom:1,smax:1.1,fx:(g,W,H,q)=>({rad:Math.min(W,H)/2*q,cf:VIB,blur:8*q,lens:[24*q,24*q,0,0],t1:st.container(.4),hi:hiD(q),sh:shD(q)}),xf:(g,W)=>{const s=lerp(1,1+16/W,d.pr.x);return{sx:s,sy:s,tx:po(),ty:0,rot:0}},ov:pov(ih.pp,pos)});
const gh=gl(st,hid,{bg:bd,fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,cf:VIB,blur:8*q,lens:[24*q*p,24*q*p,0,0],t1:st.container(.4),hi:{...hiD(q),a:p},sh:shD(q)}},xf:()=>({sx:1,sy:1,tx:po(),ty:0,rot:0}),ov:pov(ih.pp,pos),
post:(t,g,W,H,q)=>{const w=(W-8)/n,s=lerp(1,1.2,d.pr.x);t.fillStyle=st.accent();t.textAlign='center';t.textBaseline='middle';t.font='400 '+12*q+'px '+font;
for(let i=0;i<n;i++){t.save();t.translate((PD+4+w*(i+.5))*q,(PD+H/2)*q);t.scale(s,s);const ic=items[i].icon;if(ic){const k=26*q/ic.h;t.save();t.translate(-ic.w*k/2,-8.2*q-ic.h*k/2);t.scale(k,k);t.fill(new Path2D(ic.path));t.restore()}t.fillText(items[i].label||'',0,15*q);t.restore()}}});
gl(st,pill,{bg:BDcomb(bd,BDlayer(gh)),smax:1.4,fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,lens:[10*q*p,14*q*p,1,0],t1:st.dark()?[1,1,1,.1*(1-p)]:[0,0,0,.1*(1-p)],t2:[0,0,0,.03*p],hi:{...hiD(q),a:p},sh:{r:24*q,ox:0,oy:4*q,a:.1*p},is:{r:8*q*p,ox:0,oy:8*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/10;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
let down=0,onPill=0,lx=0,tap=-1;const f=dt=>{d.step(dt);off.step(dt);lay();return down||!d.rest||!off.rest};st._step(f);
host.addEventListener('pointerdown',e=>{host.setPointerCapture(e.pointerId);const r=host.getBoundingClientRect(),x=e.clientX-r.left,pl=4+d.val.x*tw()+po();down=1;lx=e.clientX;onPill=x>=pl&&x<=pl+tw();tap=onPill?-1:Math.floor((x-4)/tw());if(onPill)d.press();wake()});
host.addEventListener('pointermove',e=>{if(!down||!onPill)return;const dx=e.clientX-lx;lx=e.clientX;d.update(d.target+dx/tw());off.snap(off.x+dx);wake()});
const up=()=>{if(!down)return;down=0;if(onPill){const i=cl(Math.round(d.target),0,n-1);d.animateTo(i);off.t=0;o.onChange&&o.onChange(i)}else if(tap>=0&&tap<n){d.animateTo(tap);o.onChange&&o.onChange(tap)}wake()};host.addEventListener('pointerup',up);host.addEventListener('pointercancel',up);lay();host.select=i=>{d.animateTo(cl(i,0,n-1));wake()};return host}
