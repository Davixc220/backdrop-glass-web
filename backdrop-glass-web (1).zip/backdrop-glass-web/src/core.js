/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Layer backdrops (LayerBackdrop/CombinedBackdrop), drawBackdrop (DrawBackdropModifier), InteractiveHighlight and the Liquid* defaults
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- infraestrutura de elementos de vidro ---- */
let GE=null,raf=0,until=0;const VIB=[1.5,1,0];function getEngine(){return GE||(GE=new Eng())}
const GL=new Set(),SP=new Set();
function wake(ms=0){until=Math.max(until,performance.now()+ms);if(!raf)raf=requestAnimationFrame(frame)}
function frame(t){const dt=Math.min(.033,(t-(frame.l||t))/1e3||.016);frame.l=t;let busy=performance.now()<until;SP.forEach(f=>{if(f(dt))busy=true});GL.forEach(g=>{try{drawG(g)}catch(err){if(!frame.warned){frame.warned=1;console.error('[backdrop-glass]',err)}}});if(busy)raf=requestAnimationFrame(frame);else{raf=0;frame.l=0}}
const rel=(el,pr)=>{const r=el.getBoundingClientRect();return[r.left-pr.left,r.top-pr.top,r.width,r.height]};
/* desenha uma camada (canvas src na posição P, em px css) no espaço local do elemento, compensando o layerBlock (LayerBackdrop.inverseTransform) */
function layerDraw(x,c,src,P,sd){const{q,X,Ch,bw,bh}=c,k=1/sd;x.save();x.translate(bw/2,bh/2);x.scale(q,q);x.scale(1/X.sx,1/X.sy);x.rotate(-X.rot);x.translate(P[0]-Ch[0]-X.tx,P[1]-Ch[1]-X.ty);x.scale(k,k);
let inv;try{inv=x.getTransform().inverse()}catch(err){x.restore();return}const xs=[],ys=[];for(const[u,v]of[[0,0],[bw,0],[bw,bh],[0,bh]]){const t=inv.transformPoint({x:u,y:v});xs.push(t.x);ys.push(t.y)}
const x0=Math.max(0,Math.floor(Math.min(...xs))-1),y0=Math.max(0,Math.floor(Math.min(...ys))-1),x1=Math.min(src.width,Math.ceil(Math.max(...xs))+1),y1=Math.min(src.height,Math.ceil(Math.max(...ys))+1);
if(x1>x0&&y1>y0)x.drawImage(src,x0,y0,x1-x0,y1-y0,x0,y0,x1-x0,y1-y0);x.restore()}
/* backdrops (Backdrop.kt) */
const BDsolid=col=>(x,c)=>{x.fillStyle=col;x.fillRect(0,0,c.bw,c.bh)};
const BDscene=st=>(x,c)=>{if(st.cv.width)layerDraw(x,c,st.cv,[0,0],st.cv.width/Math.max(1,st.root.clientWidth))};
const BDlayer=(g2,own)=>(x,c)=>{const cv=own||g2.ex||g2.cv;if(!cv||!cv.width||!g2.hr)return;const hr=g2.hr(c.pr),X=g2.X||I0;layerDraw(x,c,cv,[hr[0]-PD+X.tx,hr[1]-PD+X.ty],cv.width/(hr[2]+2*PD))};
const BDel=(el,pg)=>(x,c)=>{const r=rel(el,c.pr);if(el.width)layerDraw(x,c,el,[r[0],r[1]],el.width/Math.max(1,r[2]))};
const BDcomb=(...b)=>(x,c)=>b.forEach(f=>f(x,c));
const BDwrap=(f,tf)=>(x,c)=>{x.save();tf(x,c);f(x,c);x.restore()};
/* gl(): drawBackdrop(backdrop, shape, effects, highlight, shadow, innerShadow, layerBlock, exportedBackdrop, onDrawSurface...) */
function gl(st,host,o){const cv=h('canvas','',`position:absolute;left:${-PD}px;top:${-PD}px;pointer-events:none;width:0;height:0;z-index:-1`);host.style.isolation='isolate';host.prepend(cv);const g={host,cv,o,bk:document.createElement('canvas'),st,X:I0,hr:pr=>rel(host,pr)};GL.add(g);st._gl.push(g);return g}
function drawG(g){const o=g.o,hr=g.host.getBoundingClientRect(),pr=g.st.root.getBoundingClientRect(),W=hr.width,H=hr.height;if(W<2||H<2||!g.st.ready||(o.skip&&o.skip()))return;
if(hr.bottom<pr.top-80||hr.top>pr.bottom+80||hr.right<pr.left-80||hr.left>pr.right+80)return;
GE=getEngine();const dp=DPR(),X=g.X=o.xf?o.xf(g,W,H):I0,S=typeof o.smax=='function'?o.smax():(o.smax||1),q=dp*S,f=o.fx(g,W,H,q);
if(f.mode==null)f.mode=f.lens&&f.lens[0]>0&&f.lens[1]>0?(f.lens[2]?2:1):0;let pad=0;if(f.cf&&f.blur>0)pad=f.blur;if(f.lens&&f.lens[0]>0&&f.lens[1]>0&&pad>0)pad=Math.max(pad-f.lens[0],0);if(f.mode>2)pad=0;pad=Math.round(pad);
const cw=Math.round((W+2*PD)*q),ch=Math.round((H+2*PD)*q),bw=Math.round(W*q)+2*pad,bh=Math.round(H*q)+2*pad,{cv,bk}=g;
if(bk.width!=bw||bk.height!=bh){bk.width=bw;bk.height=bh}if(cv.width!=cw||cv.height!=ch){cv.width=cw;cv.height=ch;cv.style.width=W+2*PD+'px';cv.style.height=H+2*PD+'px'}
const x=bk.getContext('2d'),c={q,bw,bh,X,pr,Ch:[hr.left-pr.left+W/2,hr.top-pr.top+H/2],pad};x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,bw,bh);o.bg(x,c);
if(o.after)o.after(g,bk);
const rcss=f.rad/q,circ=Math.abs(W-H)<.5&&rcss>=Math.min(W,H)/2-.01,shp=f.rad>0&&!circ?g2shape(W,H,rcss,q):null;
const job=(extra)=>{GE.draw({bk,cw,ch,ex:PD*q,ey:PD*q,w:W*q,h:H*q,bo:pad,shp,...f,...extra});};
job();const t=cv.getContext('2d');t.setTransform(1,0,0,1,0,0);t.clearRect(0,0,cw,ch);t.drawImage(GE.cv,0,GE.cap[1]-ch,cw,ch,0,0,cw,ch);
if(o.exp){job({hi:null,sh:null,is:null});const e=g.ex||(g.ex=document.createElement('canvas'));if(e.width!=cw||e.height!=ch){e.width=cw;e.height=ch}const y=e.getContext('2d');y.clearRect(0,0,cw,ch);y.drawImage(GE.cv,0,GE.cap[1]-ch,cw,ch,0,0,cw,ch)}
if(o.ov){t.save();t.beginPath();t.roundRect(PD*q,PD*q,W*q,H*q,f.rad);t.clip();t.globalCompositeOperation='lighter';o.ov(t,g,W,H,q);t.restore()}
if(o.post)o.post(t,g,W,H,q);
const tf=`translate(${X.tx}px,${X.ty}px) rotate(${X.rot}rad) scale(${X.sx},${X.sy})`;cv.style.transform=tf;
if(o.dom)for(const k of g.host.children)if(k!==cv){k.style.transformOrigin=(W/2-k.offsetLeft)+'px '+(H/2-k.offsetTop)+'px';k.style.transform=tf}}
const drawAll=()=>GL.forEach(g=>drawG(g));
/* ---- InteractiveHighlight ---- */
function IH(st,host,onTap){const pp=new Sp(0,.5,300,.001),px=new Sp(0,.5,300,.5),py=new Sp(0,.5,300,.5),s={pp,px,py,sx:0,sy:0,down:0},pos=e=>{const r=host.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
host.addEventListener('pointerdown',e=>{[s.sx,s.sy]=pos(e);px.snap(s.sx);py.snap(s.sy);pp.t=1;s.down=1;wake();
const mv=ev=>{const[a,b]=pos(ev);px.snap(a);py.snap(b);wake()},up=()=>{s.down=0;pp.t=0;px.t=s.sx;py.t=s.sy;removeEventListener('pointermove',mv);removeEventListener('pointerup',up);removeEventListener('pointercancel',up);wake()};
addEventListener('pointermove',mv);addEventListener('pointerup',up);addEventListener('pointercancel',up)});
if(onTap)host.addEventListener('click',onTap);const f=dt=>{pp.step(dt);px.step(dt);py.step(dt);return s.down||!(pp.rest&&px.rest&&py.rest)};SP.add(f);st._sp.push(f);return s}
const pov=(pp,pos)=>(t,g,W,H,q)=>{const p=pp.x;if(p<=.001)return;const X=PD*q;t.fillStyle=`rgba(255,255,255,${.08*p})`;t.fillRect(X,X,W*q,H*q);const[cx,cy]=pos(W,H),R=Math.min(W,H)*1.5*q,x=X+cl(cx,0,W)*q,y=X+cl(cy,0,H)*q,r=t.createRadialGradient(x,y,0,x,y,R),a=.15*p;r.addColorStop(0,`rgba(255,255,255,${a})`);r.addColorStop(.5,`rgba(255,255,255,${a})`);r.addColorStop(.75,`rgba(255,255,255,${a*.5})`);r.addColorStop(1,'rgba(255,255,255,0)');t.fillStyle=r;t.fillRect(X,X,W*q,H*q)};
const bxf=ih=>(g,W,H)=>{const p=ih.pp.x,s=lerp(1,1+4/H,p),mo=Math.min(W,H),mx=Math.max(W,H),ox=ih.px.x-ih.sx,oy=ih.py.x-ih.sy,an=Math.atan2(oy,ox),md=4/H;return{tx:mo*Math.tanh(.05*ox/mo),ty:mo*Math.tanh(.05*oy/mo),sx:s+md*Math.abs(Math.cos(an)*ox/mx)*Math.min(W/H,1),sy:s+md*Math.abs(Math.sin(an)*oy/mx)*Math.min(H/W,1),rot:0}};
const hiD=q=>({m:1,w:.73*q,b:.25*q,a:1}),hiP=q=>({m:3,w:.73*q,b:.25*q,a:1}),shD=q=>({r:24*q,ox:0,oy:4*q,a:.1});
