/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Public API layer. The component behaviours follow the catalog of Kyant0/AndroidLiquidGlass
 * (Apache-2.0, Copyright 2025 Kyant) - see NOTICE.
 */
const DEFAULT_FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

/** true when the browser can run the effects (WebGL2 + canvas 2D). */
function supported() {
  try {
    return !!document.createElement('canvas').getContext('webgl2');
  } catch (e) {
    return false;
  }
}

let rgbaCtx = null;
/** any CSS colour (or [r,g,b(,a)] in 0..1) -> [r,g,b,a] in 0..1 */
function toRGBA(c) {
  if (Array.isArray(c)) return c.length === 3 ? [c[0], c[1], c[2], 1] : c;
  const x = rgbaCtx || (rgbaCtx = document.createElement('canvas').getContext('2d', { willReadFrequently: true }));
  x.canvas.width = x.canvas.height = 1;
  x.clearRect(0, 0, 1, 1);
  x.fillStyle = '#000';
  x.fillStyle = c;
  x.fillRect(0, 0, 1, 1);
  const d = x.getImageData(0, 0, 1, 1).data;
  return [d[0] / 255, d[1] / 255, d[2] / 255, d[3] / 255];
}

/**
 * A Stage owns one background (the "backdrop") painted on a canvas that fills `root`, and every glass element
 * created through it refracts / blurs that background. Put the elements you want to turn into glass inside `root`.
 *
 * @param {HTMLElement} root  container (becomes position:relative if static)
 * @param {object} [options]
 * @param {string|HTMLImageElement|HTMLCanvasElement|ImageBitmap|function(CanvasRenderingContext2D,number,number,number)} [options.background]
 *        image URL / image-like object (drawn "cover") or a draw function (ctx, widthPx, heightPx, dpr). Default: BackdropGlass.backgrounds.aurora
 * @param {number|function():number} [options.blur]  pre-blur of an image background, in css px
 * @param {number[]|function():number[]} [options.dim]  [r,g,b,a] (0..1) overlay painted over the background (it is part of the backdrop)
 * @param {function} [options.extra]  (ctx,w,h,dpr) extra drawing on top of background+dim (also part of the backdrop)
 * @param {boolean|function():boolean} [options.dark]  force light/dark theme (default: prefers-color-scheme)
 * @param {string} [options.accent]  accent colour used by sliders / tabs
 * @param {string} [options.font]  CSS font-family used by tabs
 */
class Stage {
  constructor(root, o = {}) {
    if (!root) throw new Error('Stage: root element required');
    this.root = root;
    this.o = o;
    this._gl = [];
    this._sp = [];
    this._tm = [];
    this.ready = false;
    if (getComputedStyle(root).position === 'static') root.style.position = 'relative';
    root.style.isolation = 'isolate';
    this.cv = document.createElement('canvas');
    this.cv.setAttribute('aria-hidden', 'true');
    this.cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none';
    root.prepend(this.cv);
    this.font = o.font || DEFAULT_FONT;
    this.setBackground(o.background === undefined ? aurora : o.background);
    this._ro = new ResizeObserver(() => this.redraw());
    this._ro.observe(root);
  }

  /** replace the background (same accepted types as the `background` option) */
  setBackground(b) {
    this._src = null;
    this.ready = false;
    if (typeof b === 'string') {
      const im = new Image();
      im.crossOrigin = 'anonymous';
      im.onload = () => { this._src = im; this.redraw(); };
      im.src = b;
    } else {
      this._src = b;
      this.redraw();
    }
  }

  /** repaint the background (call after changing blur/dim/extra, or when you draw a custom background) */
  redraw() {
    const W = this.root.clientWidth, H = this.root.clientHeight, dp = DPR(), b = this._src, o = this.o;
    if (!W || !H || !b) return;
    const w = Math.round(W * dp), hh = Math.round(H * dp), cv = this.cv;
    if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
    const x = cv.getContext('2d'), val = (v) => (typeof v === 'function' ? v() : v);
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.clearRect(0, 0, w, hh);
    const bl = val(o.blur) || 0, m = bl * dp * 2;
    if (typeof b === 'function') {
      if (bl > 0 && 'filter' in x) {
        const t = this._tmp || (this._tmp = document.createElement('canvas'));
        if (t.width !== w || t.height !== hh) { t.width = w; t.height = hh; }
        const tx = t.getContext('2d');
        tx.setTransform(1, 0, 0, 1, 0, 0);
        tx.clearRect(0, 0, w, hh);
        b(tx, w, hh, dp);
        x.save();
        x.filter = 'blur(' + bl * dp + 'px)';
        x.drawImage(t, -m, -m, w + 2 * m, hh + 2 * m);
        x.restore();
      } else {
        b(x, w, hh, dp);
      }
    } else {
      const iw = b.naturalWidth || b.videoWidth || b.width, ih = b.naturalHeight || b.videoHeight || b.height;
      if (!iw || !ih) return;
      const k = Math.max((w + 2 * m) / iw, (hh + 2 * m) / ih);
      x.save();
      if (bl > 0 && 'filter' in x) x.filter = 'blur(' + bl * dp + 'px)';
      x.drawImage(b, (w - iw * k) / 2, (hh - ih * k) / 2, iw * k, ih * k);
      x.restore();
    }
    const d = val(o.dim);
    if (d) {
      x.fillStyle = 'rgba(' + Math.round(d[0] * 255) + ',' + Math.round(d[1] * 255) + ',' + Math.round(d[2] * 255) + ',' + d[3] + ')';
      x.fillRect(0, 0, w, hh);
    }
    if (o.extra) o.extra(x, w, hh, dp);
    this.ready = true;
    wake(60);
  }

  /** request a few animation frames (call after you move/resize glass elements yourself, e.g. on scroll) */
  wake(ms) { wake(ms || 120); }

  dark() {
    const d = this.o.dark;
    return typeof d === 'function' ? !!d() : d !== undefined ? !!d : matchMedia('(prefers-color-scheme: dark)').matches;
  }
  accent() { return this.o.accent || (this.dark() ? '#0091ff' : '#0088ff'); }
  fg() { return this.dark() ? '#fff' : '#000'; }
  container(a) { return this.dark() ? [18 / 255, 18 / 255, 18 / 255, a] : [250 / 255, 250 / 255, 250 / 255, a]; }

  /** (advanced) low-level glass element, same as the catalog's drawBackdrop(...). See docs/API.md */
  gl(host, o) { return gl(this, host, o); }
  IH(host, onTap) { return IH(this, host, onTap); }
  bdScene() { return BDscene(this); }
  _backdrop(b) {
    if (b === undefined || b === null || b === 'scene') return BDscene(this);
    if (typeof b === 'string') return BDsolid(b);
    if (typeof b === 'function') return b;
    if (b.cv && b.hr) return BDlayer(b);
    return BDscene(this);
  }
  _step(f) { SP.add(f); this._sp.push(f); wake(); return f; }
  /** register an animation stepper: f(dtSeconds) -> true while it still needs frames */
  step(f) { return this._step(f); }
  timer(fn, ms) { const id = setInterval(fn, ms); this._tm.push(id); return id; }
  /** upload an SDF texture for the "sdf" effect (see BackdropGlass.sdf.fromText) */
  setSdfTexture(src) { getEngine().setSdf(src); wake(100); }

  /**
   * Turns `el` into a glass surface (declarative form of the catalog's drawBackdrop).
   * @param {HTMLElement} el
   * @param {object} [o]
   * @param {'capsule'|'rect'|number|{radius:number}} [o.shape='capsule']  corner radius in css px (G2 continuous corners)
   * @param {boolean} [o.vibrancy]  saturation boost (vibrancy())
   * @param {{saturation?:number,contrast?:number,brightness?:number}} [o.colorControls]
   * @param {number} [o.blur]  blur radius (css px)
   * @param {{height?:number,amount?:number,depth?:boolean,chromatic?:boolean}} [o.lens]  refraction (css px)
   * @param {string|number[]} [o.surface]  colour painted over the glass (e.g. 'rgba(255,255,255,.3)')
   * @param {string|number[]} [o.tint]  hue-blend tint like LiquidButton's (alpha .75)
   * @param {'default'|'plain'|'ambient'|false} [o.highlight='default']
   * @param {boolean|{radius?:number,offset?:number[],alpha?:number}} [o.shadow=true]
   * @param {false|{radius?:number,offset?:number[],alpha?:number}} [o.innerShadow=false]
   * @param {boolean} [o.interactive]  press scale + light, like LiquidButton (children are transformed with it)
   * @param {function} [o.onClick]
   * @param {string|HTMLElement|function|object} [o.backdrop='scene']  'scene' | css colour | draw fn | another glass handle created with exportBackdrop
   * @param {boolean} [o.exportBackdrop]  make this glass usable as the `backdrop` of other elements
   * @returns the glass handle ({destroy()})
   */
  glass(el, o = {}) {
    const shape = o.shape === undefined ? 'capsule' : o.shape;
    const hl = o.highlight === undefined ? 'default' : o.highlight;
    const sh = o.shadow === undefined ? true : o.shadow;
    const surface = o.surface ? toRGBA(o.surface) : null, tint = o.tint ? toRGBA(o.tint) : null;
    const lens = o.lens ? { height: 24, amount: 24, depth: false, chromatic: false, ...o.lens } : null;
    const cc = o.colorControls ? { saturation: 1, contrast: 1, brightness: 0, ...o.colorControls } : null;
    const ih = o.interactive ? this.IH(el, o.onClick) : null;
    if (!ih && o.onClick) el.addEventListener('click', o.onClick);
    const g = this.gl(el, {
      bg: this._backdrop(o.backdrop), dom: ih ? 1 : 0, smax: ih ? 1.12 : 1, exp: o.exportBackdrop ? 1 : 0,
      fx: (gg, W, H, q) => {
        const m = Math.min(W, H);
        const r = shape === 'capsule' ? m / 2 : shape === 'rect' ? 0 : Math.min(typeof shape === 'number' ? shape : shape.radius || 0, W / 2, H / 2);
        const f = { rad: r * q };
        if (cc) f.cf = [cc.saturation, cc.contrast, cc.brightness]; else if (o.vibrancy) f.cf = VIB;
        if (o.blur) f.blur = o.blur * q;
        if (lens) f.lens = [lens.height * q, lens.amount * q, lens.chromatic ? 1 : 0, lens.depth ? 1 : 0];
        if (tint) { f.t1 = [tint[0], tint[1], tint[2], .75]; f.hue = true; if (surface) f.t2 = surface; } else if (surface) f.t1 = surface;
        if (hl === 'default') f.hi = hiD(q); else if (hl === 'plain') f.hi = hiP(q);
        else if (hl === 'ambient') f.hi = { m: 2, w: .36 * q, b: .25 / 1.5 * q, a: 1 };
        if (f.hi && o.highlightAngle !== undefined) f.hi.angle = o.highlightAngle;
        if (f.hi && o.highlightFalloff !== undefined) f.hi.falloff = o.highlightFalloff;
        if (sh) { const s = sh === true ? {} : sh, rr = s.radius === undefined ? 24 : s.radius; f.sh = { r: rr * q, ox: (s.offset ? s.offset[0] : 0) * q, oy: (s.offset ? s.offset[1] : rr / 6) * q, a: s.alpha === undefined ? .1 : s.alpha }; }
        if (o.innerShadow) { const s = o.innerShadow, rr = s.radius === undefined ? 24 : s.radius; f.is = { r: rr * q, ox: (s.offset ? s.offset[0] : 0) * q, oy: (s.offset ? s.offset[1] : rr) * q, a: s.alpha === undefined ? .15 : s.alpha }; }
        return f;
      },
      xf: ih ? bxf(ih) : undefined, ov: ih ? pov(ih.pp, () => [ih.px.x, ih.py.x]) : undefined,
    });
    g.destroy = () => { GL.delete(g); g.cv.remove(); };
    return g;
  }

  /** LiquidButton. `content`: text or a DOM node. Options: tint, surface, color, onClick, style, backdrop. Returns the element. */
  button(content, o = {}) {
    return makeButton(this, content, { ...o, tint: o.tint ? toRGBA(o.tint).slice(0, 3) : null, backdrop: o.backdrop ? this._backdrop(o.backdrop) : undefined });
  }

  /** LiquidToggle. Options: checked, onChange(bool), backdrop. Returns the element (el.checked, el.setChecked(v)). */
  toggle(o = {}) {
    let on = !!o.checked;
    const el = makeToggle(this, this._backdrop(o.backdrop), () => on, (v) => { on = v; if (o.onChange) o.onChange(v); });
    el.setChecked = (v) => { on = !!v; el.sync(); };
    Object.defineProperty(el, 'checked', { get: () => on });
    return el;
  }

  /** LiquidSlider (fills the width of its parent). Options: value, min, max, onChange(value), backdrop. Returns the element (el.value, el.setValue(v)). */
  slider(o = {}) {
    const min = o.min === undefined ? 0 : o.min, max = o.max === undefined ? 1 : o.max;
    let v = cl(o.value === undefined ? min : o.value, min, max);
    const el = makeSlider(this, this._backdrop(o.backdrop), () => v, (x) => { v = x; if (o.onChange) o.onChange(x); }, min, max, (max - min) * .001);
    el.setValue = (x) => { v = cl(x, min, max); el.sync(); };
    Object.defineProperty(el, 'value', { get: () => v });
    return el;
  }

  /** LiquidBottomTabs. Options: items [{label, icon:{path,w,h}}], selected, onChange(index), style. Returns the element (el.select(i)). */
  tabs(o = {}) {
    return makeTabs(this, o);
  }

  /** remove everything this stage created */
  destroy() {
    this._gl.forEach((g) => { GL.delete(g); g.cv.remove(); });
    this._sp.forEach((f) => SP.delete(f));
    this._tm.forEach(clearInterval);
    this._ro.disconnect();
    this.cv.remove();
  }
}
