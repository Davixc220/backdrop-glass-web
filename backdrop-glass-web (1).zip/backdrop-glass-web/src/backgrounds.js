/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 * Original artwork: procedural background, no third-party image is bundled.
 */

/**
 * Built-in procedural background ("aurora"): hard-edged translucent discs, light bands and fine grain.
 * It has sharp edges and gradients on purpose, so refraction is easy to see.
 * Signature = a Stage `background` function: (ctx, widthPx, heightPx, devicePixelRatio).
 */
function aurora(x, w, h, dp) {
  const s = Math.max(w, h);
  const g = x.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, '#c9fbff');
  g.addColorStop(0.4, '#5adbe8');
  g.addColorStop(0.75, '#2c7ce6');
  g.addColorStop(1, '#122aa8');
  x.fillStyle = g;
  x.fillRect(0, 0, w, h);
  const disc = (cx, cy, r, c0, c1, ring) => {
    const rg = x.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
    rg.addColorStop(0, c0);
    rg.addColorStop(1, c1);
    x.fillStyle = rg;
    x.beginPath();
    x.arc(cx, cy, r, 0, Math.PI * 2);
    x.fill();
    x.lineWidth = 2 * dp;
    x.strokeStyle = 'rgba(255,255,255,' + ring + ')';
    x.stroke();
  };
  disc(w * 0.16, h * 0.28, s * 0.34, '#5ff0d2', '#10a48f', 0.55);
  disc(w * 0.9, h * 0.2, s * 0.3, '#4aa1ff', '#0b3ec4', 0.5);
  disc(w * 0.55, h * 0.74, s * 0.42, '#35e0cf', '#0a8fb5', 0.55);
  disc(w * 0.04, h * 0.94, s * 0.3, '#bdfdf0', '#4ad3e6', 0.5);
  disc(w * 0.96, h * 0.9, s * 0.26, '#2a59e8', '#0a1f86', 0.5);
  x.save();
  x.globalCompositeOperation = 'soft-light';
  for (let i = 0; i < 7; i++) {
    x.save();
    x.translate(w * (0.05 + i * 0.16), h * 0.5);
    x.rotate(-0.55);
    x.fillStyle = 'rgba(255,255,255,' + (0.22 + (i % 3) * 0.08) + ')';
    x.fillRect(-s * 0.03, -s, s * (0.04 + (i % 2) * 0.03), s * 2);
    x.restore();
  }
  x.restore();
  let seed = 7;
  const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
  const n = Math.min(5000, Math.floor((w * h) / 300));
  for (let i = 0; i < n; i++) {
    x.fillStyle = 'rgba(255,255,255,' + (0.03 + rnd() * 0.07) + ')';
    x.fillRect(rnd() * w, rnd() * h, dp, dp);
  }
}
