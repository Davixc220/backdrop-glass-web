# Third-party notices

The code of this repository is licensed under the Apache License 2.0 (see `LICENSE`). It contains or follows the
work of the projects below.

## Kyant0/AndroidLiquidGlass and Kyant0/Shapes - Apache License 2.0
Copyright 2025 Kyant. See `NOTICE`. The full license text is in `LICENSE`.

## Oklab colour space - MIT
`src/util.js` (`lerpC`) uses the Oklab transform to interpolate colours like Jetpack Compose's `lerp(Color, Color)`.
Oklab was designed by Bjorn Ottosson - https://bottosson.github.io/posts/oklab/

> Copyright (c) 2021 Bjorn Ottosson
>
> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
> to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
> CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.

## Mapbox TinySDF - ISC License
The euclidean distance transform in `src/sdf.js` (`edt1d`, `edt`) implements the Felzenszwalb & Huttenlocher
algorithm and its structure is adapted from TinySDF - https://github.com/mapbox/tiny-sdf

> ISC License
>
> Copyright (c) 2016, Mapbox
>
> Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby
> granted, provided that the above copyright notice and this permission notice appear in all copies.
>
> THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING
> ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
> DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
> WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE
> OR PERFORMANCE OF THIS SOFTWARE.

## Other references (no code copied)
Non-separable "Hue" blend mode formulas follow the W3C *Compositing and Blending Level 1* specification.
