# Legal notes

> This file explains the choices made to keep the repository safe to publish. It is **not legal advice**; if you
> need certainty for a commercial product, ask a lawyer.

## What is in this repository, and under which licence

| Part | Origin | Licence |
|---|---|---|
| `src/shaders.js` (generated), pipeline, components, G2 shapes | port of Kyant0/AndroidLiquidGlass and Kyant0/Shapes | Apache-2.0, Copyright 2025 Kyant (kept in `NOTICE`) |
| `src/stage.js`, `src/backgrounds.js`, `src/sdf.js`, demo, examples, tools | original | Apache-2.0 |
| `src/sdf.js` distance transform | adapted from Mapbox TinySDF | ISC (see `THIRD_PARTY_NOTICES.md`) |
| Oklab constants | Bjorn Ottosson | MIT (see `THIRD_PARTY_NOTICES.md`) |

Apache-2.0 allows use, modification and redistribution (including commercial) as long as you keep the licence,
keep the `NOTICE`, and mark files you changed (section 4). Do not remove the credits to Kyant.

## What is intentionally NOT included

* **Apple's SF Pro fonts and SF Symbols.** They are proprietary Apple assets whose licence only allows specific uses
  (for example mock-ups / apps for Apple platforms) and does not allow redistributing them inside a web project.
  The demo therefore uses the visitor's own system fonts (`system-ui`, which is SF on Apple devices) and a small set
  of original icons. Do **not** add SF font files or SF Symbol SVGs to this repository or to forks.
* **The wallpaper and the clock SDF texture of the upstream Android catalog app.** Their provenance is not
  documented upstream, so they were not copied. The demo paints a procedural background (`backgrounds.aurora`) and
  generates its SDF texture at runtime (`sdf.fromText`).
* **Any third-party image, font or icon file.** `tools/audit.mjs` fails if a font file, a large embedded binary or
  known proprietary asset names show up in the repository.

## Trademarks

Apple, iOS, macOS, SF Pro, SF Symbols and Liquid Glass are trademarks or product names of Apple Inc. Android is a
trademark of Google LLC. This project is an independent open-source work, is not affiliated with or endorsed by
Apple, Google or Kyant, and uses those names only to describe what the effects resemble. Do not present the
project as an official Apple/Android/Kyant product.

## If you publish a fork or use it in a product

* Keep `LICENSE`, `NOTICE` and `THIRD_PARTY_NOTICES.md` with your distribution.
* Mark files you changed ("Modified by ..."), as Apache-2.0 requires.
* Use only fonts/icons/images you have the right to use. Link to fonts the visitor already has instead of embedding
  fonts you cannot redistribute.
