/*! Backdrop Glass Web v1.0.0 | Apache-2.0 | WebGL2 port of Kyant0/AndroidLiquidGlass (Apache-2.0, Copyright 2025 Kyant) - see NOTICE */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BackdropGlass = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';
/*
 * GENERATED FILE - do not edit by hand.  Regenerate with:
 *     python3 tools/extract_shaders.py /path/to/AndroidLiquidGlass
 *
 * GLSL ES 3.00 translation of the AGSL shaders of Kyant0/AndroidLiquidGlass
 *   (backdrop/.../internal/Shaders.kt and app/.../catalog/utils/SdfShader.kt)
 *   https://github.com/Kyant0/AndroidLiquidGlass
 * Original work: Copyright 2025 Kyant - Licensed under the Apache License, Version 2.0.
 * Modifications: translated from AGSL to GLSL ES 3.00 (type names, `content.eval()` replaced by a
 * texture lookup, entry points renamed, uniforms hoisted). See NOTICE and tools/extract_shaders.py.
 */
const KT = {
  "sdf": "\nfloat radiusAt(vec2 coord, vec4 radii) {\n    if (coord.x >= 0.0) {\n        if (coord.y <= 0.0) return radii.y;\n        else return radii.z;\n    } else {\n        if (coord.y <= 0.0) return radii.x;\n        else return radii.w;\n    }\n}\n\nfloat sdRoundedRect(vec2 coord, vec2 halfSize, float radius) {\n    vec2 cornerCoord = abs(coord) - (halfSize - vec2(radius));\n    float outside = length(max(cornerCoord, 0.0)) - radius;\n    float inside = min(max(cornerCoord.x, cornerCoord.y), 0.0);\n    return outside + inside;\n}\n\nvec2 gradSdRoundedRect(vec2 coord, vec2 halfSize, float radius) {\n    vec2 cornerCoord = abs(coord) - (halfSize - vec2(radius));\n    if (cornerCoord.x >= 0.0 || cornerCoord.y >= 0.0) {\n        return sign(coord) * normalize(max(cornerCoord, 0.0));\n    } else {\n        float gradX = step(cornerCoord.y, cornerCoord.x);\n        return sign(coord) * vec2(gradX, 1.0 - gradX);\n    }\n}\n",
  "circle": "float circleMap(float x) {\n    return 1.0 - sqrt(1.0 - x * x);\n}\n",
  "lens": "\n\nvec4 lensMain(vec2 coord) {\n    vec2 halfSize = size * 0.5;\n    vec2 centeredCoord = (coord + offset) - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n    if (-sd >= refractionHeight) {\n        return cEval(coord);\n    }\n    sd = min(sd, 0.0);\n    \n    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;\n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    vec2 grad = normalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius) + depthEffect * normalize(centeredCoord));\n    \n    vec2 refractedCoord = coord + d * grad;\n    return cEval(refractedCoord);\n}",
  "lensD": "\nvec4 lensDMain(vec2 coord) {\n    vec2 halfSize = size * 0.5;\n    vec2 centeredCoord = (coord + offset) - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float sd = sdRoundedRect(centeredCoord, halfSize, radius);\n    if (-sd >= refractionHeight) {\n        return cEval(coord);\n    }\n    sd = min(sd, 0.0);\n    \n    float d = circleMap(1.0 - -sd / refractionHeight) * refractionAmount;\n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    vec2 grad = normalize(gradSdRoundedRect(centeredCoord, halfSize, gradRadius) + depthEffect * normalize(centeredCoord));\n    \n    vec2 refractedCoord = coord + d * grad;\n    float dispersionIntensity = chromaticAberration * ((centeredCoord.x * centeredCoord.y) / (halfSize.x * halfSize.y));\n    vec2 dispersedCoord = d * grad * dispersionIntensity;\n    \n    vec4 color = vec4(0.0);\n    \n    vec4 red = cEval(refractedCoord + dispersedCoord);\n    color.r += red.r / 3.5;\n    color.a += red.a / 7.0;\n    \n    vec4 orange = cEval(refractedCoord + dispersedCoord * (2.0 / 3.0));\n    color.r += orange.r / 3.5;\n    color.g += orange.g / 7.0;\n    color.a += orange.a / 7.0;\n    \n    vec4 yellow = cEval(refractedCoord + dispersedCoord * (1.0 / 3.0));\n    color.r += yellow.r / 3.5;\n    color.g += yellow.g / 3.5;\n    color.a += yellow.a / 7.0;\n    \n    vec4 green = cEval(refractedCoord);\n    color.g += green.g / 3.5;\n    color.a += green.a / 7.0;\n    \n    vec4 cyan = cEval(refractedCoord - dispersedCoord * (1.0 / 3.0));\n    color.g += cyan.g / 3.5;\n    color.b += cyan.b / 3.0;\n    color.a += cyan.a / 7.0;\n    \n    vec4 blue = cEval(refractedCoord - dispersedCoord * (2.0 / 3.0));\n    color.b += blue.b / 3.0;\n    color.a += blue.a / 7.0;\n    \n    vec4 purple = cEval(refractedCoord - dispersedCoord);\n    color.r += purple.r / 7.0;\n    color.b += purple.b / 3.0;\n    color.a += purple.a / 7.0;\n    \n    return color;\n}",
  "hiD": "\nvec4 hiDMain(vec2 coord) {\n    vec2 halfSize = size * 0.5;\n    vec2 centeredCoord = coord - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    vec2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n    vec2 normal = vec2(cos(angle), sin(angle));\n    float d = dot(grad, normal);\n    float intensity = pow(abs(d), falloff);\n    return color * intensity;\n}",
  "hiA": "\nvec4 hiAMain(vec2 coord) {\n    vec2 halfSize = size * 0.5;\n    vec2 centeredCoord = coord - halfSize;\n    float radius = radiusAt(coord, cornerRadii);\n    \n    float gradRadius = min(radius * 1.5, min(halfSize.x, halfSize.y));\n    vec2 grad = gradSdRoundedRect(centeredCoord, halfSize, gradRadius);\n    vec2 normal = vec2(cos(angle), sin(angle));\n    float d = dot(grad, normal);\n    float intensity = pow(abs(d), falloff);\n    float t = step(0.0, d);\n    return vec4(t, t, t, 1.0) * intensity;\n}",
  "sdfs": "\nvec4 sdfMain(vec2 coord) {\n    vec2 p = coord / size * sdfTexSize;\n    if (p.x < 0.0 || p.y < 0.0 || p.x >= sdfTexSize.x || p.y >= sdfTexSize.y) {\n        return vec4(0.0);\n    }\n    vec4 v = sdfEval(p);\n    float sd = v.r * 2.0 - 1.0;\n    v.a = smoothstep(0.5, 1.0, v.a);\n    if (v.a <= 0.0) {\n        return vec4(0.0);\n    }\n    if (v.a < 1.0) {\n        sd = 0.0;\n    }\n    vec2 normal = normalize(v.gb * 2.0 - 1.0);\n    \n    float intensity = circleMap(1.0 - min(1.0, -sd * 1.5));\n    vec2 refractedCoord = coord - intensity * refractionHeight * normal;\n\n    vec4 color = cEval(refractedCoord) * v.a;\n    vec2 lightDir = vec2(cos(lightAngle * 3.1415926 / 180.0), sin(lightAngle * 3.1415926 / 180.0));\n    float bevelIntensity = clamp(dot(normal, lightDir), 0.0, 1.0);\n    color.rgb *= 1.0 + 0.5 * intensity * bevelIntensity;\n    bevelIntensity = clamp(dot(normal, -lightDir), 0.0, 1.0);\n    color.rgb *= 1.0 + 0.5 * bevelIntensity * min(1.0, (1.0 - smoothstep(0.0, 1.0, abs(intensity - 0.25) * 6.0)));\n    return color;\n}",
  "uni": "uniform vec2 size;\nuniform vec2 offset;\nuniform vec4 cornerRadii;\nuniform float refractionHeight;\nuniform float refractionAmount;\nuniform float depthEffect;\nuniform float chromaticAberration;\nuniform vec4 color;\nuniform float angle;\nuniform float falloff;\nuniform vec2 sdfTexSize;\nuniform float lightAngle;\n"
};

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Springs (spring(dampingRatio, stiffness)) and DampedDragAnimation follow the catalog of Kyant0/AndroidLiquidGlass.
 * Colour lerp uses the Oklab colour space (Bjorn Ottosson, MIT - see THIRD_PARTY_NOTICES.md), like Compose.
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
const NS='http://www.w3.org/2000/svg',PD=32,I0={sx:1,sy:1,tx:0,ty:0,rot:0};
const cl=(x,a,b)=>Math.min(b,Math.max(a,x)),lerp=(a,b,t)=>a+(b-a)*t,DPR=()=>Math.min(2,devicePixelRatio||1);
const h=(t,c,s,...k)=>{const e=document.createElement(t);if(c)e.className=c;if(s)e.style.cssText=s;e.append(...k);return e};
/* lerp de cor em Oklab, igual ao androidx.compose.ui.graphics.lerp */
const s2l=c=>c<=.04045?c/12.92:Math.pow((c+.055)/1.055,2.4),l2s=c=>c<=.0031308?c*12.92:1.055*Math.pow(c,1/2.4)-.055;
const toLab=([r,g,b])=>{r=s2l(r);g=s2l(g);b=s2l(b);const l=Math.cbrt(.4122214708*r+.5363325363*g+.0514459929*b),m=Math.cbrt(.2119034982*r+.6806995451*g+.1073969566*b),s=Math.cbrt(.0883024619*r+.2817188376*g+.6299787005*b);return[.2104542553*l+.793617785*m-.0040720468*s,1.9779984951*l-2.428592205*m+.4505937099*s,.0259040371*l+.7827717662*m-.808675766*s]};
const fromLab=([L,a,b])=>{const l=Math.pow(L+.3963377774*a+.2158037573*b,3),m=Math.pow(L-.1055613458*a-.0638541728*b,3),s=Math.pow(L-.0894841775*a-1.291485548*b,3);return[l2s(4.0767416621*l-3.3077115913*m+.2309699292*s),l2s(-1.2684380046*l+2.6097574011*m-.3413193965*s),l2s(-.0041960863*l-.7034186147*m+1.707614701*s)]};
const lerpC=(A,B,t)=>{const a=toLab(A),b=toLab(B),c=fromLab(a.map((v,i)=>lerp(v,b[i],t)));return'rgba('+c.map(v=>Math.round(cl(v,0,1)*255)).join(',')+','+lerp(A[3],B[3],t)+')'};
/* ---- molas (spring(dampingRatio, stiffness, threshold) do Compose) e DampedDragAnimation ---- */
class Sp{constructor(x,z,k,th){this.x=x;this.v=0;this.t=x;this.z=z;this.k=k;this.th=th}
step(dt){const c=2*this.z*Math.sqrt(this.k);let n=Math.max(1,Math.ceil(dt/.004));const q=dt/n;while(n--){this.v+=(this.k*(this.t-this.x)-c*this.v)*q;this.x+=this.v*q}}
snap(v){this.x=this.t=v;this.v=0}get rest(){return Math.abs(this.x-this.t)<this.th&&Math.abs(this.v)<this.th*10}}
class DDA{constructor(v0,min,max,th,ps){this.min=min;this.max=max;this.ps=ps||1.5;this.val=new Sp(v0,1,1000,th);this.vel=new Sp(0,.5,300,th*10);this.pr=new Sp(0,1,1000,.001);this.sx=new Sp(1,.6,250,.001);this.sy=new Sp(1,.7,250,.001);this.last=v0;this.rel=false}
get progress(){return(this.val.x-this.min)/(this.max-this.min)}get target(){return this.val.t}
press(){this.rel=false;this.pr.t=1;this.sx.t=this.sy.t=this.ps}release(){this.rel=true}
update(v){this.val.t=cl(v,this.min,this.max)}animateTo(v){this.press();this.update(v);this.rel=true}
step(dt){this.val.step(dt);const iv=(this.val.x-this.last)/Math.max(dt,1e-3)/(this.max-this.min);this.last=this.val.x;this.vel.t=Math.abs(iv)<1e-3?0:iv;this.vel.step(dt);this.pr.step(dt);this.sx.step(dt);this.sy.step(dt);
if(this.rel&&Math.abs(this.val.x-this.val.t)<(this.max-this.min)*.025){this.rel=false;this.pr.t=0;this.sx.t=this.sy.t=1}}
get rest(){return[this.val,this.vel,this.pr,this.sx,this.sy].every(s=>s.rest)}}

/* easing: CubicBezierEasing(x1, y1, x2, y2) do Compose (EaseIn = .42,0,1,1 / EaseOut = 0,0,.58,1) */
const bez=(x1,y1,x2,y2)=>x=>{let lo=0,hi=1,t=x;for(let i=0;i<24;i++){const b=3*(1-t)*(1-t)*t*x1+3*(1-t)*t*t*x2+t*t*t;if(b<x)lo=t;else hi=t;t=(lo+hi)/2}return 3*(1-t)*(1-t)*t*y1+3*(1-t)*t*t*y2+t*t*t},easeOut=bez(0,0,.58,1),easeIn=bez(.42,0,1,1);

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * G2 (curvature-continuous) rounded rectangles and capsules: port of ContinuousCurvatureRoundedRectangleCornerBuilder
 * Original work: Kyant0/Shapes (https://github.com/Kyant0/Shapes), author Kyant0, Apache License 2.0.
 * This file was MODIFIED from the original: ported from Kotlin to JavaScript.
 */
/* Capsule()/RoundedRectangle() of Kyant0/Shapes (Apache-2.0) are G2 shapes; the corner Bezier construction is ported 1:1. */
/* ===== Shapes do Kyant0: Capsule()/RoundedRectangle() com cantos G2 (curvatura contínua), porte de ContinuousCurvatureRoundedRectangleCornerBuilder ===== */
const G2K=(()=>{const R2=Math.SQRT2,R2i=Math.SQRT1_2,th=(1-.5)*Math.PI/4,cs=Math.cos(th),sn=Math.sin(th),ct=1/Math.tan(th),cs2=cs*cs,sn2=sn*sn,cs3=cs2*cs,sn3=sn2*sn,E=2/3;
const k0=27*(R2-6*cs+6*R2*cs2-4*cs3)*ct+2*sn*(-9+2*(R2-2*sn)*sn3+2*R2*cs*(9+sn2)-2*cs2*(9+2*sn2)),k1=-81*(-2+R2+4*(-1+R2)*cs+2*(-2+R2)*cs2)*ct-4*sn*(-9+9*R2+R2*sn3+(-2+R2)*cs*(9+sn2)),k2=9*(9*(-4+3*R2+(-6+4*R2)*cs)*ct+(-6+4*R2)*sn),k3=27*(10-7*R2)*ct;
const cubic=(a,b,c,d)=>{const f=((3*c/a)-(b*b)/(a*a))/3,g=((2*b*b*b)/(a*a*a)-(9*b*c)/(a*a)+(27*d)/a)/27,s=Math.sqrt(g*g/4+f*f*f/27);return Math.cbrt(-g/2+s)+Math.cbrt(-g/2-s)-b/(3*a)};
const quartic=(p,q,r)=>{const b=-p/2,c=-r,d=r*p/2-q*q/8,f=((3*c)-(b*b))/3,g=((2*b*b*b)-(9*b*c)+(27*d))/27,rr=Math.sqrt(-f*f*f/27),phi=Math.acos(-g/(2*rr)),y=2*Math.sqrt(-f/3)*Math.cos(phi/3),z=y-b/3,u=Math.sqrt(2*z-p);return(u-Math.sqrt(u*u-4*(z+q/(2*u))))/2};
const even=t=>{const k=E*t,ka=cubic(k3,k2,k1+8*(-k)*sn3*sn,k0),x3=R2i+(-R2i+sn)/ka,y3=1-R2i+(R2i-cs)/ka,x2=x3-y3*ct,x1=x2-1.5*ka*y3*y3/sn3,x0=-k,x6=1-y3,y6=1-x3,y7=1-x2,y8=1-x1,y9=1-x0,a=1.5*ka,g=cs2-sn2,x36=x6-x3,y36=y6-y3,c=-(cs*y36-sn*x36),la=(-g+Math.sqrt(g*g-4*a*c))/(2*a),x4=x3+la*cs,y4=y3+la*sn,x5=x6-la*sn,y5=y6-la*cs;return[x0,0,x1,0,x2,0,x3,y3,x4,y4,x5,y5,x6,y6,1,y7,1,y8,1,y9]};
const uneven=(tH,tV)=>{const kH=E*tH,kV=E*tV,ka3=cubic(k3,k2,k1+8*(-kH)*sn3*sn,k0),ka6=cubic(k3,k2,k1+8*(-kV)*sn3*sn,k0),x3=R2i+(-R2i+sn)/ka3,y3=1-R2i+(R2i-cs)/ka3,x2=x3-y3*ct,x1=x2-1.5*ka3*y3*y3/sn3,x0=-kH,x3p=R2i+(-R2i+sn)/ka6,y3p=1-R2i+(R2i-cs)/ka6,x2p=x3p-y3p*ct,x1p=x2p-1.5*ka6*y3p*y3p/sn3,x0p=-kV,
x6=1-y3p,y6=1-x3p,y7=1-x2p,y8=1-x1p,y9=1-x0p,a=1.5*ka3,b=1.5*ka6,g=cs2-sn2,x36=x6-x3,y36=y6-y3,c=-(cs*y36-sn*x36),d=sn*y36-cs*x36,pp=2*(d/b),qq=g*g*g/(a*b*b),rr=(a*d*d+c*g*g)/(a*b*b),l6=quartic(pp,qq,rr),l3=(-d-b*l6*l6)/g,x4=x3+l3*cs,y4=y3+l3*sn,x5=x6-l6*sn,y5=y6-l6*cs;return[x0,0,x1,0,x2,0,x3,y3,x4,y4,x5,y5,x6,y6,1,y7,1,y8,1,y9]};
const pts=(a,b)=>a===b?even(a):uneven(a,b);
function path(w,h,r,p=new Path2D()){const tW=Math.min(1,Math.max(0,(w*.5-r)/r)),tH=Math.min(1,Math.max(0,(h*.5-r)/r)),P=pts(tW,tH);if(P.length<20||P.some(v=>!isFinite(v))){p.roundRect(0,0,w,h,r);return p}
let x=w-r,y=0;p.moveTo(x+P[0]*r,y+P[1]*r);p.bezierCurveTo(x+P[2]*r,y+P[3]*r,x+P[4]*r,y+P[5]*r,x+P[6]*r,y+P[7]*r);p.bezierCurveTo(x+P[8]*r,y+P[9]*r,x+P[10]*r,y+P[11]*r,x+P[12]*r,y+P[13]*r);p.bezierCurveTo(x+P[14]*r,y+P[15]*r,x+P[16]*r,y+P[17]*r,x+P[18]*r,y+P[19]*r);
x=w-r;y=h;p.lineTo(x+P[18]*r,y-P[19]*r);p.bezierCurveTo(x+P[16]*r,y-P[17]*r,x+P[14]*r,y-P[15]*r,x+P[12]*r,y-P[13]*r);p.bezierCurveTo(x+P[10]*r,y-P[11]*r,x+P[8]*r,y-P[9]*r,x+P[6]*r,y-P[7]*r);p.bezierCurveTo(x+P[4]*r,y-P[5]*r,x+P[2]*r,y-P[3]*r,x+P[0]*r,y-P[1]*r);
x=r;y=h;p.lineTo(x-P[0]*r,y-P[1]*r);p.bezierCurveTo(x-P[2]*r,y-P[3]*r,x-P[4]*r,y-P[5]*r,x-P[6]*r,y-P[7]*r);p.bezierCurveTo(x-P[8]*r,y-P[9]*r,x-P[10]*r,y-P[11]*r,x-P[12]*r,y-P[13]*r);p.bezierCurveTo(x-P[14]*r,y-P[15]*r,x-P[16]*r,y-P[17]*r,x-P[18]*r,y-P[19]*r);
x=r;y=0;p.lineTo(x-P[18]*r,y+P[19]*r);p.bezierCurveTo(x-P[16]*r,y+P[17]*r,x-P[14]*r,y+P[15]*r,x-P[12]*r,y+P[13]*r);p.bezierCurveTo(x-P[10]*r,y+P[11]*r,x-P[8]*r,y+P[9]*r,x-P[6]*r,y+P[7]*r);p.bezierCurveTo(x-P[4]*r,y+P[5]*r,x-P[2]*r,y+P[3]*r,x-P[0]*r,y+P[1]*r);p.closePath();return p}
function quad(w,h,r){const cl01=v=>Math.min(1,Math.max(0,v)),P=pts(cl01((w*.5-r)/r),cl01((h*.5-r)/r));if(P.length<20||P.some(v=>!isFinite(v)))return null;const hw=w/2,hh=h/2,ax=hw-r,pt=i=>[ax+P[i]*r,hh-P[i+1]*r],o=[[0,hh],pt(0)];
for(let c=0;c<3;c++){const b0=pt(c*6),b1=pt(c*6+2),b2=pt(c*6+4),b3=pt(c*6+6);for(let s=1;s<=8;s++){const t=s/8,u=1-t;o.push([u*u*u*b0[0]+3*u*u*t*b1[0]+3*u*t*t*b2[0]+t*t*t*b3[0],u*u*u*b0[1]+3*u*u*t*b1[1]+3*u*t*t*b2[1]+t*t*t*b3[1]])}}o.push([hw,0]);return Float32Array.from(o.flat())}
const svg=(w,h,r)=>{const s={d:'',moveTo(x,y){this.d+='M'+x.toFixed(2)+' '+y.toFixed(2)},lineTo(x,y){this.d+='L'+x.toFixed(2)+' '+y.toFixed(2)},bezierCurveTo(...v){this.d+='C'+v.map(n=>n.toFixed(2)).join(' ')},closePath(){this.d+='Z'},roundRect(){}};path(w,h,r,s);return s.d};
return{path,quad,svg}})();
function g2clip(el,r){const f=()=>{const w=el.offsetWidth,hh=el.offsetHeight;if(w>1&&hh>1)el.style.clipPath='path("'+G2K.svg(w,hh,Math.min(r,w/2,hh/2))+'")'};new ResizeObserver(f).observe(el);f()}
const G2C=new Map();function g2shape(W,H,r,q){const k=W.toFixed(2)+'x'+H.toFixed(2)+'r'+r.toFixed(2);let p=G2C.get(k);if(p===undefined){if(G2C.size>300)G2C.clear();p=G2K.quad(W,H,r);G2C.set(k,p)}return p?{q,pts:p}:null}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * WebGL2 version of the backdrop effect pipeline of Kyant0/AndroidLiquidGlass:
 * colorFilter -> blur -> lens | sdf | alpha mask -> surface -> highlight -> inner shadow, plus the outer shadow.
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- shaders ---- */
const HD='#version 300 es\nprecision highp float;\n',VS='#version 300 es\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0,1);}';
/* colorFilter (vibrancy/colorControls) + blur gaussiano separável; textura de capacidade fixa, clamp no tamanho lógico (TileMode.Clamp) */
const FS_B=HD+`uniform sampler2D t;uniform vec2 dir,uBS,uTS;uniform float sig,uCF;uniform mat3 uM;uniform vec3 uK;out vec4 o;
vec3 S(vec2 p){vec3 c=texture(t,clamp(p,vec2(.5),uBS-.5)/uTS).rgb;return uCF>.5?clamp(uM*c+uK,0.,1.):c;}
void main(){vec2 p=gl_FragCoord.xy;if(sig<.05){o=vec4(S(p),1);return;}
float R=ceil(sig*3.),st=max(1.,R/12.),ws=0.;vec3 a=vec3(0);
for(float x=-R;x<=R;x+=st){float w=exp(-.5*x*x/(sig*sig));a+=S(p+dir*x)*w;ws+=w;}o=vec4(a/ws,1);}`;
/* elemento: efeito (lens/dispersão/sdf/máscara alfa) -> surface -> highlight -> inner shadow, e shadow por fora (ordem do DrawBackdropModifier) */
const FS_E=HD+`uniform sampler2D uBack,uSdf;uniform vec4 uShp;uniform vec2 uQ[27];uniform vec2 uBS,uTS,uCS,uPos;uniform float uBO,uMode,uHue;uniform vec4 uT1,uT2,uHi,uSh,uIs,uAM;
${KT.uni}
vec4 cEval(vec2 p){return texture(uBack,clamp(p,vec2(.5),uBS-.5)/uTS);}
vec4 sdfEval(vec2 p){return texture(uSdf,p/sdfTexSize);}
${KT.sdf}${KT.circle}${KT.lens}${KT.lensD}${KT.hiD}${KT.hiA}${KT.sdfs}
vec4 amMain(vec2 coord){float a=1.-smoothstep(size.y*.5,size.y,coord.y);return mix(cEval(coord)*a,vec4(uAM.rgb,1.)*a,uAM.w);}
float lum(vec3 c){return dot(c,vec3(.3,.59,.11));}
vec3 clipC(vec3 c){float l=lum(c),n=min(c.r,min(c.g,c.b)),x=max(c.r,max(c.g,c.b));if(n<0.)c=l+(c-l)*l/(l-n);if(x>1.)c=l+(c-l)*(1.-l)/(x-l);return c;}
vec3 setLum(vec3 c,float l){return clipC(c+(l-lum(c)));}
float satOf(vec3 c){return max(c.r,max(c.g,c.b))-min(c.r,min(c.g,c.b));}
vec3 setSat(vec3 c,float s){float mn=min(c.r,min(c.g,c.b)),mx=max(c.r,max(c.g,c.b));return mx>mn?(c-mn)*s/(mx-mn):vec3(0);}
out vec4 o;float ph(float x){return .5+.5*tanh(clamp(.85*x,-12.,12.));}
float sdG(vec2 pc){vec2 p=abs(pc);float mx=-1e9,dm=1e9;for(int i=0;i<26;i++){vec2 A=uQ[i],d=uQ[i+1]-A,ap=p-A;float l2=dot(d,d);if(l2<1e-8)continue;mx=max(mx,dot(ap,vec2(-d.y,d.x))/sqrt(l2));dm=min(dm,length(ap-d*clamp(dot(ap,d)/l2,0.,1.)));}return mx>0.?dm:mx;}
float sdAt(vec2 p,vec2 hs,float rd){return uShp.x>.5?sdG((p-uPos-hs)/uShp.y)*uShp.y:sdRoundedRect(p-uPos-hs,hs,rd);}
float rA(vec2 q,vec4 r){return q.x>=0.?(q.y<=0.?r.y:r.z):(q.y<=0.?r.x:r.w);}
void main(){vec2 px=vec2(gl_FragCoord.x,uCS.y-gl_FragCoord.y),c=px-uPos,hs=size*.5,cc=c-hs,bo=vec2(uBO);
float rd=rA(cc,cornerRadii),sd=sdAt(px,hs,rd),a0=1.-smoothstep(-.5,.5,sd);vec4 res=vec4(0);
if(a0>0.){vec4 b;
if(uMode<.5)b=vec4(cEval(c+bo).rgb,1.);else if(uMode<1.5)b=lensMain(c+bo);else if(uMode<2.5)b=lensDMain(c+bo);else if(uMode<3.5)b=sdfMain(c+bo);else b=amMain(c+bo);
if(uMode<2.5){vec3 col=b.rgb;if(uHue>.5)col=setLum(setSat(uT1.rgb,satOf(col)),lum(col));col=mix(col,uT1.rgb,uT1.a);col=mix(col,uT2.rgb,uT2.a);
if(uHi.x>.5){float d=max(-sd,0.),w=uHi.y,s=max(uHi.z,.001),k=(ph((d+w)/s)-ph((d-w)/s))*uHi.w;
if(uHi.x>2.5)col=min(col+vec3(.38*k),1.);else if(uHi.x<1.5)col=min(col+hiDMain(c).rgb*.5*k,1.);else{vec4 hh=hiAMain(c)*.38*k;col=hh.rgb+col*(1.-hh.a);}}
if(uIs.w>0.){float s=max(uIs.x,.001);col*=1.-uIs.w*ph(-sd/s)*(1.-ph(-sdAt(px-uIs.yz,hs,rd)/s));}
res=vec4(col,1.);}else res=b;}
float sA=0.;if(uSh.w>0.&&a0<1.)sA=uSh.w*ph(-sdAt(px-uSh.yz,hs,rd)/max(uSh.x,.001));
float ra=res.a*a0;o=vec4(res.rgb*a0,ra+sA*(1.-ra));}`;
const sgm=r=>r>0?.57735*r+.5:0;                       /* BlurMaskFilter(radius) do Android: sigma = 0.57735*r + 0.5 */
class Eng{
constructor(){const cv=document.createElement('canvas');cv.width=cv.height=8;const g=this.g=cv.getContext('webgl2',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true,depth:false,stencil:false});this.cv=cv;this.cap=[0,0];this.ul=new Map();
this.pB=this.prog(FS_B);this.pE=this.prog(FS_E);this.t0=this.tex();this.tA=this.tex();this.tB=this.tex();this.ts=this.tex();g.texImage2D(g.TEXTURE_2D,0,g.RGBA,1,1,0,g.RGBA,g.UNSIGNED_BYTE,new Uint8Array(4));this.fb=g.createFramebuffer();this.hasSdf=0;}
prog(fs){const g=this.g,p=g.createProgram();for(const[t,s]of[[g.VERTEX_SHADER,VS],[g.FRAGMENT_SHADER,fs]]){const x=g.createShader(t);g.shaderSource(x,s);g.compileShader(x);if(!g.getShaderParameter(x,g.COMPILE_STATUS))console.error(g.getShaderInfoLog(x));g.attachShader(p,x)}g.linkProgram(p);return p}
tex(){const g=this.g,t=g.createTexture();g.bindTexture(g.TEXTURE_2D,t);[[g.TEXTURE_MIN_FILTER,g.LINEAR],[g.TEXTURE_MAG_FILTER,g.LINEAR],[g.TEXTURE_WRAP_S,g.CLAMP_TO_EDGE],[g.TEXTURE_WRAP_T,g.CLAMP_TO_EDGE]].forEach(([a,b])=>g.texParameteri(g.TEXTURE_2D,a,b));return t}
setSdf(bmp){const g=this.g;if(bmp&&bmp.data){g.bindTexture(g.TEXTURE_2D,this.ts);g.pixelStorei(g.UNPACK_ALIGNMENT,1);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,bmp.width,bmp.height,0,g.RGBA,g.UNSIGNED_BYTE,bmp.data);g.pixelStorei(g.UNPACK_ALIGNMENT,4);this.hasSdf=1;return}g.bindTexture(g.TEXTURE_2D,this.ts);g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL,false);g.pixelStorei(g.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);g.pixelStorei(g.UNPACK_COLORSPACE_CONVERSION_WEBGL,g.NONE);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,g.RGBA,g.UNSIGNED_BYTE,bmp);g.pixelStorei(g.UNPACK_COLORSPACE_CONVERSION_WEBGL,g.BROWSER_DEFAULT_WEBGL);this.hasSdf=1}
ensure(w,hh){if(w<=this.cap[0]&&hh<=this.cap[1])return;const g=this.g,W=Math.max(this.cap[0],Math.ceil(w/128)*128),H=Math.max(this.cap[1],Math.ceil(hh/128)*128);this.cap=[W,H];this.cv.width=W;this.cv.height=H;[this.t0,this.tA,this.tB].forEach(t=>{g.bindTexture(g.TEXTURE_2D,t);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,W,H,0,g.RGBA,g.UNSIGNED_BYTE,null)})}
use(p){this.g.useProgram(p);this.cur=p}
L(n){let m=this.ul.get(this.cur);if(!m)this.ul.set(this.cur,m={});return n in m?m[n]:(m[n]=this.g.getUniformLocation(this.cur,n))}
u(n,...v){const l=this.L(n);if(l===null)return;const g=this.g;if(n=='t'||n=='uBack'||n=='uSdf')g.uniform1i(l,v[0]);else g['uniform'+v.length+'f'](l,...v)}
pass(src,dst,W,H){const g=this.g;g.bindFramebuffer(g.FRAMEBUFFER,this.fb);g.framebufferTexture2D(g.FRAMEBUFFER,g.COLOR_ATTACHMENT0,g.TEXTURE_2D,dst,0);g.viewport(0,0,W,H);g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,src);g.drawArrays(g.TRIANGLES,0,3)}
/* o: {bk,cw,ch,ex,ey,w,h,bo,rad,cf:[sat,con,bri],blur,mode,lens,t1,t2,hue,hi,sh,is,am,sdf} — tudo em px de dispositivo/raster */
draw(o){const g=this.g,BW=o.bk.width,BH=o.bk.height,CW=o.cw,CH=o.ch;this.ensure(Math.max(CW,BW),Math.max(CH,BH));const TS=this.cap;
g.disable(g.BLEND);g.disable(g.SCISSOR_TEST);g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL,false);g.pixelStorei(g.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);
g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,this.t0);g.texSubImage2D(g.TEXTURE_2D,0,0,0,g.RGBA,g.UNSIGNED_BYTE,o.bk);
let T=this.t0;const cf=o.cf,sg=o.blur||0;
if(cf||sg>=.05){this.use(this.pB);this.u('uBS',BW,BH);this.u('uTS',TS[0],TS[1]);this.u('t',0);
if(cf){const[s,c,b]=cf,iv=1-s,r=.213*iv,gg=.715*iv,bb=.072*iv,k=.5-c*.5+b,M=[c*r+c*s,c*r,c*r,c*gg,c*gg+c*s,c*gg,c*bb,c*bb,c*bb+c*s];g.uniformMatrix3fv(this.L('uM'),false,M);this.u('uK',k,k,k);this.u('uCF',1)}else this.u('uCF',0);
this.u('dir',1,0);this.u('sig',sg);this.pass(this.t0,this.tA,BW,BH);T=this.tA;
if(sg>=.05){this.u('uCF',0);this.u('dir',0,1);this.pass(this.tA,this.tB,BW,BH);T=this.tB}}
g.bindFramebuffer(g.FRAMEBUFFER,null);g.viewport(0,0,CW,CH);g.enable(g.SCISSOR_TEST);g.scissor(0,0,CW,CH);g.clearColor(0,0,0,0);g.clear(g.COLOR_BUFFER_BIT);g.disable(g.SCISSOR_TEST);
this.use(this.pE);g.activeTexture(g.TEXTURE0);g.bindTexture(g.TEXTURE_2D,T);g.activeTexture(g.TEXTURE1);g.bindTexture(g.TEXTURE_2D,this.ts);g.activeTexture(g.TEXTURE0);
this.u('uBack',0);this.u('uSdf',1);const sp=o.shp;if(sp){this.u('uShp',1,sp.q,0,0);g.uniform2fv(this.L('uQ'),sp.pts)}else this.u('uShp',0,1,0,0);this.u('uBS',BW,BH);this.u('uTS',TS[0],TS[1]);this.u('uCS',CW,CH);this.u('uPos',o.ex,o.ey);this.u('uBO',o.bo||0);
this.u('size',o.w,o.h);this.u('offset',-(o.bo||0),-(o.bo||0));this.u('cornerRadii',o.rad,o.rad,o.rad,o.rad);
const mode=o.mode||0,L=o.lens;this.u('uMode',mode);
if(mode==1||mode==2){this.u('refractionHeight',L[0]);this.u('refractionAmount',-L[1]);this.u('depthEffect',L[3]?1:0);this.u('chromaticAberration',1)}
if(mode==3){this.u('refractionHeight',o.sdf.h);this.u('lightAngle',o.sdf.a);this.u('sdfTexSize',o.sdf.w,o.sdf.h2)}
const t1=o.t1||[0,0,0,0],t2=o.t2||[0,0,0,0],hi=o.hi,sh=o.sh,is=o.is,am=o.am||[0,0,0,0];
this.u('uT1',...t1);this.u('uT2',...t2);this.u('uHue',o.hue?1:0);this.u('uAM',...am);
this.u('uHi',hi?hi.m:0,hi?hi.w:0,hi?sgm(hi.b):0,hi?hi.a:0);this.u('color',1,1,1,1);this.u('angle',((hi&&hi.angle)??45)*Math.PI/180);this.u('falloff',(hi&&hi.falloff)||1);
this.u('uSh',sh?sgm(sh.r):0,sh?sh.ox:0,sh?sh.oy:0,sh?sh.a:0);this.u('uIs',is?is.r:0,is?is.ox:0,is?is.oy:0,is?is.a:0);
g.drawArrays(g.TRIANGLES,0,3)}}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Layer backdrops (LayerBackdrop/CombinedBackdrop), drawBackdrop (DrawBackdropModifier), InteractiveHighlight and the Liquid* defaults
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- infraestrutura de elementos de vidro ---- */
let GE=null,raf=0,until=0;const VIB=[1.5,1,0];function getEngine(){return GE||(GE=new Eng())}
const GL=new Set(),SP=new Set();
function wake(ms=0){until=Math.max(until,performance.now()+ms);if(!raf)raf=requestAnimationFrame(frame)}
function frame(t){const dt=Math.min(.033,(t-(frame.l||t))/1e3||.016);frame.l=t;let busy=performance.now()<until;SP.forEach(f=>{if(f(dt))busy=true});GL.forEach(g=>{try{drawG(g)}catch(err){if(!frame.warned){frame.warned=1;console.error('[backdrop-glass]',err)}}});if(busy)raf=requestAnimationFrame(frame);else{raf=0;frame.l=0}}
const rel=(el,pr)=>{const r=el.getBoundingClientRect();return[r.left-pr.left,r.top-pr.top,r.width,r.height]};
/* desenha uma camada (canvas src na posição P, em px css) no espaço local do elemento, compensando o layerBlock (LayerBackdrop.inverseTransform) */
function layerDraw(x,c,src,P,sd){const{q,X,Ch,bw,bh}=c,k=1/sd;x.save();x.translate(bw/2,bh/2);x.scale(q,q);x.scale(1/X.sx,1/X.sy);x.rotate(-X.rot);x.translate(P[0]-Ch[0]-X.tx,P[1]-Ch[1]-X.ty);x.scale(k,k);
let inv;try{inv=x.getTransform().inverse()}catch(err){x.restore();return}const xs=[],ys=[];for(const[u,v]of[[0,0],[bw,0],[bw,bh],[0,bh]]){const t=inv.transformPoint({x:u,y:v});xs.push(t.x);ys.push(t.y)}
const x0=Math.max(0,Math.floor(Math.min(...xs))-1),y0=Math.max(0,Math.floor(Math.min(...ys))-1),x1=Math.min(src.width,Math.ceil(Math.max(...xs))+1),y1=Math.min(src.height,Math.ceil(Math.max(...ys))+1);
if(x1>x0&&y1>y0)x.drawImage(src,x0,y0,x1-x0,y1-y0,x0,y0,x1-x0,y1-y0);x.restore()}
/* backdrops (Backdrop.kt) */
const BDsolid=col=>(x,c)=>{x.fillStyle=col;x.fillRect(0,0,c.bw,c.bh)};
const BDscene=st=>(x,c)=>{if(st.cv.width)layerDraw(x,c,st.cv,[0,0],st.cv.width/Math.max(1,st.root.clientWidth))};
const BDlayer=(g2,own)=>(x,c)=>{const cv=own||g2.ex||g2.cv;if(!cv||!cv.width||!g2.hr)return;const hr=g2.hr(c.pr),X=g2.X||I0;layerDraw(x,c,cv,[hr[0]-PD+X.tx,hr[1]-PD+X.ty],cv.width/(hr[2]+2*PD))};
const BDel=(el,pg)=>(x,c)=>{const r=rel(el,c.pr);if(el.width)layerDraw(x,c,el,[r[0],r[1]],el.width/Math.max(1,r[2]))};
const BDcomb=(...b)=>(x,c)=>b.forEach(f=>f(x,c));
const BDwrap=(f,tf)=>(x,c)=>{x.save();tf(x,c);f(x,c);x.restore()};
/* gl(): drawBackdrop(backdrop, shape, effects, highlight, shadow, innerShadow, layerBlock, exportedBackdrop, onDrawSurface...) */
function gl(st,host,o){const cv=h('canvas','',`position:absolute;left:${-PD}px;top:${-PD}px;pointer-events:none;width:0;height:0;z-index:-1`);host.style.isolation='isolate';host.prepend(cv);const g={host,cv,o,bk:document.createElement('canvas'),st,X:I0,hr:pr=>rel(host,pr)};GL.add(g);st._gl.push(g);return g}
function drawG(g){const o=g.o,hr=g.host.getBoundingClientRect(),pr=g.st.root.getBoundingClientRect(),W=hr.width,H=hr.height;if(W<2||H<2||!g.st.ready||(o.skip&&o.skip()))return;
if(hr.bottom<pr.top-80||hr.top>pr.bottom+80||hr.right<pr.left-80||hr.left>pr.right+80)return;
GE=getEngine();const dp=DPR(),X=g.X=o.xf?o.xf(g,W,H):I0,S=typeof o.smax=='function'?o.smax():(o.smax||1),q=dp*S,f=o.fx(g,W,H,q);
if(f.mode==null)f.mode=f.lens&&f.lens[0]>0&&f.lens[1]>0?(f.lens[2]?2:1):0;let pad=0;if(f.cf&&f.blur>0)pad=f.blur;if(f.lens&&f.lens[0]>0&&f.lens[1]>0&&pad>0)pad=Math.max(pad-f.lens[0],0);if(f.mode>2)pad=0;pad=Math.round(pad);
const cw=Math.round((W+2*PD)*q),ch=Math.round((H+2*PD)*q),bw=Math.round(W*q)+2*pad,bh=Math.round(H*q)+2*pad,{cv,bk}=g;
if(bk.width!=bw||bk.height!=bh){bk.width=bw;bk.height=bh}if(cv.width!=cw||cv.height!=ch){cv.width=cw;cv.height=ch;cv.style.width=W+2*PD+'px';cv.style.height=H+2*PD+'px'}
const x=bk.getContext('2d'),c={q,bw,bh,X,pr,Ch:[hr.left-pr.left+W/2,hr.top-pr.top+H/2],pad};x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,bw,bh);o.bg(x,c);
if(o.after)o.after(g,bk);
const rcss=f.rad/q,circ=Math.abs(W-H)<.5&&rcss>=Math.min(W,H)/2-.01,shp=f.rad>0&&!circ?g2shape(W,H,rcss,q):null;
const job=(extra)=>{GE.draw({bk,cw,ch,ex:PD*q,ey:PD*q,w:W*q,h:H*q,bo:pad,shp,...f,...extra});};
job();const t=cv.getContext('2d');t.setTransform(1,0,0,1,0,0);t.clearRect(0,0,cw,ch);t.drawImage(GE.cv,0,GE.cap[1]-ch,cw,ch,0,0,cw,ch);
if(o.exp){job({hi:null,sh:null,is:null});const e=g.ex||(g.ex=document.createElement('canvas'));if(e.width!=cw||e.height!=ch){e.width=cw;e.height=ch}const y=e.getContext('2d');y.clearRect(0,0,cw,ch);y.drawImage(GE.cv,0,GE.cap[1]-ch,cw,ch,0,0,cw,ch)}
if(o.ov){t.save();t.beginPath();t.roundRect(PD*q,PD*q,W*q,H*q,f.rad);t.clip();t.globalCompositeOperation='lighter';o.ov(t,g,W,H,q);t.restore()}
if(o.post)o.post(t,g,W,H,q);
const tf=`translate(${X.tx}px,${X.ty}px) rotate(${X.rot}rad) scale(${X.sx},${X.sy})`;cv.style.transform=tf;
if(o.dom)for(const k of g.host.children)if(k!==cv){k.style.transformOrigin=(W/2-k.offsetLeft)+'px '+(H/2-k.offsetTop)+'px';k.style.transform=tf}}
const drawAll=()=>GL.forEach(g=>drawG(g));
/* ---- InteractiveHighlight ---- */
function IH(st,host,onTap){const pp=new Sp(0,.5,300,.001),px=new Sp(0,.5,300,.5),py=new Sp(0,.5,300,.5),s={pp,px,py,sx:0,sy:0,down:0},pos=e=>{const r=host.getBoundingClientRect();return[e.clientX-r.left,e.clientY-r.top]};
host.addEventListener('pointerdown',e=>{[s.sx,s.sy]=pos(e);px.snap(s.sx);py.snap(s.sy);pp.t=1;s.down=1;wake();
const mv=ev=>{const[a,b]=pos(ev);px.snap(a);py.snap(b);wake()},up=()=>{s.down=0;pp.t=0;px.t=s.sx;py.t=s.sy;removeEventListener('pointermove',mv);removeEventListener('pointerup',up);removeEventListener('pointercancel',up);wake()};
addEventListener('pointermove',mv);addEventListener('pointerup',up);addEventListener('pointercancel',up)});
if(onTap)host.addEventListener('click',onTap);const f=dt=>{pp.step(dt);px.step(dt);py.step(dt);return s.down||!(pp.rest&&px.rest&&py.rest)};SP.add(f);st._sp.push(f);return s}
const pov=(pp,pos)=>(t,g,W,H,q)=>{const p=pp.x;if(p<=.001)return;const X=PD*q;t.fillStyle=`rgba(255,255,255,${.08*p})`;t.fillRect(X,X,W*q,H*q);const[cx,cy]=pos(W,H),R=Math.min(W,H)*1.5*q,x=X+cl(cx,0,W)*q,y=X+cl(cy,0,H)*q,r=t.createRadialGradient(x,y,0,x,y,R),a=.15*p;r.addColorStop(0,`rgba(255,255,255,${a})`);r.addColorStop(.5,`rgba(255,255,255,${a})`);r.addColorStop(.75,`rgba(255,255,255,${a*.5})`);r.addColorStop(1,'rgba(255,255,255,0)');t.fillStyle=r;t.fillRect(X,X,W*q,H*q)};
const bxf=ih=>(g,W,H)=>{const p=ih.pp.x,s=lerp(1,1+4/H,p),mo=Math.min(W,H),mx=Math.max(W,H),ox=ih.px.x-ih.sx,oy=ih.py.x-ih.sy,an=Math.atan2(oy,ox),md=4/H;return{tx:mo*Math.tanh(.05*ox/mo),ty:mo*Math.tanh(.05*oy/mo),sx:s+md*Math.abs(Math.cos(an)*ox/mx)*Math.min(W/H,1),sy:s+md*Math.abs(Math.sin(an)*oy/mx)*Math.min(H/W,1),rot:0}};
const hiD=q=>({m:1,w:.73*q,b:.25*q,a:1}),hiP=q=>({m:3,w:.73*q,b:.25*q,a:1}),shD=q=>({r:24*q,ox:0,oy:4*q,a:.1});

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Pan / pinch-zoom / rotate helpers (detectTransformGestures behaviour used by the catalog playground)
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* ---- gestos de transformação (detectTransformGestures) ---- */
function xform(el,T){const P=new Map(),c=p=>p.length?[p.reduce((a,b)=>a+b[0],0)/p.length,p.reduce((a,b)=>a+b[1],0)/p.length]:[0,0],ds=p=>p.length>1?Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]):1,an=p=>p.length>1?Math.atan2(p[1][1]-p[0][1],p[1][0]-p[0][0]):0;
el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);P.set(e.pointerId,[e.clientX,e.clientY]);wake()});
el.addEventListener('pointermove',e=>{if(!P.has(e.pointerId))return;const b=[...P.values()],cb=c(b),db=ds(b),ab=an(b);P.set(e.pointerId,[e.clientX,e.clientY]);const a=[...P.values()],ca=c(a);
if(a.length>1){T.z.snap(cl(T.z.x*ds(a)/(db||1),.2,6));T.r.snap(T.r.x+(an(a)-ab)*180/Math.PI)}T.x.snap(T.x.x+ca[0]-cb[0]);T.y.snap(T.y.x+ca[1]-cb[1]);wake()});
const up=e=>P.delete(e.pointerId);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
el.addEventListener('wheel',e=>{e.preventDefault();if(e.shiftKey)T.r.snap(T.r.x+e.deltaY*.2);else T.z.snap(cl(T.z.x*Math.exp(-e.deltaY*.0015),.2,6));wake()},{passive:false})}
const mkT=()=>({x:new Sp(0,1,1500,.5),y:new Sp(0,1,1500,.5),z:new Sp(1,1,1500,.001),r:new Sp(0,1,1500,.1)}),stepT=(T,dt)=>{for(const k in T)T[k].step(dt);return!Object.values(T).every(s=>s.rest)},xfT=T=>()=>({tx:T.x.x,ty:T.y.x,sx:T.z.x,sy:T.z.x,rot:T.r.x*Math.PI/180}),smaxT=T=>()=>Math.min(2.5,Math.max(1,Math.ceil(T.z.x*2)/2));
const hitSync=(hit,T)=>{hit.style.transform='translate('+T.x.x+'px,'+T.y.x+'px) rotate('+T.r.x+'deg) scale('+T.z.x+')'};

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Port of the catalog components LiquidButton, LiquidToggle, LiquidSlider and LiquidBottomTabs
 * Original work: Copyright 2025 Kyant, Apache License 2.0 (https://github.com/Kyant0/AndroidLiquidGlass).
 * This file was MODIFIED from the original: rewritten from Kotlin/Compose to JavaScript/WebGL2.
 */
/* LiquidButton (catalog/components/LiquidButton.kt): vibrancy + blur(2dp) + lens(12dp, 24dp), default highlight/shadow, press scale + interactive highlight */
const BTN_STYLE='position:relative;display:flex;align-items:center;justify-content:center;gap:8px;box-sizing:border-box;height:48px;padding:0 16px;font:400 15px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:none;width:max-content;';
function makeButton(st,content,o={}){const host=h('div','',BTN_STYLE+(o.style||''));
if(content instanceof Node)host.append(content);else if(content!==undefined&&content!==null&&content!=='')host.append(h('span','','pointer-events:none;color:'+(o.color||'#000'),String(content)));
const ih=IH(st,host,o.onClick);
gl(st,host,{bg:o.backdrop||BDscene(st),dom:1,smax:1.12,fx:(g,W,H,q)=>({rad:Math.min(W,H)/2*q,cf:VIB,blur:2*q,lens:[12*q,24*q,0,0],t1:o.tint?[...o.tint,.75]:o.surface?[1,1,1,.3]:null,hue:!!o.tint,hi:hiD(q),sh:shD(q)}),xf:bxf(ih),ov:pov(ih.pp,()=>[ih.px.x,ih.py.x])});return host}
/* icon spec: {path:'SVG path data (y down)', w, h} -> inline <svg> */
function iconSvg(ic,px){const v=document.createElementNS(NS,'svg'),p=document.createElementNS(NS,'path');v.setAttribute('viewBox','0 0 '+ic.w+' '+ic.h);p.setAttribute('d',ic.path);v.append(p);v.style.cssText='height:'+px+'px;width:auto;fill:currentColor;flex:none;display:block';return v}
/* ---- LiquidToggle ---- */
function makeToggle(st,bd,get,set){const w=h('div','','position:relative;width:64px;height:28px;flex:none;cursor:pointer;touch-action:none'),trk=h('canvas','','position:absolute;left:0;top:0;width:64px;height:28px'),th=h('div','','position:absolute;left:0;top:2px;width:40px;height:24px');w.append(trk,th);
let fr=get()?1:0,drag=0,down=0,lx=0;const d=new DDA(fr,0,1,.001),acc=st.dark()?[48/255,209/255,88/255,1]:[52/255,199/255,89/255,1],trc=st.dark()?[120/255,120/255,128/255,.36]:[120/255,120/255,120/255,.2];
const lay=()=>{th.style.left=lerp(2,22,d.val.x)+'px';const dp=DPR();if(trk.width!=64*dp){trk.width=64*dp;trk.height=28*dp}const x=trk.getContext('2d');x.setTransform(dp,0,0,dp,0,0);x.clearRect(0,0,64,28);x.fillStyle=lerpC(trc,acc,d.val.x);x.beginPath();x.roundRect(0,0,64,28,14);x.fill()};
gl(st,th,{bg:BDcomb(bd,BDwrap(BDel(trk),(x,c)=>{const p=d.pr.x;x.translate(c.bw/2,c.bh/2);x.scale(lerp(2/3,.75,p),lerp(0,.75,p));x.translate(-c.bw/2,-c.bh/2)})),smax:1.5,
fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,blur:8*q*(1-p),lens:[5*q*p,10*q*p,1,0],t1:[1,1,1,1-p],hi:{m:2,w:.36*q,b:.25/1.5*q,a:p},sh:{r:4*q,ox:0,oy:4/6*q,a:.05},is:{r:4*q*p,ox:0,oy:4*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/50;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
w.addEventListener('pointerdown',e=>{w.setPointerCapture(e.pointerId);down=1;drag=0;lx=e.clientX;d.press();wake()});
w.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-lx;lx=e.clientX;if(dx)drag=1;fr=cl(fr+dx/20,0,1);d.update(fr);wake()});
const up=()=>{if(!down)return;down=0;if(drag){fr=d.target>=.5?1:0;drag=0}else fr=get()?0:1;set(fr==1);d.update(fr);d.release();wake()};w.addEventListener('pointerup',up);w.addEventListener('pointercancel',up);
w.sync=()=>{const t=get()?1:0;if(t!=fr){fr=t;d.animateTo(t)}wake()};const f=dt=>{d.step(dt);lay();return down||!d.rest};st._step(f);lay();return w}
/* ---- LiquidSlider ---- */
function makeSlider(st,bd,get,set,min,max,vt){const w=h('div','','position:relative;width:100%;height:24px;cursor:pointer;touch-action:none'),trk=h('canvas','','position:absolute;left:0;top:9px;width:100%;height:6px'),th=h('div','','position:absolute;left:0;top:0;width:40px;height:24px');w.append(trk,th);
const d=new DDA(get(),min,max,vt),acc=st.accent(),trc=st.dark()?'rgba(120,120,128,.36)':'rgba(120,120,120,.2)',TW=()=>w.clientWidth||300;let down=0,drag=0,lx=0,tap=0;
const lay=()=>{const dp=DPR(),W=TW();th.style.left=cl(-20+W*d.progress,-10,W-30)+'px';if(trk.width!=Math.round(W*dp)){trk.width=Math.round(W*dp);trk.height=6*dp}const x=trk.getContext('2d');x.setTransform(dp,0,0,dp,0,0);x.clearRect(0,0,W,6);x.fillStyle=trc;x.beginPath();x.roundRect(0,0,W,6,3);x.fill();const aw=Math.round(W*d.progress);if(aw>0){x.fillStyle=acc;x.beginPath();x.roundRect(0,0,aw,6,Math.min(aw,6)/2);x.fill()}};
gl(st,th,{bg:BDcomb(bd,BDwrap(BDel(trk),(x,c)=>{const p=d.pr.x;x.translate(c.bw/2,c.bh/2);x.scale(lerp(2/3,1,p),lerp(0,1,p));x.translate(-c.bw/2,-c.bh/2)})),smax:1.5,
fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,blur:8*q*(1-p),lens:[10*q*p,14*q*p,1,0],t1:[1,1,1,1-p],hi:{m:2,w:.36*q,b:.25/1.5*q,a:p},sh:{r:4*q,ox:0,oy:4/6*q,a:.05},is:{r:4*q*p,ox:0,oy:4*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/10;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
w.addEventListener('pointerdown',e=>{w.setPointerCapture(e.pointerId);const r=w.getBoundingClientRect(),px=e.clientX-r.left,t=parseFloat(th.style.left)||0;tap=px<t||px>t+40;down=1;drag=0;lx=e.clientX;if(!tap)d.press();wake()});
w.addEventListener('pointermove',e=>{if(!down||tap)return;const dx=e.clientX-lx;lx=e.clientX;if(dx)drag=1;const v=cl(d.target+(max-min)*dx/TW(),min,max);d.update(v);set(v);wake()});
const up=e=>{if(!down)return;down=0;if(tap){const r=w.getBoundingClientRect(),v=cl(min+(max-min)*(e.clientX-r.left)/TW(),min,max);d.animateTo(v);set(v)}else d.release();wake()};w.addEventListener('pointerup',up);w.addEventListener('pointercancel',()=>{down=0;d.release()});
w.sync=()=>{const v=cl(get(),min,max);if(d.target!=v)d.update(v);wake()};const f=dt=>{d.step(dt);lay();return down||!d.rest};st._step(f);lay();return w}
/* ---- LiquidBottomTabs ---- */
function makeTabs(st,o){const items=o.items,n=items.length,font=st.font,bd=BDscene(st),host=h('div','','position:relative;height:64px;touch-action:none;user-select:none;-webkit-user-select:none;'+(o.style||'')),row=h('div','','position:absolute;inset:0;display:flex;padding:4px;pointer-events:none');
items.forEach(it=>row.append(h('div','','flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font:400 12px/14px '+font+';color:'+st.fg(),it.icon?iconSvg(it.icon,26):'',it.label||'')));
const bar=h('div','','position:absolute;inset:0',row),hid=h('div','','position:absolute;left:0;right:0;top:4px;height:56px;opacity:0;pointer-events:none'),pill=h('div','','position:absolute;top:4px;height:56px'),d=new DDA(o.selected||0,0,n-1,.001,78/56),off=new Sp(0,1,300,.5);host.append(bar,hid,pill);
const tw=()=>(host.clientWidth-8)/n,po=()=>{const f=cl(off.x/(host.clientWidth||1),-1,1);return 4*Math.sign(f)*easeOut(Math.abs(f))},lay=()=>{pill.style.width=tw()+'px';pill.style.left=4+d.val.x*tw()+po()+'px'},ih=IH(st,pill),pos=(W,H)=>[(d.val.x+.5)*tw()+po(),H/2];
gl(st,bar,{bg:bd,dom:1,smax:1.1,fx:(g,W,H,q)=>({rad:Math.min(W,H)/2*q,cf:VIB,blur:8*q,lens:[24*q,24*q,0,0],t1:st.container(.4),hi:hiD(q),sh:shD(q)}),xf:(g,W)=>{const s=lerp(1,1+16/W,d.pr.x);return{sx:s,sy:s,tx:po(),ty:0,rot:0}},ov:pov(ih.pp,pos)});
const gh=gl(st,hid,{bg:bd,fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,cf:VIB,blur:8*q,lens:[24*q*p,24*q*p,0,0],t1:st.container(.4),hi:{...hiD(q),a:p},sh:shD(q)}},xf:()=>({sx:1,sy:1,tx:po(),ty:0,rot:0}),ov:pov(ih.pp,pos),
post:(t,g,W,H,q)=>{const w=(W-8)/n,s=lerp(1,1.2,d.pr.x);t.fillStyle=st.accent();t.textAlign='center';t.textBaseline='middle';t.font='400 '+12*q+'px '+font;
for(let i=0;i<n;i++){t.save();t.translate((PD+4+w*(i+.5))*q,(PD+H/2)*q);t.scale(s,s);const ic=items[i].icon;if(ic){const k=26*q/ic.h;t.save();t.translate(-ic.w*k/2,-8.2*q-ic.h*k/2);t.scale(k,k);t.fill(new Path2D(ic.path));t.restore()}t.fillText(items[i].label||'',0,15*q);t.restore()}}});
gl(st,pill,{bg:BDcomb(bd,BDlayer(gh)),smax:1.4,fx:(g,W,H,q)=>{const p=d.pr.x;return{rad:Math.min(W,H)/2*q,lens:[10*q*p,14*q*p,1,0],t1:st.dark()?[1,1,1,.1*(1-p)]:[0,0,0,.1*(1-p)],t2:[0,0,0,.03*p],hi:{...hiD(q),a:p},sh:{r:24*q,ox:0,oy:4*q,a:.1*p},is:{r:8*q*p,ox:0,oy:8*q*p,a:.15*p}}},
xf:()=>{const v=d.vel.x/10;return{sx:d.sx.x/(1-cl(v*.75,-.2,.2)),sy:d.sy.x*(1-cl(v*.25,-.2,.2)),tx:0,ty:0,rot:0}}});
let down=0,onPill=0,lx=0,tap=-1;const f=dt=>{d.step(dt);off.step(dt);lay();return down||!d.rest||!off.rest};st._step(f);
host.addEventListener('pointerdown',e=>{host.setPointerCapture(e.pointerId);const r=host.getBoundingClientRect(),x=e.clientX-r.left,pl=4+d.val.x*tw()+po();down=1;lx=e.clientX;onPill=x>=pl&&x<=pl+tw();tap=onPill?-1:Math.floor((x-4)/tw());if(onPill)d.press();wake()});
host.addEventListener('pointermove',e=>{if(!down||!onPill)return;const dx=e.clientX-lx;lx=e.clientX;d.update(d.target+dx/tw());off.snap(off.x+dx);wake()});
const up=()=>{if(!down)return;down=0;if(onPill){const i=cl(Math.round(d.target),0,n-1);d.animateTo(i);off.t=0;o.onChange&&o.onChange(i)}else if(tap>=0&&tap<n){d.animateTo(tap);o.onChange&&o.onChange(tap)}wake()};host.addEventListener('pointerup',up);host.addEventListener('pointercancel',up);lay();host.select=i=>{d.animateTo(cl(i,0,n-1));wake()};return host}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 * Original artwork: procedural background, no third-party image is bundled.
 */

/**
 * Built-in procedural background ("aurora"): hard-edged translucent discs, light bands and fine grain.
 * It has sharp edges and gradients on purpose, so refraction is easy to see.
 * Signature = a Stage `background` function: (ctx, widthPx, heightPx, devicePixelRatio).
 */
function aurora(x, w, h, dp) {
  const s = Math.max(w, h);
  const g = x.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, '#c9fbff');
  g.addColorStop(0.4, '#5adbe8');
  g.addColorStop(0.75, '#2c7ce6');
  g.addColorStop(1, '#122aa8');
  x.fillStyle = g;
  x.fillRect(0, 0, w, h);
  const disc = (cx, cy, r, c0, c1, ring) => {
    const rg = x.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
    rg.addColorStop(0, c0);
    rg.addColorStop(1, c1);
    x.fillStyle = rg;
    x.beginPath();
    x.arc(cx, cy, r, 0, Math.PI * 2);
    x.fill();
    x.lineWidth = 2 * dp;
    x.strokeStyle = 'rgba(255,255,255,' + ring + ')';
    x.stroke();
  };
  disc(w * 0.16, h * 0.28, s * 0.34, '#5ff0d2', '#10a48f', 0.55);
  disc(w * 0.9, h * 0.2, s * 0.3, '#4aa1ff', '#0b3ec4', 0.5);
  disc(w * 0.55, h * 0.74, s * 0.42, '#35e0cf', '#0a8fb5', 0.55);
  disc(w * 0.04, h * 0.94, s * 0.3, '#bdfdf0', '#4ad3e6', 0.5);
  disc(w * 0.96, h * 0.9, s * 0.26, '#2a59e8', '#0a1f86', 0.5);
  x.save();
  x.globalCompositeOperation = 'soft-light';
  for (let i = 0; i < 7; i++) {
    x.save();
    x.translate(w * (0.05 + i * 0.16), h * 0.5);
    x.rotate(-0.55);
    x.fillStyle = 'rgba(255,255,255,' + (0.22 + (i % 3) * 0.08) + ')';
    x.fillRect(-s * 0.03, -s, s * (0.04 + (i % 2) * 0.03), s * 2);
    x.restore();
  }
  x.restore();
  let seed = 7;
  const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
  const n = Math.min(5000, Math.floor((w * h) / 300));
  for (let i = 0; i < n; i++) {
    x.fillStyle = 'rgba(255,255,255,' + (0.03 + rnd() * 0.07) + ')';
    x.fillRect(rnd() * w, rnd() * h, dp, dp);
  }
}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Runtime signed-distance-field texture generator for the "sdf" glass effect (the Lock screen clock of the
 * upstream catalog). The upstream catalog ships a pre-baked texture whose provenance is not documented, so
 * this project generates its own from any text/font instead.
 *
 * The euclidean distance transform follows Felzenszwalb & Huttenlocher (2012); the routine structure is adapted
 * from Mapbox TinySDF (ISC License, Copyright (c) 2016, Mapbox) - see THIRD_PARTY_NOTICES.md.
 */
const INF = 1e20;

function edt1d(grid, offset, stride, length, f, v, z) {
  v[0] = 0;
  z[0] = -INF;
  z[1] = INF;
  f[0] = grid[offset];
  for (let q = 1, k = 0, s = 0; q < length; q++) {
    f[q] = grid[offset + q * stride];
    const q2 = q * q;
    do {
      const r = v[k];
      s = (f[q] - f[r] + q2 - r * r) / (q - r) / 2;
    } while (s <= z[k] && --k > -1);
    k++;
    v[k] = q;
    z[k] = s;
    z[k + 1] = INF;
  }
  for (let q = 0, k = 0; q < length; q++) {
    while (z[k + 1] < q) k++;
    const r = v[k];
    const qr = q - r;
    grid[offset + q * stride] = f[r] + qr * qr;
  }
}

function edt(data, w, h) {
  const m = Math.max(w, h);
  const f = new Float64Array(m), v = new Uint16Array(m), z = new Float64Array(m + 1);
  for (let x = 0; x < w; x++) edt1d(data, x, w, h, f, v, z);
  for (let y = 0; y < h; y++) edt1d(data, y * w, 1, w, f, v, z);
}

/**
 * Builds the RGBA texture expected by the SDF shader of the upstream catalog:
 *   R = signed distance (negative inside) / maxDistance, remapped to 0..1
 *   G,B = outward normal (x,y) remapped to 0..1,   A = coverage.
 * @param {string} text
 * @param {{font?:string,width?:number,height?:number,maxDistance?:number}} [o]
 * @returns {{width:number,height:number,data:Uint8Array}}  pass to stage.setSdfTexture()
 */
function sdfFromText(text, o = {}) {
  const W = o.width || 900, H = o.height || 340, D = o.maxDistance || 16;
  const font = o.font || '700 210px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  const cv = document.createElement('canvas');
  cv.width = W;
  cv.height = H;
  const x = cv.getContext('2d', { willReadFrequently: true });
  x.font = font;
  x.textAlign = 'center';
  x.textBaseline = 'middle';
  x.fillStyle = '#fff';
  x.fillText(text, W / 2, H / 2 + (o.dy || 0));
  const px = x.getImageData(0, 0, W, H).data, n = W * H;
  const outer = new Float64Array(n), inner = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const a = px[i * 4 + 3] / 255;
    if (a === 1) { outer[i] = 0; inner[i] = INF; }
    else if (a === 0) { outer[i] = INF; inner[i] = 0; }
    else { const d = 0.5 - a; outer[i] = d > 0 ? d * d : 0; inner[i] = d < 0 ? d * d : 0; }
  }
  edt(outer, W, H);
  edt(inner, W, H);
  const d = new Float32Array(n);
  for (let i = 0; i < n; i++) d[i] = Math.sqrt(outer[i]) - Math.sqrt(inner[i]);
  // 3x3 box smoothing before taking the gradient (removes stair-steps in the normals)
  const sm = new Float32Array(n);
  for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) {
    let s = 0, c = 0;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
      const X = xx + i, Y = y + j;
      if (X >= 0 && X < W && Y >= 0 && Y < H) { s += d[Y * W + X]; c++; }
    }
    sm[y * W + xx] = s / c;
  }
  const out = new Uint8Array(n * 4);
  for (let y = 0; y < H; y++) for (let xx = 0; xx < W; xx++) {
    const i = y * W + xx;
    const gx = (sm[y * W + Math.min(W - 1, xx + 1)] - sm[y * W + Math.max(0, xx - 1)]) / 2;
    const gy = (sm[Math.min(H - 1, y + 1) * W + xx] - sm[Math.max(0, y - 1) * W + xx]) / 2;
    const len = Math.hypot(gx, gy), nx = len > 1e-4 ? gx / len : 0, ny = len > 1e-4 ? gy / len : 0;
    out[i * 4] = Math.round((Math.min(1, Math.max(-1, d[i] / D)) * 0.5 + 0.5) * 255);
    out[i * 4 + 1] = Math.round((nx * 0.5 + 0.5) * 255);
    out[i * 4 + 2] = Math.round((ny * 0.5 + 0.5) * 255);
    out[i * 4 + 3] = px[i * 4 + 3];
  }
  return { width: W, height: H, data: out };
}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 *
 * Public API layer. The component behaviours follow the catalog of Kyant0/AndroidLiquidGlass
 * (Apache-2.0, Copyright 2025 Kyant) - see NOTICE.
 */
const DEFAULT_FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

/** true when the browser can run the effects (WebGL2 + canvas 2D). */
function supported() {
  try {
    return !!document.createElement('canvas').getContext('webgl2');
  } catch (e) {
    return false;
  }
}

let rgbaCtx = null;
/** any CSS colour (or [r,g,b(,a)] in 0..1) -> [r,g,b,a] in 0..1 */
function toRGBA(c) {
  if (Array.isArray(c)) return c.length === 3 ? [c[0], c[1], c[2], 1] : c;
  const x = rgbaCtx || (rgbaCtx = document.createElement('canvas').getContext('2d', { willReadFrequently: true }));
  x.canvas.width = x.canvas.height = 1;
  x.clearRect(0, 0, 1, 1);
  x.fillStyle = '#000';
  x.fillStyle = c;
  x.fillRect(0, 0, 1, 1);
  const d = x.getImageData(0, 0, 1, 1).data;
  return [d[0] / 255, d[1] / 255, d[2] / 255, d[3] / 255];
}

/**
 * A Stage owns one background (the "backdrop") painted on a canvas that fills `root`, and every glass element
 * created through it refracts / blurs that background. Put the elements you want to turn into glass inside `root`.
 *
 * @param {HTMLElement} root  container (becomes position:relative if static)
 * @param {object} [options]
 * @param {string|HTMLImageElement|HTMLCanvasElement|ImageBitmap|function(CanvasRenderingContext2D,number,number,number)} [options.background]
 *        image URL / image-like object (drawn "cover") or a draw function (ctx, widthPx, heightPx, dpr). Default: BackdropGlass.backgrounds.aurora
 * @param {number|function():number} [options.blur]  pre-blur of an image background, in css px
 * @param {number[]|function():number[]} [options.dim]  [r,g,b,a] (0..1) overlay painted over the background (it is part of the backdrop)
 * @param {function} [options.extra]  (ctx,w,h,dpr) extra drawing on top of background+dim (also part of the backdrop)
 * @param {boolean|function():boolean} [options.dark]  force light/dark theme (default: prefers-color-scheme)
 * @param {string} [options.accent]  accent colour used by sliders / tabs
 * @param {string} [options.font]  CSS font-family used by tabs
 */
class Stage {
  constructor(root, o = {}) {
    if (!root) throw new Error('Stage: root element required');
    this.root = root;
    this.o = o;
    this._gl = [];
    this._sp = [];
    this._tm = [];
    this.ready = false;
    if (getComputedStyle(root).position === 'static') root.style.position = 'relative';
    root.style.isolation = 'isolate';
    this.cv = document.createElement('canvas');
    this.cv.setAttribute('aria-hidden', 'true');
    this.cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none';
    root.prepend(this.cv);
    this.font = o.font || DEFAULT_FONT;
    this.setBackground(o.background === undefined ? aurora : o.background);
    this._ro = new ResizeObserver(() => this.redraw());
    this._ro.observe(root);
  }

  /** replace the background (same accepted types as the `background` option) */
  setBackground(b) {
    this._src = null;
    this.ready = false;
    if (typeof b === 'string') {
      const im = new Image();
      im.crossOrigin = 'anonymous';
      im.onload = () => { this._src = im; this.redraw(); };
      im.src = b;
    } else {
      this._src = b;
      this.redraw();
    }
  }

  /** repaint the background (call after changing blur/dim/extra, or when you draw a custom background) */
  redraw() {
    const W = this.root.clientWidth, H = this.root.clientHeight, dp = DPR(), b = this._src, o = this.o;
    if (!W || !H || !b) return;
    const w = Math.round(W * dp), hh = Math.round(H * dp), cv = this.cv;
    if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
    const x = cv.getContext('2d'), val = (v) => (typeof v === 'function' ? v() : v);
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.clearRect(0, 0, w, hh);
    const bl = val(o.blur) || 0, m = bl * dp * 2;
    if (typeof b === 'function') {
      if (bl > 0 && 'filter' in x) {
        const t = this._tmp || (this._tmp = document.createElement('canvas'));
        if (t.width !== w || t.height !== hh) { t.width = w; t.height = hh; }
        const tx = t.getContext('2d');
        tx.setTransform(1, 0, 0, 1, 0, 0);
        tx.clearRect(0, 0, w, hh);
        b(tx, w, hh, dp);
        x.save();
        x.filter = 'blur(' + bl * dp + 'px)';
        x.drawImage(t, -m, -m, w + 2 * m, hh + 2 * m);
        x.restore();
      } else {
        b(x, w, hh, dp);
      }
    } else {
      const iw = b.naturalWidth || b.videoWidth || b.width, ih = b.naturalHeight || b.videoHeight || b.height;
      if (!iw || !ih) return;
      const k = Math.max((w + 2 * m) / iw, (hh + 2 * m) / ih);
      x.save();
      if (bl > 0 && 'filter' in x) x.filter = 'blur(' + bl * dp + 'px)';
      x.drawImage(b, (w - iw * k) / 2, (hh - ih * k) / 2, iw * k, ih * k);
      x.restore();
    }
    const d = val(o.dim);
    if (d) {
      x.fillStyle = 'rgba(' + Math.round(d[0] * 255) + ',' + Math.round(d[1] * 255) + ',' + Math.round(d[2] * 255) + ',' + d[3] + ')';
      x.fillRect(0, 0, w, hh);
    }
    if (o.extra) o.extra(x, w, hh, dp);
    this.ready = true;
    wake(60);
  }

  /** request a few animation frames (call after you move/resize glass elements yourself, e.g. on scroll) */
  wake(ms) { wake(ms || 120); }

  dark() {
    const d = this.o.dark;
    return typeof d === 'function' ? !!d() : d !== undefined ? !!d : matchMedia('(prefers-color-scheme: dark)').matches;
  }
  accent() { return this.o.accent || (this.dark() ? '#0091ff' : '#0088ff'); }
  fg() { return this.dark() ? '#fff' : '#000'; }
  container(a) { return this.dark() ? [18 / 255, 18 / 255, 18 / 255, a] : [250 / 255, 250 / 255, 250 / 255, a]; }

  /** (advanced) low-level glass element, same as the catalog's drawBackdrop(...). See docs/API.md */
  gl(host, o) { return gl(this, host, o); }
  IH(host, onTap) { return IH(this, host, onTap); }
  bdScene() { return BDscene(this); }
  _backdrop(b) {
    if (b === undefined || b === null || b === 'scene') return BDscene(this);
    if (typeof b === 'string') return BDsolid(b);
    if (typeof b === 'function') return b;
    if (b.cv && b.hr) return BDlayer(b);
    return BDscene(this);
  }
  _step(f) { SP.add(f); this._sp.push(f); wake(); return f; }
  /** register an animation stepper: f(dtSeconds) -> true while it still needs frames */
  step(f) { return this._step(f); }
  timer(fn, ms) { const id = setInterval(fn, ms); this._tm.push(id); return id; }
  /** upload an SDF texture for the "sdf" effect (see BackdropGlass.sdf.fromText) */
  setSdfTexture(src) { getEngine().setSdf(src); wake(100); }

  /**
   * Turns `el` into a glass surface (declarative form of the catalog's drawBackdrop).
   * @param {HTMLElement} el
   * @param {object} [o]
   * @param {'capsule'|'rect'|number|{radius:number}} [o.shape='capsule']  corner radius in css px (G2 continuous corners)
   * @param {boolean} [o.vibrancy]  saturation boost (vibrancy())
   * @param {{saturation?:number,contrast?:number,brightness?:number}} [o.colorControls]
   * @param {number} [o.blur]  blur radius (css px)
   * @param {{height?:number,amount?:number,depth?:boolean,chromatic?:boolean}} [o.lens]  refraction (css px)
   * @param {string|number[]} [o.surface]  colour painted over the glass (e.g. 'rgba(255,255,255,.3)')
   * @param {string|number[]} [o.tint]  hue-blend tint like LiquidButton's (alpha .75)
   * @param {'default'|'plain'|'ambient'|false} [o.highlight='default']
   * @param {boolean|{radius?:number,offset?:number[],alpha?:number}} [o.shadow=true]
   * @param {false|{radius?:number,offset?:number[],alpha?:number}} [o.innerShadow=false]
   * @param {boolean} [o.interactive]  press scale + light, like LiquidButton (children are transformed with it)
   * @param {function} [o.onClick]
   * @param {string|HTMLElement|function|object} [o.backdrop='scene']  'scene' | css colour | draw fn | another glass handle created with exportBackdrop
   * @param {boolean} [o.exportBackdrop]  make this glass usable as the `backdrop` of other elements
   * @returns the glass handle ({destroy()})
   */
  glass(el, o = {}) {
    const shape = o.shape === undefined ? 'capsule' : o.shape;
    const hl = o.highlight === undefined ? 'default' : o.highlight;
    const sh = o.shadow === undefined ? true : o.shadow;
    const surface = o.surface ? toRGBA(o.surface) : null, tint = o.tint ? toRGBA(o.tint) : null;
    const lens = o.lens ? { height: 24, amount: 24, depth: false, chromatic: false, ...o.lens } : null;
    const cc = o.colorControls ? { saturation: 1, contrast: 1, brightness: 0, ...o.colorControls } : null;
    const ih = o.interactive ? this.IH(el, o.onClick) : null;
    if (!ih && o.onClick) el.addEventListener('click', o.onClick);
    const g = this.gl(el, {
      bg: this._backdrop(o.backdrop), dom: ih ? 1 : 0, smax: ih ? 1.12 : 1, exp: o.exportBackdrop ? 1 : 0,
      fx: (gg, W, H, q) => {
        const m = Math.min(W, H);
        const r = shape === 'capsule' ? m / 2 : shape === 'rect' ? 0 : Math.min(typeof shape === 'number' ? shape : shape.radius || 0, W / 2, H / 2);
        const f = { rad: r * q };
        if (cc) f.cf = [cc.saturation, cc.contrast, cc.brightness]; else if (o.vibrancy) f.cf = VIB;
        if (o.blur) f.blur = o.blur * q;
        if (lens) f.lens = [lens.height * q, lens.amount * q, lens.chromatic ? 1 : 0, lens.depth ? 1 : 0];
        if (tint) { f.t1 = [tint[0], tint[1], tint[2], .75]; f.hue = true; if (surface) f.t2 = surface; } else if (surface) f.t1 = surface;
        if (hl === 'default') f.hi = hiD(q); else if (hl === 'plain') f.hi = hiP(q);
        else if (hl === 'ambient') f.hi = { m: 2, w: .36 * q, b: .25 / 1.5 * q, a: 1 };
        if (f.hi && o.highlightAngle !== undefined) f.hi.angle = o.highlightAngle;
        if (f.hi && o.highlightFalloff !== undefined) f.hi.falloff = o.highlightFalloff;
        if (sh) { const s = sh === true ? {} : sh, rr = s.radius === undefined ? 24 : s.radius; f.sh = { r: rr * q, ox: (s.offset ? s.offset[0] : 0) * q, oy: (s.offset ? s.offset[1] : rr / 6) * q, a: s.alpha === undefined ? .1 : s.alpha }; }
        if (o.innerShadow) { const s = o.innerShadow, rr = s.radius === undefined ? 24 : s.radius; f.is = { r: rr * q, ox: (s.offset ? s.offset[0] : 0) * q, oy: (s.offset ? s.offset[1] : rr) * q, a: s.alpha === undefined ? .15 : s.alpha }; }
        return f;
      },
      xf: ih ? bxf(ih) : undefined, ov: ih ? pov(ih.pp, () => [ih.px.x, ih.py.x]) : undefined,
    });
    g.destroy = () => { GL.delete(g); g.cv.remove(); };
    return g;
  }

  /** LiquidButton. `content`: text or a DOM node. Options: tint, surface, color, onClick, style, backdrop. Returns the element. */
  button(content, o = {}) {
    return makeButton(this, content, { ...o, tint: o.tint ? toRGBA(o.tint).slice(0, 3) : null, backdrop: o.backdrop ? this._backdrop(o.backdrop) : undefined });
  }

  /** LiquidToggle. Options: checked, onChange(bool), backdrop. Returns the element (el.checked, el.setChecked(v)). */
  toggle(o = {}) {
    let on = !!o.checked;
    const el = makeToggle(this, this._backdrop(o.backdrop), () => on, (v) => { on = v; if (o.onChange) o.onChange(v); });
    el.setChecked = (v) => { on = !!v; el.sync(); };
    Object.defineProperty(el, 'checked', { get: () => on });
    return el;
  }

  /** LiquidSlider (fills the width of its parent). Options: value, min, max, onChange(value), backdrop. Returns the element (el.value, el.setValue(v)). */
  slider(o = {}) {
    const min = o.min === undefined ? 0 : o.min, max = o.max === undefined ? 1 : o.max;
    let v = cl(o.value === undefined ? min : o.value, min, max);
    const el = makeSlider(this, this._backdrop(o.backdrop), () => v, (x) => { v = x; if (o.onChange) o.onChange(x); }, min, max, (max - min) * .001);
    el.setValue = (x) => { v = cl(x, min, max); el.sync(); };
    Object.defineProperty(el, 'value', { get: () => v });
    return el;
  }

  /** LiquidBottomTabs. Options: items [{label, icon:{path,w,h}}], selected, onChange(index), style. Returns the element (el.select(i)). */
  tabs(o = {}) {
    return makeTabs(this, o);
  }

  /** remove everything this stage created */
  destroy() {
    this._gl.forEach((g) => { GL.delete(g); g.cv.remove(); });
    this._sp.forEach((f) => SP.delete(f));
    this._tm.forEach(clearInterval);
    this._ro.disconnect();
    this.cv.remove();
  }
}

/*
 * Backdrop Glass Web - Copyright 2026 Backdrop Glass Web contributors
 * Licensed under the Apache License, Version 2.0 (see LICENSE).
 */
const api = {
  version: '1.0.0',
  Stage,
  supported,
  backgrounds: { aurora },
  sdf: { fromText: sdfFromText },
  util: { Sp, DDA, cl, lerp, DPR, easeIn, easeOut, lerpOklab: lerpC, toRGBA, wake },
  /** building blocks used by the demo catalog; less stable than the API above */
  advanced: {
    BD: { solid: BDsolid, scene: BDscene, layer: BDlayer, el: BDel, combine: BDcomb, wrap: BDwrap },
    bxf, pov, hiD, hiP, shD, VIB, G2K, g2clip, layerDraw, PD,
    gestures: { xform, mkT, stepT, xfT, smaxT, hitSync },
  },
};

return api;
});
